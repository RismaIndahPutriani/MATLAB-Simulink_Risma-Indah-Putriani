clearvars; clc;

%Pv spesification
 Wp=350.55
 Voc=43.8
 Isc=10.1
 Vmp=36.9
 Imp=9.5
 
 %Spesifikasi Parameter
 Vin=Vmp
 Vout=24 %Tegangan keluaran yang diinginkan
 Fsw=20000 %Frekuensi 20kHz
 Iripple=0.2 %Presentase 20%
 Vripple=0.05 %Presentase 5%
 
 %Menghitung duty cycle
 D_PG=(Vout/Vin)*100
 D=Vout/Vin
 %Menghitung Arus Keluaran
 Iout=Wp/Vout
 
 %Menghitung Arus Masukan
 Iin_hitung=D*Iout
 Iin=Imp
 
 %Hitung deltaIL dan deltaVL
 deltaIL=Iripple*Iout %deltaI
 deltaVL=Vripple*Vout %deltaV
 
 %Menghitung Induktansi
 L=(Vout*(1-D))/(Fsw*deltaIL) %Rumus fix
 
 %Menghitung Kapasitansi
 C=(1-D)/(8*L*deltaVL*(Fsw)^2) %Rumus fix
 
 %Menghitung Resistansi beban
 R=Vout/Iout
 
 %Menghitung arus maximum dan minimum induktor = beban
 Imax=Vout*((1/R)+((1-D)/(2*L*Fsw)))
 Imin=Vout*((1/R)-((1-D)/(2*L*Fsw)))
 
 %Menghitung arus ripple
 Iripple2=(Vout*(1-D))/(L*Fsw)
 
 %Menghitung tegangan ripple
 Vripple2=(1-D)/(8*L*C*(Fsw)^2)
 
 