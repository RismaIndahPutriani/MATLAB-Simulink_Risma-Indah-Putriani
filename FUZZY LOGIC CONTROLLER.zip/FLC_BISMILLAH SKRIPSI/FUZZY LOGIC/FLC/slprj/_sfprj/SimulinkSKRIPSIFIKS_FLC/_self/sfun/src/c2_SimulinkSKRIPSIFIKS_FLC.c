/* Include files */

#include "SimulinkSKRIPSIFIKS_FLC_sfun.h"
#include "c2_SimulinkSKRIPSIFIKS_FLC.h"
#include <string.h>
#include "mwmathutil.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Forward Declarations */

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static emlrtMCInfo c2_emlrtMCI = { 47, /* lineNo */
  5,                                   /* colNo */
  "repmat",                            /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\elmat\\repmat.m"/* pName */
};

static emlrtMCInfo c2_b_emlrtMCI = { 58,/* lineNo */
  23,                                  /* colNo */
  "assertValidSizeArg",                /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\assertValidSizeArg.m"/* pName */
};

static emlrtMCInfo c2_c_emlrtMCI = { 88,/* lineNo */
  9,                                   /* colNo */
  "eml_int_forloop_overflow_check",    /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"/* pName */
};

static emlrtMCInfo c2_d_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validateTriMFParameterValues",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateTriMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_e_emlrtMCI = { 15,/* lineNo */
  1,                                   /* colNo */
  "validateTriMFParameterValues",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateTriMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_f_emlrtMCI = { 18,/* lineNo */
  1,                                   /* colNo */
  "validateTriMFParameterValues",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateTriMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_g_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validateTrapMFParameterValues",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateTrapMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_h_emlrtMCI = { 15,/* lineNo */
  1,                                   /* colNo */
  "validateTrapMFParameterValues",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateTrapMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_i_emlrtMCI = { 18,/* lineNo */
  1,                                   /* colNo */
  "validateTrapMFParameterValues",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateTrapMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_j_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validateGaussMFParameterValues",    /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateGaussMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_k_emlrtMCI = { 15,/* lineNo */
  1,                                   /* colNo */
  "validateGaussMFParameterValues",    /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateGaussMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_l_emlrtMCI = { 83,/* lineNo */
  5,                                   /* colNo */
  "power",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\ops\\power.m"/* pName */
};

static emlrtMCInfo c2_m_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validateGBellMFParameterValues",    /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateGBellMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_n_emlrtMCI = { 15,/* lineNo */
  1,                                   /* colNo */
  "validateGBellMFParameterValues",    /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateGBellMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_o_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validateSigMFParameterValues",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateSigMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_p_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validateSMFParameterValues",        /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateSMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_q_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validateZMFParameterValues",        /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateZMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_r_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validateGauss2MFParameterValues",   /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateGauss2MFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_s_emlrtMCI = { 15,/* lineNo */
  1,                                   /* colNo */
  "validateGauss2MFParameterValues",   /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateGauss2MFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_t_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validateDSigMFParameterValues",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateDSigMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_u_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validatePSigMFParameterValues",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validatePSigMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_v_emlrtMCI = { 12,/* lineNo */
  1,                                   /* colNo */
  "validatePiMFParameterValues",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validatePiMFParameterValues.m"/* pName */
};

static emlrtMCInfo c2_w_emlrtMCI = { 26,/* lineNo */
  27,                                  /* colNo */
  "unaryMinOrMax",                     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pName */
};

static emlrtMCInfo c2_x_emlrtMCI = { 124,/* lineNo */
  27,                                  /* colNo */
  "unaryMinOrMax",                     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pName */
};

static emlrtMCInfo c2_y_emlrtMCI = { 46,/* lineNo */
  23,                                  /* colNo */
  "sumprod",                           /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\datafun\\private\\sumprod.m"/* pName */
};

static emlrtRSInfo c2_emlrtRSI = { 31, /* lineNo */
  "MATLAB Function",                   /* fcnName */
  "#SimulinkSKRIPSIFIKS_FLC:737"       /* pathName */
};

static emlrtRSInfo c2_b_emlrtRSI = { 37,/* lineNo */
  "evalfis",                           /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\eml\\evalfis.m"/* pathName */
};

static emlrtRSInfo c2_c_emlrtRSI = { 60,/* lineNo */
  "evalfistype1",                      /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evalfistype1.m"/* pathName */
};

static emlrtRSInfo c2_d_emlrtRSI = { 40,/* lineNo */
  "evalfistype1",                      /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evalfistype1.m"/* pathName */
};

static emlrtRSInfo c2_e_emlrtRSI = { 19,/* lineNo */
  "packageAndSetDataType",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pathName */
};

static emlrtRSInfo c2_f_emlrtRSI = { 20,/* lineNo */
  "packageAndSetDataType",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pathName */
};

static emlrtRSInfo c2_g_emlrtRSI = { 37,/* lineNo */
  "packageAndSetDataType",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pathName */
};

static emlrtRSInfo c2_h_emlrtRSI = { 38,/* lineNo */
  "packageAndSetDataType",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pathName */
};

static emlrtRSInfo c2_i_emlrtRSI = { 65,/* lineNo */
  "packageAndSetDataType",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pathName */
};

static emlrtRSInfo c2_j_emlrtRSI = { 262,/* lineNo */
  "packageAndSetDataType",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pathName */
};

static emlrtRSInfo c2_k_emlrtRSI = { 28,/* lineNo */
  "repmat",                            /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\elmat\\repmat.m"/* pathName */
};

static emlrtRSInfo c2_l_emlrtRSI = { 92,/* lineNo */
  "packageAndSetDataType",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pathName */
};

static emlrtRSInfo c2_m_emlrtRSI = { 93,/* lineNo */
  "packageAndSetDataType",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pathName */
};

static emlrtRSInfo c2_n_emlrtRSI = { 134,/* lineNo */
  "packageAndSetDataType",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pathName */
};

static emlrtRSInfo c2_o_emlrtRSI = { 88,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_p_emlrtRSI = { 57,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_q_emlrtRSI = { 60,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_r_emlrtRSI = { 82,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_s_emlrtRSI = { 86,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_t_emlrtRSI = { 104,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_u_emlrtRSI = { 107,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_v_emlrtRSI = { 114,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_w_emlrtRSI = { 116,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_x_emlrtRSI = { 119,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_y_emlrtRSI = { 121,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_ab_emlrtRSI = { 122,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_bb_emlrtRSI = { 125,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_cb_emlrtRSI = { 147,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_db_emlrtRSI = { 16,/* lineNo */
  "createMamdaniOutputMFCache",        /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m"/* pathName */
};

static emlrtRSInfo c2_eb_emlrtRSI = { 23,/* lineNo */
  "createMamdaniOutputMFCache",        /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m"/* pathName */
};

static emlrtRSInfo c2_fb_emlrtRSI = { 64,/* lineNo */
  "evaluateCommonMembershipFcn",       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pathName */
};

static emlrtRSInfo c2_gb_emlrtRSI = { 55,/* lineNo */
  "evaluateCommonMembershipFcn",       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pathName */
};

static emlrtRSInfo c2_hb_emlrtRSI = { 47,/* lineNo */
  "evaluateCommonMembershipFcn",       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pathName */
};

static emlrtRSInfo c2_ib_emlrtRSI = { 45,/* lineNo */
  "evaluateCommonMembershipFcn",       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pathName */
};

static emlrtRSInfo c2_jb_emlrtRSI = { 43,/* lineNo */
  "evaluateCommonMembershipFcn",       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pathName */
};

static emlrtRSInfo c2_kb_emlrtRSI = { 35,/* lineNo */
  "evaluateCommonMembershipFcn",       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pathName */
};

static emlrtRSInfo c2_lb_emlrtRSI = { 66,/* lineNo */
  "evaluateCommonMembershipFcn",       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pathName */
};

static emlrtRSInfo c2_mb_emlrtRSI = { 29,/* lineNo */
  "trimf",                             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\trimf.m"/* pathName */
};

static emlrtRSInfo c2_nb_emlrtRSI = { 34,/* lineNo */
  "trimf",                             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\trimf.m"/* pathName */
};

static emlrtRSInfo c2_ob_emlrtRSI = { 25,/* lineNo */
  "trapmf",                            /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\trapmf.m"/* pathName */
};

static emlrtRSInfo c2_pb_emlrtRSI = { 30,/* lineNo */
  "trapmf",                            /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\trapmf.m"/* pathName */
};

static emlrtRSInfo c2_qb_emlrtRSI = { 30,/* lineNo */
  "gaussmf",                           /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\gaussmf.m"/* pathName */
};

static emlrtRSInfo c2_rb_emlrtRSI = { 34,/* lineNo */
  "gaussmf",                           /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\gaussmf.m"/* pathName */
};

static emlrtRSInfo c2_sb_emlrtRSI = { 71,/* lineNo */
  "power",                             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\ops\\power.m"/* pathName */
};

static emlrtRSInfo c2_tb_emlrtRSI = { 80,/* lineNo */
  "power",                             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\ops\\power.m"/* pathName */
};

static emlrtRSInfo c2_ub_emlrtRSI = { 52,/* lineNo */
  "ixfun",                             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\ixfun.m"/* pathName */
};

static emlrtRSInfo c2_vb_emlrtRSI = { 45,/* lineNo */
  "applyBinaryScalarFunction",         /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pathName */
};

static emlrtRSInfo c2_wb_emlrtRSI = { 66,/* lineNo */
  "applyBinaryScalarFunction",         /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pathName */
};

static emlrtRSInfo c2_xb_emlrtRSI = { 17,/* lineNo */
  "scalexpAlloc",                      /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\scalexpAlloc.m"/* pathName */
};

static emlrtRSInfo c2_yb_emlrtRSI = { 20,/* lineNo */
  "scalexpAllocNoCheck",               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\scalexpAllocNoCheck.m"/* pathName */
};

static emlrtRSInfo c2_ac_emlrtRSI = { 127,/* lineNo */
  "applyBinaryScalarFunction",         /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pathName */
};

static emlrtRSInfo c2_bc_emlrtRSI = { 200,/* lineNo */
  "applyBinaryScalarFunction",         /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pathName */
};

static emlrtRSInfo c2_cc_emlrtRSI = { 21,/* lineNo */
  "eml_int_forloop_overflow_check",    /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"/* pathName */
};

static emlrtRSInfo c2_dc_emlrtRSI = { 44,/* lineNo */
  "mpower",                            /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\ops\\mpower.m"/* pathName */
};

static emlrtRSInfo c2_ec_emlrtRSI = { 33,/* lineNo */
  "gbellmf",                           /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\gbellmf.m"/* pathName */
};

static emlrtRSInfo c2_fc_emlrtRSI = { 38,/* lineNo */
  "gbellmf",                           /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\gbellmf.m"/* pathName */
};

static emlrtRSInfo c2_gc_emlrtRSI = { 30,/* lineNo */
  "sigmf",                             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\sigmf.m"/* pathName */
};

static emlrtRSInfo c2_hc_emlrtRSI = { 76,/* lineNo */
  "div",                               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\div.m"/* pathName */
};

static emlrtRSInfo c2_ic_emlrtRSI = { 259,/* lineNo */
  "div",                               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\div.m"/* pathName */
};

static emlrtRSInfo c2_jc_emlrtRSI = { 186,/* lineNo */
  "applyBinaryScalarFunction",         /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\applyBinaryScalarFunction.m"/* pathName */
};

static emlrtRSInfo c2_kc_emlrtRSI = { 23,/* lineNo */
  "smf",                               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\smf.m"/* pathName */
};

static emlrtRSInfo c2_lc_emlrtRSI = { 28,/* lineNo */
  "smf",                               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\smf.m"/* pathName */
};

static emlrtRSInfo c2_mc_emlrtRSI = { 23,/* lineNo */
  "zmf",                               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\zmf.m"/* pathName */
};

static emlrtRSInfo c2_nc_emlrtRSI = { 28,/* lineNo */
  "zmf",                               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\zmf.m"/* pathName */
};

static emlrtRSInfo c2_oc_emlrtRSI = { 35,/* lineNo */
  "gauss2mf",                          /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\gauss2mf.m"/* pathName */
};

static emlrtRSInfo c2_pc_emlrtRSI = { 44,/* lineNo */
  "gauss2mf",                          /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\gauss2mf.m"/* pathName */
};

static emlrtRSInfo c2_qc_emlrtRSI = { 45,/* lineNo */
  "gauss2mf",                          /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\gauss2mf.m"/* pathName */
};

static emlrtRSInfo c2_rc_emlrtRSI = { 24,/* lineNo */
  "dsigmf",                            /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\dsigmf.m"/* pathName */
};

static emlrtRSInfo c2_sc_emlrtRSI = { 26,/* lineNo */
  "dsigmf",                            /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\dsigmf.m"/* pathName */
};

static emlrtRSInfo c2_tc_emlrtRSI = { 18,/* lineNo */
  "abs",                               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\elfun\\abs.m"/* pathName */
};

static emlrtRSInfo c2_uc_emlrtRSI = { 29,/* lineNo */
  "psigmf",                            /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\psigmf.m"/* pathName */
};

static emlrtRSInfo c2_vc_emlrtRSI = { 32,/* lineNo */
  "pimf",                              /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\pimf.m"/* pathName */
};

static emlrtRSInfo c2_wc_emlrtRSI = { 34,/* lineNo */
  "pimf",                              /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\pimf.m"/* pathName */
};

static emlrtRSInfo c2_xc_emlrtRSI = { 38,/* lineNo */
  "fprintf",                           /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\iofun\\fprintf.m"/* pathName */
};

static emlrtRSInfo c2_yc_emlrtRSI = { 66,/* lineNo */
  "fprintf",                           /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\iofun\\fprintf.m"/* pathName */
};

static emlrtRSInfo c2_ad_emlrtRSI = { 24,/* lineNo */
  "gbellmf",                           /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\gbellmf.m"/* pathName */
};

static emlrtRSInfo c2_bd_emlrtRSI = { 27,/* lineNo */
  "applyOperators",                    /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyOperators.m"/* pathName */
};

static emlrtRSInfo c2_cd_emlrtRSI = { 46,/* lineNo */
  "evaluateAndMethod",                 /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateAndMethod.m"/* pathName */
};

static emlrtRSInfo c2_dd_emlrtRSI = { 33,/* lineNo */
  "evaluateAndMethod",                 /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateAndMethod.m"/* pathName */
};

static emlrtRSInfo c2_ed_emlrtRSI = { 44,/* lineNo */
  "evaluateAndMethod",                 /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateAndMethod.m"/* pathName */
};

static emlrtRSInfo c2_fd_emlrtRSI = { 15,/* lineNo */
  "min",                               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\datafun\\min.m"/* pathName */
};

static emlrtRSInfo c2_gd_emlrtRSI = { 46,/* lineNo */
  "minOrMax",                          /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m"/* pathName */
};

static emlrtRSInfo c2_hd_emlrtRSI = { 92,/* lineNo */
  "minOrMax",                          /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m"/* pathName */
};

static emlrtRSInfo c2_id_emlrtRSI = { 103,/* lineNo */
  "vectorMinOrMaxInPlace",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\vectorMinOrMaxInPlace.m"/* pathName */
};

static emlrtRSInfo c2_jd_emlrtRSI = { 120,/* lineNo */
  "vectorMinOrMaxInPlace",             /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\vectorMinOrMaxInPlace.m"/* pathName */
};

static emlrtRSInfo c2_kd_emlrtRSI = { 48,/* lineNo */
  "evaluateOrMethod",                  /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateOrMethod.m"/* pathName */
};

static emlrtRSInfo c2_ld_emlrtRSI = { 33,/* lineNo */
  "evaluateOrMethod",                  /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateOrMethod.m"/* pathName */
};

static emlrtRSInfo c2_md_emlrtRSI = { 37,/* lineNo */
  "evaluateOrMethod",                  /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateOrMethod.m"/* pathName */
};

static emlrtRSInfo c2_nd_emlrtRSI = { 46,/* lineNo */
  "evaluateOrMethod",                  /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateOrMethod.m"/* pathName */
};

static emlrtRSInfo c2_od_emlrtRSI = { 15,/* lineNo */
  "max",                               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\datafun\\max.m"/* pathName */
};

static emlrtRSInfo c2_pd_emlrtRSI = { 44,/* lineNo */
  "minOrMax",                          /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m"/* pathName */
};

static emlrtRSInfo c2_qd_emlrtRSI = { 79,/* lineNo */
  "minOrMax",                          /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m"/* pathName */
};

static emlrtRSInfo c2_rd_emlrtRSI = { 20,/* lineNo */
  "sum",                               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\datafun\\sum.m"/* pathName */
};

static emlrtRSInfo c2_sd_emlrtRSI = { 183,/* lineNo */
  "sumMatrixIncludeNaN",               /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\datafun\\private\\sumMatrixIncludeNaN.m"/* pathName */
};

static emlrtRSInfo c2_td_emlrtRSI = { 51,/* lineNo */
  "applyMamdaniImplicationMethod",     /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniImplicationMethod.m"/* pathName */
};

static emlrtRSInfo c2_ud_emlrtRSI = { 35,/* lineNo */
  "applyMamdaniImplicationMethod",     /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniImplicationMethod.m"/* pathName */
};

static emlrtRSInfo c2_vd_emlrtRSI = { 49,/* lineNo */
  "applyMamdaniImplicationMethod",     /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniImplicationMethod.m"/* pathName */
};

static emlrtRSInfo c2_wd_emlrtRSI = { 40,/* lineNo */
  "applyMamdaniAggregationMethod",     /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniAggregationMethod.m"/* pathName */
};

static emlrtRSInfo c2_xd_emlrtRSI = { 25,/* lineNo */
  "applyMamdaniAggregationMethod",     /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniAggregationMethod.m"/* pathName */
};

static emlrtRSInfo c2_yd_emlrtRSI = { 29,/* lineNo */
  "applyMamdaniAggregationMethod",     /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniAggregationMethod.m"/* pathName */
};

static emlrtRSInfo c2_ae_emlrtRSI = { 38,/* lineNo */
  "applyMamdaniAggregationMethod",     /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniAggregationMethod.m"/* pathName */
};

static emlrtRSInfo c2_be_emlrtRSI = { 55,/* lineNo */
  "applyMamdaniDefuzzificationMethod", /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniDefuzzificationMethod.m"/* pathName */
};

static emlrtRSInfo c2_ce_emlrtRSI = { 77,/* lineNo */
  "applyMamdaniDefuzzificationMethod", /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniDefuzzificationMethod.m"/* pathName */
};

static emlrtRSInfo c2_de_emlrtRSI = { 15,/* lineNo */
  "applySugenoImplicationMethod",      /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applySugenoImplicationMethod.m"/* pathName */
};

static emlrtRSInfo c2_ee_emlrtRSI = { 13,/* lineNo */
  "createSugenoOutputMFCache",         /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createSugenoOutputMFCache.m"/* pathName */
};

static emlrtRSInfo c2_fe_emlrtRSI = { 20,/* lineNo */
  "createSugenoOutputMFCache",         /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createSugenoOutputMFCache.m"/* pathName */
};

static emlrtRSInfo c2_ge_emlrtRSI = { 29,/* lineNo */
  "evaluateSugenoOutputMembershipFcn", /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateSugenoOutputMembershipFcn.m"/* pathName */
};

static emlrtRSInfo c2_he_emlrtRSI = { 9,/* lineNo */
  "bisector",                          /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\bisector.m"/* pathName */
};

static emlrtRSInfo c2_ie_emlrtRSI = { 21,/* lineNo */
  "fuzzifyInputs",                     /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\fuzzifyInputs.m"/* pathName */
};

static emlrtRSInfo c2_je_emlrtRSI = { 32,/* lineNo */
  "createInputMFCache",                /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createInputMFCache.m"/* pathName */
};

static emlrtRTEInfo c2_emlrtRTEI = { 31,/* lineNo */
  1,                                   /* colNo */
  "MATLAB Function",                   /* fName */
  "#SimulinkSKRIPSIFIKS_FLC:737"       /* pName */
};

static emlrtRTEInfo c2_b_emlrtRTEI = { 220,/* lineNo */
  1,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_c_emlrtRTEI = { 229,/* lineNo */
  10,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_d_emlrtRTEI = { 228,/* lineNo */
  1,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_e_emlrtRTEI = { 19,/* lineNo */
  1,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_f_emlrtRTEI = { 31,/* lineNo */
  1,                                   /* colNo */
  "repmat",                            /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\elmat\\repmat.m"/* pName */
};

static emlrtRTEInfo c2_g_emlrtRTEI = { 262,/* lineNo */
  5,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_h_emlrtRTEI = { 264,/* lineNo */
  41,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_i_emlrtRTEI = { 25,/* lineNo */
  28,                                  /* colNo */
  "char",                              /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\strfun\\char.m"/* pName */
};

static emlrtRTEInfo c2_j_emlrtRTEI = { 26,/* lineNo */
  16,                                  /* colNo */
  "char",                              /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\strfun\\char.m"/* pName */
};

static emlrtRTEInfo c2_k_emlrtRTEI = { 26,/* lineNo */
  9,                                   /* colNo */
  "char",                              /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\strfun\\char.m"/* pName */
};

static emlrtRTEInfo c2_l_emlrtRTEI = { 264,/* lineNo */
  9,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_m_emlrtRTEI = { 265,/* lineNo */
  9,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_n_emlrtRTEI = { 65,/* lineNo */
  1,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_o_emlrtRTEI = { 271,/* lineNo */
  13,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_p_emlrtRTEI = { 292,/* lineNo */
  37,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_q_emlrtRTEI = { 274,/* lineNo */
  13,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_r_emlrtRTEI = { 92,/* lineNo */
  32,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_s_emlrtRTEI = { 123,/* lineNo */
  16,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_t_emlrtRTEI = { 124,/* lineNo */
  23,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_u_emlrtRTEI = { 125,/* lineNo */
  24,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_v_emlrtRTEI = { 128,/* lineNo */
  17,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_w_emlrtRTEI = { 128,/* lineNo */
  12,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_x_emlrtRTEI = { 130,/* lineNo */
  19,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_y_emlrtRTEI = { 134,/* lineNo */
  10,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_ab_emlrtRTEI = { 92,/* lineNo */
  1,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_bb_emlrtRTEI = { 93,/* lineNo */
  33,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_cb_emlrtRTEI = { 143,/* lineNo */
  39,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_db_emlrtRTEI = { 143,/* lineNo */
  9,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_eb_emlrtRTEI = { 144,/* lineNo */
  41,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_fb_emlrtRTEI = { 144,/* lineNo */
  9,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_gb_emlrtRTEI = { 93,/* lineNo */
  1,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_hb_emlrtRTEI = { 145,/* lineNo */
  49,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_ib_emlrtRTEI = { 146,/* lineNo */
  50,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_jb_emlrtRTEI = { 109,/* lineNo */
  1,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtRTEInfo c2_kb_emlrtRTEI = { 14,/* lineNo */
  32,                                  /* colNo */
  "createMamdaniOutputMFCache",        /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m"/* pName */
};

static emlrtRTEInfo c2_lb_emlrtRTEI = { 16,/* lineNo */
  25,                                  /* colNo */
  "createMamdaniOutputMFCache",        /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m"/* pName */
};

static emlrtRTEInfo c2_mb_emlrtRTEI = { 22,/* lineNo */
  58,                                  /* colNo */
  "createMamdaniOutputMFCache",        /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m"/* pName */
};

static emlrtRTEInfo c2_nb_emlrtRTEI = { 24,/* lineNo */
  13,                                  /* colNo */
  "createMamdaniOutputMFCache",        /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m"/* pName */
};

static emlrtRTEInfo c2_ob_emlrtRTEI = { 26,/* lineNo */
  13,                                  /* colNo */
  "createMamdaniOutputMFCache",        /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m"/* pName */
};

static emlrtRTEInfo c2_pb_emlrtRTEI = { 25,/* lineNo */
  13,                                  /* colNo */
  "createMamdaniOutputMFCache",        /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m"/* pName */
};

static emlrtRTEInfo c2_qb_emlrtRTEI = { 1,/* lineNo */
  19,                                  /* colNo */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m"/* pName */
};

static emlrtRTEInfo c2_rb_emlrtRTEI = { 14,/* lineNo */
  32,                                  /* colNo */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m"/* pName */
};

static emlrtRTEInfo c2_sb_emlrtRTEI = { 21,/* lineNo */
  5,                                   /* colNo */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m"/* pName */
};

static emlrtRTEInfo c2_tb_emlrtRTEI = { 17,/* lineNo */
  20,                                  /* colNo */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m"/* pName */
};

static emlrtRTEInfo c2_ub_emlrtRTEI = { 18,/* lineNo */
  22,                                  /* colNo */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m"/* pName */
};

static emlrtRTEInfo c2_vb_emlrtRTEI = { 16,/* lineNo */
  9,                                   /* colNo */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m"/* pName */
};

static emlrtRTEInfo c2_wb_emlrtRTEI = { 14,/* lineNo */
  1,                                   /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_xb_emlrtRTEI = { 29,/* lineNo */
  5,                                   /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_yb_emlrtRTEI = { 29,/* lineNo */
  6,                                   /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_ac_emlrtRTEI = { 34,/* lineNo */
  16,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_bc_emlrtRTEI = { 42,/* lineNo */
  20,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_cc_emlrtRTEI = { 35,/* lineNo */
  22,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_dc_emlrtRTEI = { 35,/* lineNo */
  24,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_ec_emlrtRTEI = { 44,/* lineNo */
  20,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_fc_emlrtRTEI = { 46,/* lineNo */
  20,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_gc_emlrtRTEI = { 45,/* lineNo */
  20,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_hc_emlrtRTEI = { 34,/* lineNo */
  21,                                  /* colNo */
  "sigmf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\sigmf.m"/* pName */
};

static emlrtRTEInfo c2_ic_emlrtRTEI = { 45,/* lineNo */
  22,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_jc_emlrtRTEI = { 54,/* lineNo */
  20,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_kc_emlrtRTEI = { 47,/* lineNo */
  20,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_lc_emlrtRTEI = { 77,/* lineNo */
  9,                                   /* colNo */
  "eml_mtimes_helper",                 /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"/* pName */
};

static emlrtRTEInfo c2_mc_emlrtRTEI = { 47,/* lineNo */
  22,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_nc_emlrtRTEI = { 55,/* lineNo */
  21,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_oc_emlrtRTEI = { 34,/* lineNo */
  9,                                   /* colNo */
  "sigmf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\sigmf.m"/* pName */
};

static emlrtRTEInfo c2_pc_emlrtRTEI = { 55,/* lineNo */
  23,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_qc_emlrtRTEI = { 43,/* lineNo */
  16,                                  /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtRTEInfo c2_rc_emlrtRTEI = { 29,/* lineNo */
  53,                                  /* colNo */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\trimf.m"/* pName */
};

static emlrtRTEInfo c2_sc_emlrtRTEI = { 34,/* lineNo */
  5,                                   /* colNo */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\trimf.m"/* pName */
};

static emlrtRTEInfo c2_tc_emlrtRTEI = { 28,/* lineNo */
  5,                                   /* colNo */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\smf.m"/* pName */
};

static emlrtRTEInfo c2_uc_emlrtRTEI = { 28,/* lineNo */
  5,                                   /* colNo */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\zmf.m"/* pName */
};

static emlrtRTEInfo c2_vc_emlrtRTEI = { 34,/* lineNo */
  10,                                  /* colNo */
  "pimf",                              /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\pimf.m"/* pName */
};

static emlrtRTEInfo c2_wc_emlrtRTEI = { 34,/* lineNo */
  31,                                  /* colNo */
  "pimf",                              /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\pimf.m"/* pName */
};

static emlrtRTEInfo c2_xc_emlrtRTEI = { 34,/* lineNo */
  1,                                   /* colNo */
  "pimf",                              /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\pimf.m"/* pName */
};

static emlrtRTEInfo c2_yc_emlrtRTEI = { 17,/* lineNo */
  42,                                  /* colNo */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m"/* pName */
};

static emlrtRTEInfo c2_ad_emlrtRTEI = { 18,/* lineNo */
  46,                                  /* colNo */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m"/* pName */
};

static emlrtRTEInfo c2_bd_emlrtRTEI = { 2,/* lineNo */
  5,                                   /* colNo */
  "applyOperators",                    /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyOperators.m"/* pName */
};

static emlrtRTEInfo c2_cd_emlrtRTEI = { 45,/* lineNo */
  13,                                  /* colNo */
  "applyMamdaniImplicationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniImplicationMethod.m"/* pName */
};

static emlrtRTEInfo c2_dd_emlrtRTEI = { 62,/* lineNo */
  5,                                   /* colNo */
  "applyMamdaniImplicationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniImplicationMethod.m"/* pName */
};

static emlrtRTEInfo c2_ed_emlrtRTEI = { 185,/* lineNo */
  38,                                  /* colNo */
  "unaryMinOrMax",                     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pName */
};

static emlrtRTEInfo c2_fd_emlrtRTEI = { 50,/* lineNo */
  36,                                  /* colNo */
  "applyMamdaniAggregationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniAggregationMethod.m"/* pName */
};

static emlrtRTEInfo c2_gd_emlrtRTEI = { 34,/* lineNo */
  13,                                  /* colNo */
  "applyMamdaniAggregationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniAggregationMethod.m"/* pName */
};

static emlrtRTEInfo c2_hd_emlrtRTEI = { 175,/* lineNo */
  38,                                  /* colNo */
  "unaryMinOrMax",                     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\eml\\+coder\\+internal\\unaryMinOrMax.m"/* pName */
};

static emlrtRTEInfo c2_id_emlrtRTEI = { 55,/* lineNo */
  30,                                  /* colNo */
  "applyMamdaniDefuzzificationMethod", /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniDefuzzificationMethod.m"/* pName */
};

static emlrtRTEInfo c2_jd_emlrtRTEI = { 78,/* lineNo */
  21,                                  /* colNo */
  "applyMamdaniDefuzzificationMethod", /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniDefuzzificationMethod.m"/* pName */
};

static emlrtRTEInfo c2_kd_emlrtRTEI = { 78,/* lineNo */
  52,                                  /* colNo */
  "applyMamdaniDefuzzificationMethod", /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniDefuzzificationMethod.m"/* pName */
};

static emlrtRTEInfo c2_ld_emlrtRTEI = { 35,/* lineNo */
  20,                                  /* colNo */
  "sumMatrixIncludeNaN",               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\datafun\\private\\sumMatrixIncludeNaN.m"/* pName */
};

static emlrtRTEInfo c2_md_emlrtRTEI = { 42,/* lineNo */
  42,                                  /* colNo */
  "sumMatrixIncludeNaN",               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\datafun\\private\\sumMatrixIncludeNaN.m"/* pName */
};

static emlrtRTEInfo c2_nd_emlrtRTEI = { 29,/* lineNo */
  30,                                  /* colNo */
  "applySugenoDefuzzificationMethod",  /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applySugenoDefuzzificationMethod.m"/* pName */
};

static emlrtRTEInfo c2_od_emlrtRTEI = { 58,/* lineNo */
  27,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_pd_emlrtRTEI = { 82,/* lineNo */
  65,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_qd_emlrtRTEI = { 61,/* lineNo */
  27,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_rd_emlrtRTEI = { 105,/* lineNo */
  19,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_sd_emlrtRTEI = { 107,/* lineNo */
  24,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_td_emlrtRTEI = { 108,/* lineNo */
  31,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ud_emlrtRTEI = { 109,/* lineNo */
  1,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_vd_emlrtRTEI = { 115,/* lineNo */
  11,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_wd_emlrtRTEI = { 115,/* lineNo */
  35,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_xd_emlrtRTEI = { 114,/* lineNo */
  6,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_yd_emlrtRTEI = { 117,/* lineNo */
  13,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ae_emlrtRTEI = { 116,/* lineNo */
  6,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_be_emlrtRTEI = { 126,/* lineNo */
  69,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ce_emlrtRTEI = { 120,/* lineNo */
  15,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_de_emlrtRTEI = { 119,/* lineNo */
  18,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ee_emlrtRTEI = { 125,/* lineNo */
  17,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_fe_emlrtRTEI = { 121,/* lineNo */
  75,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ge_emlrtRTEI = { 125,/* lineNo */
  10,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_he_emlrtRTEI = { 122,/* lineNo */
  13,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ie_emlrtRTEI = { 123,/* lineNo */
  13,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_je_emlrtRTEI = { 127,/* lineNo */
  9,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ke_emlrtRTEI = { 121,/* lineNo */
  18,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_le_emlrtRTEI = { 128,/* lineNo */
  13,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_me_emlrtRTEI = { 123,/* lineNo */
  43,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ne_emlrtRTEI = { 129,/* lineNo */
  13,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_oe_emlrtRTEI = { 122,/* lineNo */
  18,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_pe_emlrtRTEI = { 129,/* lineNo */
  17,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_qe_emlrtRTEI = { 128,/* lineNo */
  18,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_re_emlrtRTEI = { 108,/* lineNo */
  1,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_se_emlrtRTEI = { 96,/* lineNo */
  5,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_te_emlrtRTEI = { 141,/* lineNo */
  20,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ue_emlrtRTEI = { 142,/* lineNo */
  22,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ve_emlrtRTEI = { 143,/* lineNo */
  22,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_we_emlrtRTEI = { 144,/* lineNo */
  22,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_xe_emlrtRTEI = { 145,/* lineNo */
  22,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ye_emlrtRTEI = { 147,/* lineNo */
  48,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_af_emlrtRTEI = { 150,/* lineNo */
  5,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_bf_emlrtRTEI = { 147,/* lineNo */
  52,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_cf_emlrtRTEI = { 151,/* lineNo */
  38,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_df_emlrtRTEI = { 147,/* lineNo */
  5,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ef_emlrtRTEI = { 148,/* lineNo */
  5,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_ff_emlrtRTEI = { 147,/* lineNo */
  21,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_gf_emlrtRTEI = { 1,/* lineNo */
  43,                                  /* colNo */
  "fuzzifyInputs",                     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\fuzzifyInputs.m"/* pName */
};

static emlrtRTEInfo c2_hf_emlrtRTEI = { 12,/* lineNo */
  1,                                   /* colNo */
  "applySugenoImplicationMethod",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applySugenoImplicationMethod.m"/* pName */
};

static emlrtRTEInfo c2_if_emlrtRTEI = { 13,/* lineNo */
  1,                                   /* colNo */
  "applySugenoImplicationMethod",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applySugenoImplicationMethod.m"/* pName */
};

static emlrtRTEInfo c2_jf_emlrtRTEI = { 15,/* lineNo */
  1,                                   /* colNo */
  "applySugenoImplicationMethod",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applySugenoImplicationMethod.m"/* pName */
};

static emlrtRTEInfo c2_kf_emlrtRTEI = { 13,/* lineNo */
  25,                                  /* colNo */
  "createSugenoOutputMFCache",         /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createSugenoOutputMFCache.m"/* pName */
};

static emlrtRTEInfo c2_lf_emlrtRTEI = { 22,/* lineNo */
  20,                                  /* colNo */
  "createSugenoOutputMFCache",         /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createSugenoOutputMFCache.m"/* pName */
};

static emlrtRTEInfo c2_mf_emlrtRTEI = { 136,/* lineNo */
  5,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtRTEInfo c2_nf_emlrtRTEI = { 28,/* lineNo */
  27,                                  /* colNo */
  "applyOperators",                    /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyOperators.m"/* pName */
};

static emlrtRTEInfo c2_of_emlrtRTEI = { 21,/* lineNo */
  23,                                  /* colNo */
  "fuzzifyInputs",                     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\fuzzifyInputs.m"/* pName */
};

static emlrtRTEInfo c2_pf_emlrtRTEI = { 33,/* lineNo */
  13,                                  /* colNo */
  "createInputMFCache",                /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createInputMFCache.m"/* pName */
};

static emlrtRTEInfo c2_qf_emlrtRTEI = { 35,/* lineNo */
  13,                                  /* colNo */
  "createInputMFCache",                /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createInputMFCache.m"/* pName */
};

static emlrtBCInfo c2_emlrtBCI = { -1, /* iFirst */
  -1,                                  /* iLast */
  34,                                  /* lineNo */
  26,                                  /* colNo */
  "result",                            /* aName */
  "MATLAB Function",                   /* fName */
  "#SimulinkSKRIPSIFIKS_FLC:737",      /* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_b_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  271,                                 /* lineNo */
  27,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo c2_emlrtECI = { -1, /* nDims */
  271,                                 /* lineNo */
  13,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtBCInfo c2_c_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  274,                                 /* lineNo */
  27,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo c2_b_emlrtECI = { -1,/* nDims */
  274,                                 /* lineNo */
  13,                                  /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtECInfo c2_c_emlrtECI = { -1,/* nDims */
  292,                                 /* lineNo */
  9,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtBCInfo c2_d_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  265,                                 /* lineNo */
  23,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_e_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  264,                                 /* lineNo */
  23,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_f_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  25,                                  /* lineNo */
  28,                                  /* colNo */
  "",                                  /* aName */
  "char",                              /* fName */
  "C:\\MATLAB ANYA\\toolbox\\eml\\lib\\matlab\\strfun\\char.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_g_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  266,                                 /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_h_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  267,                                 /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_i_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  272,                                 /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_j_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  275,                                 /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_k_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  264,                                 /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_l_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  265,                                 /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_m_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  124,                                 /* lineNo */
  32,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_n_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  125,                                 /* lineNo */
  33,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_o_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  143,                                 /* lineNo */
  23,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo c2_d_emlrtECI = { -1,/* nDims */
  143,                                 /* lineNo */
  9,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtBCInfo c2_p_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  144,                                 /* lineNo */
  23,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo c2_e_emlrtECI = { -1,/* nDims */
  144,                                 /* lineNo */
  9,                                   /* colNo */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m"/* pName */
};

static emlrtBCInfo c2_q_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  143,                                 /* lineNo */
  52,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_r_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  144,                                 /* lineNo */
  54,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_s_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  145,                                 /* lineNo */
  49,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_t_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  145,                                 /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_u_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  146,                                 /* lineNo */
  50,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_v_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  146,                                 /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_w_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  143,                                 /* lineNo */
  39,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_x_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  144,                                 /* lineNo */
  41,                                  /* colNo */
  "",                                  /* aName */
  "packageAndSetDataType",             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\packageAndSetDataType.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo c2_f_emlrtECI = { -1,/* nDims */
  22,                                  /* lineNo */
  9,                                   /* colNo */
  "createMamdaniOutputMFCache",        /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m"/* pName */
};

static emlrtDCInfo c2_emlrtDCI = { 14, /* lineNo */
  38,                                  /* colNo */
  "createMamdaniOutputMFCache",        /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c2_y_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  17,                                  /* lineNo */
  40,                                  /* colNo */
  "",                                  /* aName */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ab_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  17,                                  /* lineNo */
  42,                                  /* colNo */
  "",                                  /* aName */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_bb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  18,                                  /* lineNo */
  44,                                  /* colNo */
  "",                                  /* aName */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_cb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  18,                                  /* lineNo */
  46,                                  /* colNo */
  "",                                  /* aName */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo c2_g_emlrtECI = { -1,/* nDims */
  55,                                  /* lineNo */
  9,                                   /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtECInfo c2_h_emlrtECI = { -1,/* nDims */
  47,                                  /* lineNo */
  9,                                   /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtECInfo c2_i_emlrtECI = { -1,/* nDims */
  45,                                  /* lineNo */
  9,                                   /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtECInfo c2_j_emlrtECI = { -1,/* nDims */
  43,                                  /* lineNo */
  9,                                   /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtECInfo c2_k_emlrtECI = { -1,/* nDims */
  35,                                  /* lineNo */
  9,                                   /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtECInfo c2_l_emlrtECI = { -1,/* nDims */
  29,                                  /* lineNo */
  6,                                   /* colNo */
  "evaluateCommonMembershipFcn",       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateCommonMembershipFcn.m"/* pName */
};

static emlrtBCInfo c2_db_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  32,                                  /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "sigmf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\sigmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_eb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  33,                                  /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "sigmf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\sigmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_fb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  8,                                   /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_gb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  9,                                   /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_hb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  10,                                  /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ib_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  16,                                  /* lineNo */
  23,                                  /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_jb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  16,                                  /* lineNo */
  31,                                  /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_kb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  21,                                  /* lineNo */
  23,                                  /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_lb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  21,                                  /* lineNo */
  31,                                  /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_mb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  17,                                  /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_nb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  17,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ob_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  26,                                  /* lineNo */
  8,                                   /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_pb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  27,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_qb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  22,                                  /* lineNo */
  19,                                  /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_rb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  22,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "trimf",                             /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\trimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_sb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  15,                                  /* lineNo */
  31,                                  /* colNo */
  "",                                  /* aName */
  "validateTriMFParameterValues",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateTriMFParameterValues.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_tb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  15,                                  /* lineNo */
  43,                                  /* colNo */
  "",                                  /* aName */
  "validateTriMFParameterValues",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateTriMFParameterValues.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ub_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  18,                                  /* lineNo */
  31,                                  /* colNo */
  "",                                  /* aName */
  "validateTriMFParameterValues",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateTriMFParameterValues.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_vb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  18,                                  /* lineNo */
  43,                                  /* colNo */
  "",                                  /* aName */
  "validateTriMFParameterValues",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+utility\\validateTriMFParameterValues.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_wb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  8,                                   /* lineNo */
  18,                                  /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_xb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  9,                                   /* lineNo */
  18,                                  /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_yb_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  22,                                  /* lineNo */
  14,                                  /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ac_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  22,                                  /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_bc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  23,                                  /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_cc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  27,                                  /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_dc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  24,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ec_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  27,                                  /* lineNo */
  31,                                  /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_fc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  28,                                  /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_gc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  32,                                  /* lineNo */
  14,                                  /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_hc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  29,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ic_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  33,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "smf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\smf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_jc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  8,                                   /* lineNo */
  18,                                  /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_kc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  9,                                   /* lineNo */
  18,                                  /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_lc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  20,                                  /* lineNo */
  8,                                   /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_mc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  21,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_nc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  24,                                  /* lineNo */
  14,                                  /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_oc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  24,                                  /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_pc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  25,                                  /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_qc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  29,                                  /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_rc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  26,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_sc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  29,                                  /* lineNo */
  31,                                  /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_tc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  30,                                  /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_uc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  34,                                  /* lineNo */
  14,                                  /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_vc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  31,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_wc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  35,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "zmf",                               /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\zmf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo c2_m_emlrtECI = { 2,/* nDims */
  34,                                  /* lineNo */
  10,                                  /* colNo */
  "pimf",                              /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\pimf.m"/* pName */
};

static emlrtBCInfo c2_xc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  34,                                  /* lineNo */
  24,                                  /* colNo */
  "",                                  /* aName */
  "pimf",                              /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\pimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_yc_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  34,                                  /* lineNo */
  45,                                  /* colNo */
  "",                                  /* aName */
  "pimf",                              /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\pimf.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ad_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  17,                                  /* lineNo */
  32,                                  /* colNo */
  "",                                  /* aName */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_bd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  18,                                  /* lineNo */
  34,                                  /* colNo */
  "",                                  /* aName */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_cd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  16,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_dd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  17,                                  /* lineNo */
  20,                                  /* colNo */
  "",                                  /* aName */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ed_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  18,                                  /* lineNo */
  22,                                  /* colNo */
  "",                                  /* aName */
  "extractVarMF",                      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\extractVarMF.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_fd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  81,                                  /* lineNo */
  17,                                  /* colNo */
  "",                                  /* aName */
  "applyMamdaniImplicationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniImplicationMethod.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_gd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  80,                                  /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "applyMamdaniImplicationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniImplicationMethod.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_hd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  96,                                  /* lineNo */
  26,                                  /* colNo */
  "",                                  /* aName */
  "applyMamdaniImplicationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniImplicationMethod.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_id_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  95,                                  /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "applyMamdaniImplicationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniImplicationMethod.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_jd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  60,                                  /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "applyMamdaniAggregationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniAggregationMethod.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_kd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  68,                                  /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "applyMamdaniAggregationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniAggregationMethod.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ld_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  63,                                  /* lineNo */
  44,                                  /* colNo */
  "",                                  /* aName */
  "applyMamdaniAggregationMethod",     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applyMamdaniAggregationMethod.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_md_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  17,                                  /* lineNo */
  22,                                  /* colNo */
  "",                                  /* aName */
  "centroid",                          /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\centroid.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_nd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  22,                                  /* lineNo */
  23,                                  /* colNo */
  "",                                  /* aName */
  "centroid",                          /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\centroid.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_od_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  25,                                  /* lineNo */
  20,                                  /* colNo */
  "",                                  /* aName */
  "centroid",                          /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\centroid.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_pd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  25,                                  /* lineNo */
  25,                                  /* colNo */
  "",                                  /* aName */
  "centroid",                          /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\centroid.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_qd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  12,                                  /* lineNo */
  23,                                  /* colNo */
  "",                                  /* aName */
  "bisector",                          /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\bisector.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_rd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  24,                                  /* lineNo */
  12,                                  /* colNo */
  "",                                  /* aName */
  "bisector",                          /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\bisector.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_sd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  18,                                  /* lineNo */
  26,                                  /* colNo */
  "",                                  /* aName */
  "bisector",                          /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\bisector.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo c2_n_emlrtECI = { -1,/* nDims */
  114,                                 /* lineNo */
  13,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtECInfo c2_o_emlrtECI = { -1,/* nDims */
  119,                                 /* lineNo */
  9,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtECInfo c2_p_emlrtECI = { -1,/* nDims */
  121,                                 /* lineNo */
  9,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtECInfo c2_q_emlrtECI = { -1,/* nDims */
  125,                                 /* lineNo */
  10,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtECInfo c2_r_emlrtECI = { -1,/* nDims */
  127,                                 /* lineNo */
  9,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtECInfo c2_s_emlrtECI = { -1,/* nDims */
  122,                                 /* lineNo */
  9,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtECInfo c2_t_emlrtECI = { -1,/* nDims */
  128,                                 /* lineNo */
  9,                                   /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtECInfo c2_u_emlrtECI = { -1,/* nDims */
  125,                                 /* lineNo */
  17,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pName */
};

static emlrtDCInfo c2_b_emlrtDCI = { 108,/* lineNo */
  39,                                  /* colNo */
  "evaluateFIS",                       /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c2_td_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  14,                                  /* lineNo */
  19,                                  /* colNo */
  "",                                  /* aName */
  "linear",                            /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\linear.m",/* pName */
  0                                    /* checkKind */
};

static emlrtDCInfo c2_c_emlrtDCI = { 15,/* lineNo */
  1,                                   /* colNo */
  "applySugenoImplicationMethod",      /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\applySugenoImplicationMethod.m",/* pName */
  1                                    /* checkKind */
};

static emlrtBCInfo c2_ud_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  11,                                  /* lineNo */
  21,                                  /* colNo */
  "",                                  /* aName */
  "linear",                            /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\linear.m",/* pName */
  0                                    /* checkKind */
};

static emlrtECInfo c2_v_emlrtECI = { -1,/* nDims */
  21,                                  /* lineNo */
  5,                                   /* colNo */
  "fuzzifyInputs",                     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\fuzzifyInputs.m"/* pName */
};

static emlrtBCInfo c2_vd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  33,                                  /* lineNo */
  30,                                  /* colNo */
  "",                                  /* aName */
  "createInputMFCache",                /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createInputMFCache.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_wd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  35,                                  /* lineNo */
  30,                                  /* colNo */
  "",                                  /* aName */
  "createInputMFCache",                /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createInputMFCache.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_xd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  37,                                  /* lineNo */
  43,                                  /* colNo */
  "",                                  /* aName */
  "fuzzifyInputs",                     /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\fuzzifyInputs.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_yd_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  31,                                  /* lineNo */
  9,                                   /* colNo */
  "",                                  /* aName */
  "createInputMFCache",                /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createInputMFCache.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_ae_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  33,                                  /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "createInputMFCache",                /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createInputMFCache.m",/* pName */
  0                                    /* checkKind */
};

static emlrtBCInfo c2_be_emlrtBCI = { -1,/* iFirst */
  -1,                                  /* iLast */
  35,                                  /* lineNo */
  13,                                  /* colNo */
  "",                                  /* aName */
  "createInputMFCache",                /* fName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createInputMFCache.m",/* pName */
  0                                    /* checkKind */
};

static emlrtRSInfo c2_ke_emlrtRSI = { 115,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_le_emlrtRSI = { 108,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_me_emlrtRSI = { 147,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_ne_emlrtRSI = { 150,/* lineNo */
  "evaluateFIS",                       /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\evaluateFIS.m"/* pathName */
};

static emlrtRSInfo c2_oe_emlrtRSI = { 14,/* lineNo */
  "createMamdaniOutputMFCache",        /* fcnName */
  "C:\\MATLAB ANYA\\toolbox\\fuzzy\\fuzzy\\+fuzzy\\+internal\\+codegen\\private\\createMamdaniOutputMFCache.m"/* pathName */
};

static const char_T c2_cv[15] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'p', 'm',
  'a', 'x', 's', 'i', 'z', 'e' };

static const char_T c2_cv1[41] = { 'f', 'u', 'z', 'z', 'y', ':', 'g', 'e', 'n',
  'e', 'r', 'a', 'l', ':', 'e', 'r', 'r', 'S', 'i', 'g', 'm', 'f', '_', 'I', 'n',
  'v', 'a', 'l', 'i', 'd', 'P', 'a', 'r', 'a', 'm', 'L', 'e', 'n', 'g', 't', 'h'
};

static const char_T c2_cv2[91] = { 'T', 'o', ' ', 'u', 's', 'e', ' ', 'c', 'u',
  's', 't', 'o', 'm', ' ', '%', 's', ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
  ' ', '\'', '%', 's', '\'', ',', ' ', 'r', 'u', 'n', ' ', 'y', 'o', 'u', 'r',
  ' ', 'M', 'A', 'T', 'L', 'A', 'B', ' ', 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n',
  ' ', 'o', 'r', ' ', 's', 'c', 'r', 'i', 'p', 't', ' ', 'b', 'e', 'f', 'o', 'r',
  'e', ' ', 'g', 'e', 'n', 'e', 'r', 'a', 't', 'i', 'n', 'g', ' ', 'c', 'o', 'd',
  'e', '.', '\x0a' };

static const char_T c2_cv3[10] = { 'm', 'e', 'm', 'b', 'e', 'r', 's', 'h', 'i',
  'p' };

static const char_T c2_cv4[39] = { 'f', 'u', 'z', 'z', 'y', ':', 'g', 'e', 'n',
  'e', 'r', 'a', 'l', ':', 'e', 'r', 'r', 'S', 'm', 'f', '_', 'I', 'n', 'v', 'a',
  'l', 'i', 'd', 'P', 'a', 'r', 'a', 'm', 'L', 'e', 'n', 'g', 't', 'h' };

static const char_T c2_cv5[39] = { 'f', 'u', 'z', 'z', 'y', ':', 'g', 'e', 'n',
  'e', 'r', 'a', 'l', ':', 'e', 'r', 'r', 'Z', 'm', 'f', '_', 'I', 'n', 'v', 'a',
  'l', 'i', 'd', 'P', 'a', 'r', 'a', 'm', 'L', 'e', 'n', 'g', 't', 'h' };

static const char_T c2_cv6[40] = { 'f', 'u', 'z', 'z', 'y', ':', 'g', 'e', 'n',
  'e', 'r', 'a', 'l', ':', 'e', 'r', 'r', 'P', 'i', 'm', 'f', '_', 'I', 'n', 'v',
  'a', 'l', 'i', 'd', 'P', 'a', 'r', 'a', 'm', 'L', 'e', 'n', 'g', 't', 'h' };

static const char_T *c2_sv[5] = { "name", "origNameLength", "range", "mf",
  "origNumMF" };

/* Function Declarations */
static void initialize_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void initialize_params_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void enable_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void disable_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void c2_update_jit_animation_state_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void c2_do_animation_call_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void ext_mode_exec_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void set_sim_state_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const mxArray
   *c2_st);
static void sf_gateway_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void mdl_start_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void mdl_terminate_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void mdl_setup_runtime_resources_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void mdl_cleanup_runtime_resources_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void initSimStructsc2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance);
static void c2_packageAndSetDataType(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *
  chartInstance, const emlrtStack *c2_sp, c2_s4qsEqaDHXG669afyZjSQlH *c2_fis,
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_b_fis);
static void c2_assertValidSizeArg(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_varargin_2);
static boolean_T c2_strcmp(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, char_T c2_a[7]);
static void c2_setDataType(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_s_GBys1jprGfE2uYETSBX2vH *c2_fisin,
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fisout);
static void c2_createMamdaniOutputMFCache
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T
   c2_outputSamplePoints_data[], int32_T c2_outputSamplePoints_size[2],
   c2_emxArray_real_T *c2_outputMFCache);
static real_T c2_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance);
static void c2_extractVarMF(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_s_64TxJFgCtXBlX73DcwNLAB *c2_varin,
  c2_cell_wrap_0 c2_varout[1]);
static void c2_evaluateCommonMembershipFcn
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, char_T c2_mfType_data[], int32_T c2_mfType_size[2], real_T c2_x_data[],
   int32_T c2_x_size[2], real_T c2_params_data[], int32_T c2_params_size[2],
   real_T c2_y_data[], int32_T c2_y_size[2]);
static boolean_T c2_isequal(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, char_T c2_varargin_1_data[], int32_T c2_varargin_1_size[2],
  uint8_T c2_varargin_2[5]);
static void c2_trimf(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
                     const emlrtStack *c2_sp, real_T c2_x_data[], int32_T
                     c2_x_size[2], real_T c2_params_data[], int32_T
                     c2_params_size[2], real_T c2_y_data[], int32_T c2_y_size[2]);
static void c2_validateTriMFParameterValues
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_params_data[], int32_T c2_params_size[2]);
static boolean_T c2_b_isequal(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, char_T c2_varargin_1_data[], int32_T c2_varargin_1_size[2],
  uint8_T c2_varargin_2[3]);
static void c2_smf(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
                   const emlrtStack *c2_sp, real_T c2_x_data[], int32_T
                   c2_x_size[2], real_T c2_params_data[], int32_T
                   c2_params_size[2], real_T c2_y_data[], int32_T c2_y_size[2]);
static void c2_zmf(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
                   const emlrtStack *c2_sp, real_T c2_x_data[], int32_T
                   c2_x_size[2], real_T c2_params_data[], int32_T
                   c2_params_size[2], real_T c2_y_data[], int32_T c2_y_size[2]);
static boolean_T c2_c_isequal(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, char_T c2_varargin_1_data[], int32_T c2_varargin_1_size[2],
  uint8_T c2_varargin_2[4]);
static void c2_pimf(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
                    const emlrtStack *c2_sp, real_T c2_x_data[], int32_T
                    c2_x_size[2], real_T c2_params_data[], int32_T
                    c2_params_size[2], real_T c2_y_data[], int32_T c2_y_size[2]);
static void c2_b_extractVarMF(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_s_64TxJFgCtXBlX73DcwNLAB c2_varin
  [2], c2_cell_wrap_0 c2_varout[2]);
static real_T c2_b_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance);
static void c2_applyOperators(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_fuzzifiedInputs_data[],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_varargin_1_data[], real_T
  c2_varargin_2_data[], real_T c2_antecedentOutputs_data[], int32_T
  c2_antecedentOutputs_size[1], real_T *c2_sumAntecedentOutputs, real_T
  c2_irrOfOneRule_data[], int32_T c2_irrOfOneRule_size[1]);
static real_T c2_c_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, real_T c2_x_data[], int32_T c2_vlen);
static void c2_applyMamdaniImplicationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_antecedentOutputs_data[], c2_s_9DL33rUTgryGqqXf4f6A1E
   *c2_fis, c2_emxArray_real_T *c2_varargin_1, real_T c2_consequentOutputs_data[],
   int32_T c2_consequentOutputs_size[2]);
static void c2_applyMamdaniAggregationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_consequentOutputs_data[], int32_T
   c2_consequentOutputs_size[2], c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T
   c2_aggregatedOutputs_data[], int32_T c2_aggregatedOutputs_size[2]);
static real_T c2_d_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, real_T c2_x[2]);
static void c2_applyMamdaniDefuzzificationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_outputSamplePoints_data[], int32_T
   c2_outputSamplePoints_size[2], real_T c2_sumAntecedentOutputs, real_T
   c2_aggregatedOutputs_data[], int32_T c2_aggregatedOutputs_size[2],
   c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_defuzzifiedOutputs_data[],
   int32_T c2_defuzzifiedOutputs_size[1]);
static void c2_applySugenoAggregationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, real_T
   c2_consequentOutputs_data[], int32_T c2_consequentOutputs_size[2], real_T
   c2_aggregatedOutputs_data[], int32_T c2_aggregatedOutputs_size[2]);
static real_T c2_e_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, real_T c2_x_data[], int32_T c2_x_size[2], int32_T c2_col,
  int32_T c2_vlen);
static void c2_applySugenoDefuzzificationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, real_T
   c2_sumAntecedentOutputs, real_T c2_aggregatedOutputs_data[],
   c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_defuzzifiedOutputs_data[],
   int32_T c2_defuzzifiedOutputs_size[1]);
static void c2_b_applyMamdaniDefuzzificationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_outputSamplePoints_data[], int32_T
   c2_outputSamplePoints_size[2], real_T c2_sumAntecedentOutputs, real_T
   c2_aggregatedOutputs_data[], int32_T c2_aggregatedOutputs_size[2],
   c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_defuzzifiedOutputs_data[],
   int32_T c2_defuzzifiedOutputs_size[1]);
static void c2_b_applySugenoDefuzzificationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, real_T
   c2_sumAntecedentOutputs, real_T c2_aggregatedOutputs_data[],
   c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_defuzzifiedOutputs_data[],
   int32_T c2_defuzzifiedOutputs_size[1]);
static real_T c2_f_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, real_T c2_x);
static void c2_evaluateFIS(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_inputs[2],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_y_data[], int32_T c2_y_size[2]);
static void c2_runFIS(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
                      const emlrtStack *c2_sp, real_T c2_inputs[2],
                      c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_y_data[],
                      int32_T c2_y_size[2], real_T c2_irr_data[], int32_T
                      c2_irr_size[2], real_T c2_orr_data[], int32_T c2_orr_size
                      [2], real_T c2_arr_data[], int32_T c2_arr_size[2], real_T
                      c2_w_data[], int32_T c2_w_size[1], real_T
                      c2_unImpSugRuleOut_data[], int32_T
                      c2_unImpSugRuleOut_size[2]);
static void c2_initVariables(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis,
  int32_T c2_y_size[2], int32_T c2_irr_size[2], int32_T c2_orr_size[2], int32_T
  c2_arr_size[2], int32_T c2_rfs_size[1], real_T c2_unImpSugRuleOut_data[],
  int32_T c2_unImpSugRuleOut_size[2], c2_emxArray_real_T *c2_outputMFCache);
static void c2_fuzzifyInputs(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_inputs[2],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, c2_cell_wrap_0 c2_varargin_1[2],
  c2_emxArray_real_T *c2_varargin_2, real_T c2_varargin_3_data[], real_T
  c2_fuzzifiedInputs_data[], int32_T c2_fuzzifiedInputs_size[2],
  c2_emxArray_real_T *c2_inputMFCache);
static void c2_applySugenoImplicationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_inputs[2], real_T c2_antecedentOutputs_data[],
   c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_consequentOutputs_data[],
   int32_T c2_consequentOutputs_size[2], real_T c2_unscaledOutputs_data[],
   int32_T c2_unscaledOutputs_size[2]);
static void c2_b_runFIS(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_inputs[2],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_y_data[], int32_T c2_y_size[2],
  real_T c2_irr_data[], int32_T c2_irr_size[2], real_T c2_orr_data[], int32_T
  c2_orr_size[2], real_T c2_arr_data[], int32_T c2_arr_size[2], real_T
  c2_w_data[], int32_T c2_w_size[1], real_T c2_unImpSugRuleOut_data[], int32_T
  c2_unImpSugRuleOut_size[2]);
static void c2_b_initVariables(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis,
  int32_T c2_y_size[2], int32_T c2_irr_size[2], int32_T c2_orr_size[2], int32_T
  c2_arr_size[2], int32_T c2_rfs_size[1], real_T c2_unImpSugRuleOut_data[],
  int32_T c2_unImpSugRuleOut_size[2]);
static real_T c2_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_a__output_of_feval_, const char_T
  *c2_identifier);
static real_T c2_b_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static const mxArray *c2_emlrt_marshallOut
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const
   c2_suvN3HkMprFcIaMRVdi47eC c2_u[5]);
static real_T c2_c_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_b_D_prev, const char_T *c2_identifier,
  boolean_T *c2_svPtr);
static real_T c2_d_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  boolean_T *c2_svPtr);
static void c2_e_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_b_fis_obj, const char_T *c2_identifier,
  boolean_T *c2_svPtr, c2_s4qsEqaDHXG669afyZjSQlH *c2_y);
static void c2_f_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  boolean_T *c2_svPtr, c2_s4qsEqaDHXG669afyZjSQlH *c2_y);
static void c2_g_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  char_T c2_y[8]);
static void c2_h_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  char_T c2_y[7]);
static void c2_i_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  char_T c2_y[3]);
static void c2_j_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  c2_s5XYxtK6icIzLqFV4FdSKVC c2_y[2]);
static void c2_k_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  char_T c2_y[2]);
static void c2_l_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  real_T c2_y[2]);
static void c2_m_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  c2_suvN3HkMprFcIaMRVdi47eC c2_y[5]);
static void c2_n_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  char_T c2_y[5]);
static void c2_o_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  real_T c2_y[3]);
static void c2_p_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  c2_s5XYxtK6icIzLqFV4FdSKVC *c2_y);
static void c2_q_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  c2_sEsqUUSxQBFGTGyl15EzrYH c2_y[24]);
static uint8_T c2_r_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *
  chartInstance, const mxArray *c2_b_is_active_c2_SimulinkSKRIPSIFIKS_FLC, const
  char_T *c2_identifier);
static uint8_T c2_s_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *
  chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_chart_data_browse_helper
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, int32_T
   c2_ssIdNumber, const mxArray **c2_mxData, uint8_T *c2_isValueTooBig);
static const mxArray *c2_feval(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, const mxArray *c2_input0, const
  mxArray *c2_input1, const mxArray *c2_input2, const mxArray *c2_input3, const
  mxArray *c2_input4);
static const mxArray *c2_b_feval(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, const mxArray *c2_input0, const
  mxArray *c2_input1, const mxArray *c2_input2, const mxArray *c2_input3, const
  mxArray *c2_input4);
static const mxArray *c2_c_feval(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, const mxArray *c2_input0, const
  mxArray *c2_input1, const mxArray *c2_input2, const mxArray *c2_input3, const
  mxArray *c2_input4);
static const mxArray *c2_d_feval(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, const mxArray *c2_input0, const
  mxArray *c2_input1, const mxArray *c2_input2, const mxArray *c2_input3, const
  mxArray *c2_input4);
static const mxArray *c2_e_feval(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, const mxArray *c2_input0, const
  mxArray *c2_input1, const mxArray *c2_input2, const mxArray *c2_input3, const
  mxArray *c2_input4);
static real_T c2_b_applyOperators(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_fuzzifiedInputs_data[],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_varargin_1_data[], real_T
  c2_varargin_2_data[]);
static void c2_b_fuzzifyInputs(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_inputs[2],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, c2_cell_wrap_0 c2_varargin_1[2],
  c2_emxArray_real_T *c2_varargin_2, real_T c2_varargin_3_data[],
  c2_emxArray_real_T *c2_inputMFCache);
static void c2_emxInitStruct_s_o4k2e0vdltB60Wn
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_o4k2e0vdltB60WnSYJQFVC *c2_pStruct);
static void c2_emxExpand_s_o4k2e0vdltB60WnSYJQ
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_o4k2e0vdltB60WnSYJQFVC c2_data[5], int32_T c2_fromIndex, int32_T
   c2_toIndex);
static void c2_emxInitStruct_s_8hQCdWJdSJhbjCf
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_8hQCdWJdSJhbjCfdgdfm1F *c2_pStruct);
static void c2_emxExpand_s_8hQCdWJdSJhbjCfdgdf
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_8hQCdWJdSJhbjCfdgdfm1F c2_data[5], int32_T c2_fromIndex, int32_T
   c2_toIndex);
static void c2_emxEnsureCapacity_real_T
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, c2_emxArray_real_T *c2_emxArray, int32_T c2_oldNumel, const
   emlrtRTEInfo *c2_srcLocation);
static void c2_emxInitStruct_s_JbR9CE1JwmiHOtK
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_JbR9CE1JwmiHOtKI7rv0ED *c2_pStruct);
static void c2_emxExpand_s_JbR9CE1JwmiHOtKI7rv
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_JbR9CE1JwmiHOtKI7rv0ED c2_data[5], int32_T c2_fromIndex, int32_T
   c2_toIndex);
static void c2_emxInit_real_T(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_emxArray_real_T **c2_pEmxArray,
  int32_T c2_numDimensions, const emlrtRTEInfo *c2_srcLocation);
static void c2_emxFree_real_T(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, c2_emxArray_real_T **c2_pEmxArray);
static void c2_emxEnsureCapacity_real_T1
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, c2_emxArray_real_T *c2_emxArray, int32_T c2_oldNumel, const
   emlrtRTEInfo *c2_srcLocation);
static void c2_emxInit_real_T1(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_emxArray_real_T **c2_pEmxArray,
  int32_T c2_numDimensions, const emlrtRTEInfo *c2_srcLocation);
static int32_T c2__s32_s64_(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, int64_T c2_b, int32_T c2_EMLOvCount_src_loc, uint32_T
  c2_ssid_src_loc, int32_T c2_offset_src_loc, int32_T c2_length_src_loc);
static void init_dsm_address_info(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance);
static void init_simulink_io_address(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *
  chartInstance);

/* Function Definitions */
static void initialize_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  emlrtStack c2_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  c2_st.tls = chartInstance->c2_fEmlrtCtx;
  emlrtLicenseCheckR2012b(&c2_st, (const char_T *)"fuzzy_toolbox", 2);
  sim_mode_is_external(chartInstance->S);
  chartInstance->c2_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c2_fis_obj_not_empty = false;
  chartInstance->c2_D_prev_not_empty = false;
  chartInstance->c2_E_prev_not_empty = false;
  chartInstance->c2_is_active_c2_SimulinkSKRIPSIFIKS_FLC = 0U;
}

static void initialize_params_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void enable_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void c2_update_jit_animation_state_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c2_do_animation_call_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  sfDoAnimationWrapper(chartInstance->S, false, true);
  sfDoAnimationWrapper(chartInstance->S, false, false);
}

static void ext_mode_exec_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static const mxArray *get_sim_state_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  static const char_T *c2_b_sv[10] = { "name", "type", "andMethod", "orMethod",
    "defuzzMethod", "impMethod", "aggMethod", "input", "output", "rule" };

  static const char_T *c2_sv1[5] = { "name", "origNameLength", "range", "mf",
    "origNumMF" };

  static const char_T *c2_sv2[4] = { "antecedent", "consequent", "weight",
    "connection" };

  c2_s5XYxtK6icIzLqFV4FdSKVC c2_d_u[2];
  const c2_s5XYxtK6icIzLqFV4FdSKVC *c2_r;
  c2_s5XYxtK6icIzLqFV4FdSKVC c2_e_u;
  c2_sEsqUUSxQBFGTGyl15EzrYH c2_l_u[24];
  const c2_sEsqUUSxQBFGTGyl15EzrYH *c2_r1;
  c2_suvN3HkMprFcIaMRVdi47eC c2_rv[5];
  const mxArray *c2_ab_y = NULL;
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_bb_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_cb_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_e_y = NULL;
  const mxArray *c2_f_y = NULL;
  const mxArray *c2_g_y = NULL;
  const mxArray *c2_h_y = NULL;
  const mxArray *c2_i_y = NULL;
  const mxArray *c2_j_y = NULL;
  const mxArray *c2_k_y = NULL;
  const mxArray *c2_l_y = NULL;
  const mxArray *c2_m_y = NULL;
  const mxArray *c2_n_y = NULL;
  const mxArray *c2_o_y = NULL;
  const mxArray *c2_p_y = NULL;
  const mxArray *c2_q_y = NULL;
  const mxArray *c2_r_y = NULL;
  const mxArray *c2_s_y = NULL;
  const mxArray *c2_st;
  const mxArray *c2_t_y = NULL;
  const mxArray *c2_u_y = NULL;
  const mxArray *c2_v_y = NULL;
  const mxArray *c2_w_y = NULL;
  const mxArray *c2_x_y = NULL;
  const mxArray *c2_y = NULL;
  const mxArray *c2_y_y = NULL;
  real_T c2_i_u[2];
  real_T c2_g_u;
  real_T c2_h_u;
  real_T c2_j_u;
  real_T c2_k_u;
  real_T c2_m_u;
  real_T c2_n_u;
  real_T c2_o_u;
  int32_T c2_iv[2];
  int32_T c2_iv1[2];
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  char_T c2_u[8];
  char_T c2_b_u[7];
  char_T c2_c_u[3];
  char_T c2_f_u[2];
  c2_st = NULL;
  c2_st = NULL;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_createcellmatrix(5, 1), false);
  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", chartInstance->c2_D, 0, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 0, c2_b_y);
  c2_c_y = NULL;
  if (!chartInstance->c2_D_prev_not_empty) {
    sf_mex_assign(&c2_c_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0),
                  false);
  } else {
    sf_mex_assign(&c2_c_y, sf_mex_create("y", &chartInstance->c2_D_prev, 0, 0U,
      0U, 0U, 0), false);
  }

  sf_mex_setcell(c2_y, 1, c2_c_y);
  c2_d_y = NULL;
  if (!chartInstance->c2_D_prev_not_empty) {
    sf_mex_assign(&c2_d_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0),
                  false);
  } else {
    sf_mex_assign(&c2_d_y, sf_mex_create("y", &chartInstance->c2_E_prev, 0, 0U,
      0U, 0U, 0), false);
  }

  sf_mex_setcell(c2_y, 2, c2_d_y);
  c2_e_y = NULL;
  if (!chartInstance->c2_fis_obj_not_empty) {
    sf_mex_assign(&c2_e_y, sf_mex_create("y", NULL, 0, 0U, 1U, 0U, 2, 0, 0),
                  false);
  } else {
    sf_mex_assign(&c2_e_y, sf_mex_createstruct("structure", 10, c2_b_sv, 2, 1, 1),
                  false);
    for (c2_i = 0; c2_i < 8; c2_i++) {
      c2_u[c2_i] = chartInstance->c2_fis_obj.name[c2_i];
    }

    c2_f_y = NULL;
    sf_mex_assign(&c2_f_y, sf_mex_create("y", c2_u, 10, 0U, 1U, 0U, 2, 1, 8),
                  false);
    sf_mex_setfieldbynum(c2_e_y, 0, "name", c2_f_y, 0);
    for (c2_i1 = 0; c2_i1 < 7; c2_i1++) {
      c2_b_u[c2_i1] = chartInstance->c2_fis_obj.type[c2_i1];
    }

    c2_h_y = NULL;
    sf_mex_assign(&c2_h_y, sf_mex_create("y", c2_b_u, 10, 0U, 1U, 0U, 2, 1, 7),
                  false);
    sf_mex_setfieldbynum(c2_e_y, 0, "type", c2_h_y, 1);
    for (c2_i2 = 0; c2_i2 < 3; c2_i2++) {
      c2_c_u[c2_i2] = chartInstance->c2_fis_obj.andMethod[c2_i2];
    }

    c2_i_y = NULL;
    sf_mex_assign(&c2_i_y, sf_mex_create("y", c2_c_u, 10, 0U, 1U, 0U, 2, 1, 3),
                  false);
    sf_mex_setfieldbynum(c2_e_y, 0, "andMethod", c2_i_y, 2);
    for (c2_i3 = 0; c2_i3 < 3; c2_i3++) {
      c2_c_u[c2_i3] = chartInstance->c2_fis_obj.orMethod[c2_i3];
    }

    c2_j_y = NULL;
    sf_mex_assign(&c2_j_y, sf_mex_create("y", c2_c_u, 10, 0U, 1U, 0U, 2, 1, 3),
                  false);
    sf_mex_setfieldbynum(c2_e_y, 0, "orMethod", c2_j_y, 3);
    for (c2_i4 = 0; c2_i4 < 8; c2_i4++) {
      c2_u[c2_i4] = chartInstance->c2_fis_obj.defuzzMethod[c2_i4];
    }

    c2_k_y = NULL;
    sf_mex_assign(&c2_k_y, sf_mex_create("y", c2_u, 10, 0U, 1U, 0U, 2, 1, 8),
                  false);
    sf_mex_setfieldbynum(c2_e_y, 0, "defuzzMethod", c2_k_y, 4);
    for (c2_i5 = 0; c2_i5 < 3; c2_i5++) {
      c2_c_u[c2_i5] = chartInstance->c2_fis_obj.impMethod[c2_i5];
    }

    c2_l_y = NULL;
    sf_mex_assign(&c2_l_y, sf_mex_create("y", c2_c_u, 10, 0U, 1U, 0U, 2, 1, 3),
                  false);
    sf_mex_setfieldbynum(c2_e_y, 0, "impMethod", c2_l_y, 5);
    for (c2_i6 = 0; c2_i6 < 3; c2_i6++) {
      c2_c_u[c2_i6] = chartInstance->c2_fis_obj.aggMethod[c2_i6];
    }

    c2_m_y = NULL;
    sf_mex_assign(&c2_m_y, sf_mex_create("y", c2_c_u, 10, 0U, 1U, 0U, 2, 1, 3),
                  false);
    sf_mex_setfieldbynum(c2_e_y, 0, "aggMethod", c2_m_y, 6);
    for (c2_i7 = 0; c2_i7 < 2; c2_i7++) {
      c2_d_u[c2_i7] = chartInstance->c2_fis_obj.input[c2_i7];
    }

    c2_n_y = NULL;
    for (c2_i8 = 0; c2_i8 < 2; c2_i8++) {
      c2_iv[c2_i8] = 1 + c2_i8;
    }

    sf_mex_assign(&c2_n_y, sf_mex_createstructarray("structure", 2, c2_iv, 5,
      c2_sv1), false);
    for (c2_i9 = 0; c2_i9 < 2; c2_i9++) {
      c2_r = &c2_d_u[c2_i9];
      for (c2_i10 = 0; c2_i10 < 2; c2_i10++) {
        c2_f_u[c2_i10] = c2_r->name[c2_i10];
      }

      c2_p_y = NULL;
      sf_mex_assign(&c2_p_y, sf_mex_create("y", c2_f_u, 10, 0U, 1U, 0U, 2, 1, 2),
                    false);
      sf_mex_setfieldbynum(c2_n_y, c2_i9, "name", c2_p_y, 0);
      c2_g_u = c2_r->origNameLength;
      c2_r_y = NULL;
      sf_mex_assign(&c2_r_y, sf_mex_create("y", &c2_g_u, 0, 0U, 0U, 0U, 0),
                    false);
      sf_mex_setfieldbynum(c2_n_y, c2_i9, "origNameLength", c2_r_y, 1);
      for (c2_i12 = 0; c2_i12 < 2; c2_i12++) {
        c2_i_u[c2_i12] = c2_r->range[c2_i12];
      }

      c2_t_y = NULL;
      sf_mex_assign(&c2_t_y, sf_mex_create("y", c2_i_u, 0, 0U, 1U, 0U, 2, 1, 2),
                    false);
      sf_mex_setfieldbynum(c2_n_y, c2_i9, "range", c2_t_y, 2);
      for (c2_i14 = 0; c2_i14 < 5; c2_i14++) {
        c2_rv[c2_i14] = c2_r->mf[c2_i14];
      }

      sf_mex_setfieldbynum(c2_n_y, c2_i9, "mf", c2_emlrt_marshallOut
                           (chartInstance, c2_rv), 3);
      c2_j_u = c2_r->origNumMF;
      c2_v_y = NULL;
      sf_mex_assign(&c2_v_y, sf_mex_create("y", &c2_j_u, 0, 0U, 0U, 0U, 0),
                    false);
      sf_mex_setfieldbynum(c2_n_y, c2_i9, "origNumMF", c2_v_y, 4);
    }

    sf_mex_setfieldbynum(c2_e_y, 0, "input", c2_n_y, 7);
    c2_e_u = chartInstance->c2_fis_obj.output;
    c2_o_y = NULL;
    sf_mex_assign(&c2_o_y, sf_mex_createstruct("structure", 5, c2_sv1, 2, 1, 1),
                  false);
    for (c2_i11 = 0; c2_i11 < 2; c2_i11++) {
      c2_f_u[c2_i11] = c2_e_u.name[c2_i11];
    }

    c2_q_y = NULL;
    sf_mex_assign(&c2_q_y, sf_mex_create("y", c2_f_u, 10, 0U, 1U, 0U, 2, 1, 2),
                  false);
    sf_mex_setfieldbynum(c2_o_y, 0, "name", c2_q_y, 0);
    c2_h_u = c2_e_u.origNameLength;
    c2_s_y = NULL;
    sf_mex_assign(&c2_s_y, sf_mex_create("y", &c2_h_u, 0, 0U, 0U, 0U, 0), false);
    sf_mex_setfieldbynum(c2_o_y, 0, "origNameLength", c2_s_y, 1);
    for (c2_i13 = 0; c2_i13 < 2; c2_i13++) {
      c2_i_u[c2_i13] = c2_e_u.range[c2_i13];
    }

    c2_u_y = NULL;
    sf_mex_assign(&c2_u_y, sf_mex_create("y", c2_i_u, 0, 0U, 1U, 0U, 2, 1, 2),
                  false);
    sf_mex_setfieldbynum(c2_o_y, 0, "range", c2_u_y, 2);
    sf_mex_setfieldbynum(c2_o_y, 0, "mf", c2_emlrt_marshallOut(chartInstance,
      c2_e_u.mf), 3);
    c2_k_u = c2_e_u.origNumMF;
    c2_w_y = NULL;
    sf_mex_assign(&c2_w_y, sf_mex_create("y", &c2_k_u, 0, 0U, 0U, 0U, 0), false);
    sf_mex_setfieldbynum(c2_o_y, 0, "origNumMF", c2_w_y, 4);
    sf_mex_setfieldbynum(c2_e_y, 0, "output", c2_o_y, 8);
    for (c2_i15 = 0; c2_i15 < 24; c2_i15++) {
      c2_l_u[c2_i15] = chartInstance->c2_fis_obj.rule[c2_i15];
    }

    c2_x_y = NULL;
    for (c2_i16 = 0; c2_i16 < 2; c2_i16++) {
      c2_iv1[c2_i16] = 1 + 23 * c2_i16;
    }

    sf_mex_assign(&c2_x_y, sf_mex_createstructarray("structure", 2, c2_iv1, 4,
      c2_sv2), false);
    for (c2_i17 = 0; c2_i17 < 24; c2_i17++) {
      c2_r1 = &c2_l_u[c2_i17];
      for (c2_i18 = 0; c2_i18 < 2; c2_i18++) {
        c2_i_u[c2_i18] = c2_r1->antecedent[c2_i18];
      }

      c2_y_y = NULL;
      sf_mex_assign(&c2_y_y, sf_mex_create("y", c2_i_u, 0, 0U, 1U, 0U, 2, 1, 2),
                    false);
      sf_mex_setfieldbynum(c2_x_y, c2_i17, "antecedent", c2_y_y, 0);
      c2_m_u = c2_r1->consequent;
      c2_ab_y = NULL;
      sf_mex_assign(&c2_ab_y, sf_mex_create("y", &c2_m_u, 0, 0U, 0U, 0U, 0),
                    false);
      sf_mex_setfieldbynum(c2_x_y, c2_i17, "consequent", c2_ab_y, 1);
      c2_n_u = c2_r1->weight;
      c2_bb_y = NULL;
      sf_mex_assign(&c2_bb_y, sf_mex_create("y", &c2_n_u, 0, 0U, 0U, 0U, 0),
                    false);
      sf_mex_setfieldbynum(c2_x_y, c2_i17, "weight", c2_bb_y, 2);
      c2_o_u = c2_r1->connection;
      c2_cb_y = NULL;
      sf_mex_assign(&c2_cb_y, sf_mex_create("y", &c2_o_u, 0, 0U, 0U, 0U, 0),
                    false);
      sf_mex_setfieldbynum(c2_x_y, c2_i17, "connection", c2_cb_y, 3);
    }

    sf_mex_setfieldbynum(c2_e_y, 0, "rule", c2_x_y, 9);
  }

  sf_mex_setcell(c2_y, 3, c2_e_y);
  c2_g_y = NULL;
  sf_mex_assign(&c2_g_y, sf_mex_create("y",
    &chartInstance->c2_is_active_c2_SimulinkSKRIPSIFIKS_FLC, 3, 0U, 0U, 0U, 0),
                false);
  sf_mex_setcell(c2_y, 4, c2_g_y);
  sf_mex_assign(&c2_st, c2_y, false);
  return c2_st;
}

static void set_sim_state_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const mxArray
   *c2_st)
{
  c2_s4qsEqaDHXG669afyZjSQlH c2_r;
  const mxArray *c2_u;
  chartInstance->c2_doneDoubleBufferReInit = true;
  c2_u = sf_mex_dup(c2_st);
  *chartInstance->c2_D = c2_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c2_u, 0)), "D");
  chartInstance->c2_D_prev = c2_c_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c2_u, 1)), "D_prev", &chartInstance->c2_D_prev_not_empty);
  chartInstance->c2_E_prev = c2_c_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c2_u, 2)), "E_prev", &chartInstance->c2_E_prev_not_empty);
  c2_e_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 3)),
                        "fis_obj", &chartInstance->c2_fis_obj_not_empty, &c2_r);
  chartInstance->c2_fis_obj = c2_r;
  chartInstance->c2_is_active_c2_SimulinkSKRIPSIFIKS_FLC = c2_r_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 4)),
     "is_active_c2_SimulinkSKRIPSIFIKS_FLC");
  sf_mex_destroy(&c2_u);
  sf_mex_destroy(&c2_st);
}

static void sf_gateway_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  static c2_s4qsEqaDHXG669afyZjSQlH c2_r = { { 'm', 'p', 'p', 't', '_', 'f', 'l',
      'c' },                           /* name */

    { 'm', 'a', 'm', 'd', 'a', 'n', 'i' },/* type */

    { 'm', 'i', 'n' },                 /* andMethod */

    { 'm', 'a', 'x' },                 /* orMethod */

    { 'c', 'e', 'n', 't', 'r', 'o', 'i', 'd' },/* defuzzMethod */

    { 'm', 'i', 'n' },                 /* impMethod */

    { 'm', 'a', 'x' },                 /* aggMethod */

    { { { 'E', '\x00' },               /* name */
        1.0,                           /* origNameLength */

        { -1.0, 1.0 },                 /* range */

        { { { 'N', 'B' },              /* name */
            2.0,                       /* origNameLength */

            { 't', 'r', 'i', 'm', 'f' },/* type */
            5.0,                       /* origTypeLength */

            { -1.0, -1.0, -0.5 },      /* params */
            3.0                        /* origParamLength */
          }, { { 'N', 'S' },           /* name */
            2.0,                       /* origNameLength */

            { 't', 'r', 'i', 'm', 'f' },/* type */
            5.0,                       /* origTypeLength */

            { -1.0, -0.5, 0.0 },       /* params */
            3.0                        /* origParamLength */
          }, { { 'Z', 'E' },           /* name */
            2.0,                       /* origNameLength */

            { 't', 'r', 'i', 'm', 'f' },/* type */
            5.0,                       /* origTypeLength */

            { -0.5, 0.0, 0.5 },        /* params */
            3.0                        /* origParamLength */
          }, { { 'P', 'S' },           /* name */
            2.0,                       /* origNameLength */

            { 't', 'r', 'i', 'm', 'f' },/* type */
            5.0,                       /* origTypeLength */

            { 0.0, 0.5, 1.0 },         /* params */
            3.0                        /* origParamLength */
          }, { { 'P', 'B' },           /* name */
            2.0,                       /* origNameLength */

            { 't', 'r', 'i', 'm', 'f' },/* type */
            5.0,                       /* origTypeLength */

            { 0.5, 1.0, 1.0 },         /* params */
            3.0                        /* origParamLength */
          } },                         /* mf */
        5.0                            /* origNumMF */
      }, { { 'd', 'E' },               /* name */
        2.0,                           /* origNameLength */

        { -1.0, 1.0 },                 /* range */

        { { { 'N', 'B' },              /* name */
            2.0,                       /* origNameLength */

            { 't', 'r', 'i', 'm', 'f' },/* type */
            5.0,                       /* origTypeLength */

            { -1.0, -1.0, -0.5 },      /* params */
            3.0                        /* origParamLength */
          }, { { 'N', 'S' },           /* name */
            2.0,                       /* origNameLength */

            { 't', 'r', 'i', 'm', 'f' },/* type */
            5.0,                       /* origTypeLength */

            { -1.0, -0.5, 0.0 },       /* params */
            3.0                        /* origParamLength */
          }, { { 'Z', 'E' },           /* name */
            2.0,                       /* origNameLength */

            { 't', 'r', 'i', 'm', 'f' },/* type */
            5.0,                       /* origTypeLength */

            { -0.5, 0.0, 0.5 },        /* params */
            3.0                        /* origParamLength */
          }, { { 'P', 'S' },           /* name */
            2.0,                       /* origNameLength */

            { 't', 'r', 'i', 'm', 'f' },/* type */
            5.0,                       /* origTypeLength */

            { 0.0, 0.5, 1.0 },         /* params */
            3.0                        /* origParamLength */
          }, { { 'P', 'B' },           /* name */
            2.0,                       /* origNameLength */

            { 't', 'r', 'i', 'm', 'f' },/* type */
            5.0,                       /* origTypeLength */

            { 0.5, 1.0, 1.0 },         /* params */
            3.0                        /* origParamLength */
          } },                         /* mf */
        5.0                            /* origNumMF */
      } },                             /* input */

    { { 'd', 'D' },                    /* name */
      2.0,                             /* origNameLength */

      { -0.05, 0.05 },                 /* range */

      { { { 'N', 'B' },                /* name */
          2.0,                         /* origNameLength */

          { 't', 'r', 'i', 'm', 'f' }, /* type */
          5.0,                         /* origTypeLength */

          { -0.05, -0.05, -0.025 },    /* params */
          3.0                          /* origParamLength */
        }, { { 'N', 'S' },             /* name */
          2.0,                         /* origNameLength */

          { 't', 'r', 'i', 'm', 'f' }, /* type */
          5.0,                         /* origTypeLength */

          { -0.05, -0.025, 0.0 },      /* params */
          3.0                          /* origParamLength */
        }, { { 'Z', 'E' },             /* name */
          2.0,                         /* origNameLength */

          { 't', 'r', 'i', 'm', 'f' }, /* type */
          5.0,                         /* origTypeLength */

          { -0.025, 0.0, 0.025 },      /* params */
          3.0                          /* origParamLength */
        }, { { 'P', 'S' },             /* name */
          2.0,                         /* origNameLength */

          { 't', 'r', 'i', 'm', 'f' }, /* type */
          5.0,                         /* origTypeLength */

          { 0.0, 0.025, 0.05 },        /* params */
          3.0                          /* origParamLength */
        }, { { 'P', 'B' },             /* name */
          2.0,                         /* origNameLength */

          { 't', 'r', 'i', 'm', 'f' }, /* type */
          5.0,                         /* origTypeLength */

          { 0.025, 0.05, 0.05 },       /* params */
          3.0                          /* origParamLength */
        } },                           /* mf */
      5.0                              /* origNumMF */
    },                                 /* output */

    { { { 1.0, 1.0 },                  /* antecedent */
        5.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 1.0, 2.0 },               /* antecedent */
        5.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 1.0, 3.0 },               /* antecedent */
        4.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 1.0, 4.0 },               /* antecedent */
        4.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 1.0, 5.0 },               /* antecedent */
        3.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 2.0, 1.0 },               /* antecedent */
        5.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 2.0, 2.0 },               /* antecedent */
        4.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 2.0, 3.0 },               /* antecedent */
        4.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 2.0, 4.0 },               /* antecedent */
        3.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 2.0, 5.0 },               /* antecedent */
        2.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 3.0, 1.0 },               /* antecedent */
        4.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 3.0, 2.0 },               /* antecedent */
        4.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 3.0, 3.0 },               /* antecedent */
        3.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 3.0, 4.0 },               /* antecedent */
        2.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 3.0, 5.0 },               /* antecedent */
        2.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 4.0, 1.0 },               /* antecedent */
        4.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 4.0, 2.0 },               /* antecedent */
        3.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 4.0, 3.0 },               /* antecedent */
        2.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 4.0, 4.0 },               /* antecedent */
        2.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 4.0, 5.0 },               /* antecedent */
        1.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 5.0, 1.0 },               /* antecedent */
        3.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 5.0, 2.0 },               /* antecedent */
        2.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 5.0, 3.0 },               /* antecedent */
        2.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      }, { { 5.0, 4.0 },               /* antecedent */
        1.0,                           /* consequent */
        1.0,                           /* weight */
        1.0                            /* connection */
      } }                              /* rule */
  };

  c2_s4qsEqaDHXG669afyZjSQlH c2_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_fish;
  emlrtStack c2_b_st;
  emlrtStack c2_c_st;
  emlrtStack c2_d_st;
  emlrtStack c2_st = { NULL,           /* site */
    NULL,                              /* tls */
    NULL                               /* prev */
  };

  real_T c2_arg2[2];
  real_T c2_result_data[2];
  real_T c2_tmp_data[1];
  real_T c2_E;
  real_T c2_Vpv;
  real_T c2_ab_y;
  real_T c2_b;
  real_T c2_b_D;
  real_T c2_b_b;
  real_T c2_b_dV;
  real_T c2_b_minval;
  real_T c2_b_varargin_2;
  real_T c2_b_y;
  real_T c2_bb_y;
  real_T c2_c_b;
  real_T c2_c_minval;
  real_T c2_c_varargin_2;
  real_T c2_c_y;
  real_T c2_cb_y;
  real_T c2_dE;
  real_T c2_d_b;
  real_T c2_d_varargin_2;
  real_T c2_d_y;
  real_T c2_db_y;
  real_T c2_e_b;
  real_T c2_e_varargin_2;
  real_T c2_e_y;
  real_T c2_eb_y;
  real_T c2_f_b;
  real_T c2_f_varargin_2;
  real_T c2_f_y;
  real_T c2_g_y;
  real_T c2_h_y;
  real_T c2_i_y;
  real_T c2_j_y;
  real_T c2_k_y;
  real_T c2_l_y;
  real_T c2_m_y;
  real_T c2_minval;
  real_T c2_n_y;
  real_T c2_o_y;
  real_T c2_p_y;
  real_T c2_q_y;
  real_T c2_r_y;
  real_T c2_s_y;
  real_T c2_t_y;
  real_T c2_u_y;
  real_T c2_v_y;
  real_T c2_varargin_2;
  real_T c2_w_y;
  real_T c2_x_y;
  real_T c2_y;
  real_T c2_y_y;
  int32_T c2_result_size[2];
  int32_T c2_tmp_size[2];
  int32_T c2_i;
  int32_T c2_i1;
  c2_st.tls = chartInstance->c2_fEmlrtCtx;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_c_st.prev = &c2_b_st;
  c2_c_st.tls = c2_b_st.tls;
  c2_d_st.prev = &c2_c_st;
  c2_d_st.tls = c2_c_st.tls;
  chartInstance->c2_JITTransitionAnimation[0] = 0U;
  _sfTime_ = sf_get_time(chartInstance->S);
  covrtSigUpdateFcn(chartInstance->c2_covrtInstance, 1U, *chartInstance->c2_dV);
  covrtSigUpdateFcn(chartInstance->c2_covrtInstance, 0U, *chartInstance->c2_dP);
  chartInstance->c2_sfEvent = CALL_EVENT;
  c2_b_dV = *chartInstance->c2_dV;
  covrtEmlFcnEval(chartInstance->c2_covrtInstance, 4U, 0, 0);
  if (covrtEmlIfEval(chartInstance->c2_covrtInstance, 4U, 0, 0,
                     !chartInstance->c2_fis_obj_not_empty)) {
    chartInstance->c2_fis_obj = c2_r;
    chartInstance->c2_fis_obj_not_empty = true;
  }

  if (covrtEmlIfEval(chartInstance->c2_covrtInstance, 4U, 0, 1,
                     !chartInstance->c2_D_prev_not_empty)) {
    chartInstance->c2_D_prev = 0.5;
    chartInstance->c2_D_prev_not_empty = true;
  }

  if (covrtEmlIfEval(chartInstance->c2_covrtInstance, 4U, 0, 2,
                     !chartInstance->c2_E_prev_not_empty)) {
    chartInstance->c2_E_prev = 0.0;
    chartInstance->c2_E_prev_not_empty = true;
  }

  c2_Vpv = c2_b_dV;
  c2_E = (36.9 - c2_Vpv) / 36.9;
  c2_dE = c2_E - chartInstance->c2_E_prev;
  chartInstance->c2_E_prev = c2_E;
  c2_varargin_2 = c2_E;
  c2_y = c2_varargin_2;
  c2_b_y = c2_y;
  c2_c_y = c2_b_y;
  c2_b = c2_c_y;
  c2_d_y = c2_b;
  c2_e_y = c2_d_y;
  c2_minval = muDoubleScalarMin(1.0, c2_e_y);
  c2_b_varargin_2 = c2_minval;
  c2_f_y = c2_b_varargin_2;
  c2_g_y = c2_f_y;
  c2_h_y = c2_g_y;
  c2_b_b = c2_h_y;
  c2_i_y = c2_b_b;
  c2_j_y = c2_i_y;
  c2_E = muDoubleScalarMax(-1.0, c2_j_y);
  c2_c_varargin_2 = c2_dE;
  c2_k_y = c2_c_varargin_2;
  c2_l_y = c2_k_y;
  c2_m_y = c2_l_y;
  c2_c_b = c2_m_y;
  c2_n_y = c2_c_b;
  c2_o_y = c2_n_y;
  c2_b_minval = muDoubleScalarMin(1.0, c2_o_y);
  c2_d_varargin_2 = c2_b_minval;
  c2_p_y = c2_d_varargin_2;
  c2_q_y = c2_p_y;
  c2_r_y = c2_q_y;
  c2_d_b = c2_r_y;
  c2_s_y = c2_d_b;
  c2_t_y = c2_s_y;
  c2_dE = muDoubleScalarMax(-1.0, c2_t_y);
  c2_b_st.site = &c2_emlrtRSI;
  c2_arg2[0] = c2_E;
  c2_arg2[1] = c2_dE;
  c2_c_st.site = &c2_b_emlrtRSI;
  c2_fis = chartInstance->c2_fis_obj;
  c2_d_st.site = &c2_d_emlrtRSI;
  c2_packageAndSetDataType(chartInstance, &c2_d_st, &c2_fis, &c2_fish);
  c2_d_st.site = &c2_c_emlrtRSI;
  c2_evaluateFIS(chartInstance, &c2_d_st, c2_arg2, &c2_fish, c2_tmp_data,
                 c2_tmp_size);
  c2_result_size[0] = 1;
  c2_result_size[1] = 1;
  c2_result_data[0] = c2_tmp_data[0];
  c2_i = c2__s32_s64_(chartInstance, (int64_T)c2_result_size[0] * (int64_T)
                      c2_result_size[1], 0, 1U, 762, 9);
  c2_i1 = 1;
  if ((c2_i1 < 1) || (c2_i1 > c2_i)) {
    emlrtDynamicBoundsCheckR2012b(c2_i1, 1, c2_i, &c2_emlrtBCI, &c2_st);
  }

  c2_b_D = chartInstance->c2_D_prev + c2_result_data[c2_i1 - 1];
  c2_e_varargin_2 = c2_b_D;
  c2_u_y = c2_e_varargin_2;
  c2_v_y = c2_u_y;
  c2_w_y = c2_v_y;
  c2_e_b = c2_w_y;
  c2_x_y = c2_e_b;
  c2_y_y = c2_x_y;
  c2_c_minval = muDoubleScalarMin(0.9, c2_y_y);
  c2_f_varargin_2 = c2_c_minval;
  c2_ab_y = c2_f_varargin_2;
  c2_bb_y = c2_ab_y;
  c2_cb_y = c2_bb_y;
  c2_f_b = c2_cb_y;
  c2_db_y = c2_f_b;
  c2_eb_y = c2_db_y;
  c2_b_D = muDoubleScalarMax(0.1, c2_eb_y);
  chartInstance->c2_D_prev = c2_b_D;
  *chartInstance->c2_D = c2_b_D;
  c2_do_animation_call_c2_SimulinkSKRIPSIFIKS_FLC(chartInstance);
  covrtSigUpdateFcn(chartInstance->c2_covrtInstance, 2U, *chartInstance->c2_D);
}

static void mdl_start_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_terminate_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void mdl_setup_runtime_resources_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  static const uint32_T c2_decisionTxtEndIdx = 0U;
  static const uint32_T c2_decisionTxtStartIdx = 0U;
  setLegacyDebuggerFlag(chartInstance->S, false);
  setDebuggerFlag(chartInstance->S, true);
  setDataBrowseFcn(chartInstance->S, (void *)&c2_chart_data_browse_helper);
  chartInstance->c2_RuntimeVar = sfListenerCacheSimStruct(chartInstance->S);
  sfListenerInitializeRuntimeVars(chartInstance->c2_RuntimeVar,
    &chartInstance->c2_IsDebuggerActive,
    &chartInstance->c2_IsSequenceViewerPresent, 0, 0,
    &chartInstance->c2_mlFcnLineNumber, &chartInstance->c2_IsHeatMapPresent, 0);
  sim_mode_is_external(chartInstance->S);
  covrtCreateStateflowInstanceData(chartInstance->c2_covrtInstance, 1U, 0U, 1U,
    6U);
  covrtChartInitFcn(chartInstance->c2_covrtInstance, 0U, false, false, false);
  covrtStateInitFcn(chartInstance->c2_covrtInstance, 0U, 0U, false, false, false,
                    0U, &c2_decisionTxtStartIdx, &c2_decisionTxtEndIdx);
  covrtTransInitFcn(chartInstance->c2_covrtInstance, 0U, 0, NULL, NULL, 0U, NULL);
  covrtEmlInitFcn(chartInstance->c2_covrtInstance, "", 4U, 0U, 1U, 0U, 3U, 0U,
                  0U, 0U, 0U, 0U, 0U, 0U);
  covrtEmlFcnInitFcn(chartInstance->c2_covrtInstance, 4U, 0U, 0U,
                     "eML_blk_kernel", 0, -1, 821);
  covrtEmlIfInitFcn(chartInstance->c2_covrtInstance, 4U, 0U, 0U, 70, 89, -1, 145);
  covrtEmlIfInitFcn(chartInstance->c2_covrtInstance, 4U, 0U, 1U, 146, 164, -1,
                    186);
  covrtEmlIfInitFcn(chartInstance->c2_covrtInstance, 4U, 0U, 2U, 187, 205, -1,
                    225);
}

static void mdl_cleanup_runtime_resources_c2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  sfListenerLightTerminate(chartInstance->c2_RuntimeVar);
  covrtDeleteStateflowInstanceData(chartInstance->c2_covrtInstance);
}

static void initSimStructsc2_SimulinkSKRIPSIFIKS_FLC
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

const mxArray *sf_c2_SimulinkSKRIPSIFIKS_FLC_get_eml_resolved_functions_info
  (void)
{
  const mxArray *c2_nameCaptureInfo = NULL;
  c2_nameCaptureInfo = NULL;
  sf_mex_assign(&c2_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c2_nameCaptureInfo;
}

static void c2_packageAndSetDataType(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *
  chartInstance, const emlrtStack *c2_sp, c2_s4qsEqaDHXG669afyZjSQlH *c2_fis,
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_b_fis)
{
  static char_T c2_b[7] = { 'm', 'a', 'm', 'd', 'a', 'n', 'i' };

  c2_s5XYxtK6icIzLqFV4FdSKVC c2_in[2];
  c2_s5XYxtK6icIzLqFV4FdSKVC c2_b_in;
  c2_sEsqUUSxQBFGTGyl15EzrYH c2_rule[24];
  c2_s_GBys1jprGfE2uYETSBX2vH c2_c_fis;
  c2_s_JPdCXkmamKQZ91xcMYnAOD c2_r;
  c2_s_R1EPQmVtPqaprBGbq4jxhD c2_varStruct;
  c2_s_o4k2e0vdltB60WnSYJQFVC c2_b_mfStruct;
  c2_s_o4k2e0vdltB60WnSYJQFVC c2_mfStruct;
  emlrtStack c2_b_st;
  emlrtStack c2_c_st;
  emlrtStack c2_d_st;
  emlrtStack c2_st;
  const mxArray *c2_y = NULL;
  real_T c2_b_y[101];
  real_T c2_numInputMFs[2];
  real_T c2_x[2];
  real_T c2_b_maxMFParamLength;
  real_T c2_b_maxMFTypeLength;
  real_T c2_b_ruleID;
  real_T c2_c_varID;
  real_T c2_d_mfID;
  real_T c2_e_varID;
  real_T c2_f_mfID;
  real_T c2_f_ruleID;
  real_T c2_h_ruleID;
  real_T c2_i_ruleID;
  real_T c2_maxMFParamLength;
  real_T c2_maxMFTypeLength;
  real_T c2_maxNumMF;
  real_T c2_varargin_2;
  int32_T c2_tmp_data[101];
  int32_T c2_e_fis[2];
  int32_T c2_h_fis[2];
  int32_T c2_i_fis[2];
  int32_T c2_iv[2];
  int32_T c2_iv1[2];
  int32_T c2_j_fis[2];
  int32_T c2_n_fis[2];
  int32_T c2_o_fis[2];
  int32_T c2_outsize[2];
  int32_T c2_tile_size[2];
  int32_T c2_varargin_1_size[2];
  int32_T c2_b_b;
  int32_T c2_b_loop_ub;
  int32_T c2_b_mfID;
  int32_T c2_b_ret;
  int32_T c2_b_varID;
  int32_T c2_c_loop_ub;
  int32_T c2_c_mfID;
  int32_T c2_c_ruleID;
  int32_T c2_c_y;
  int32_T c2_d_fis;
  int32_T c2_d_loop_ub;
  int32_T c2_d_ruleID;
  int32_T c2_d_varID;
  int32_T c2_e_loop_ub;
  int32_T c2_e_mfID;
  int32_T c2_e_ruleID;
  int32_T c2_f_fis;
  int32_T c2_f_loop_ub;
  int32_T c2_f_varID;
  int32_T c2_g_fis;
  int32_T c2_g_loop_ub;
  int32_T c2_g_ruleID;
  int32_T c2_h_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i19;
  int32_T c2_i2;
  int32_T c2_i20;
  int32_T c2_i21;
  int32_T c2_i22;
  int32_T c2_i23;
  int32_T c2_i24;
  int32_T c2_i25;
  int32_T c2_i26;
  int32_T c2_i27;
  int32_T c2_i28;
  int32_T c2_i29;
  int32_T c2_i3;
  int32_T c2_i30;
  int32_T c2_i31;
  int32_T c2_i32;
  int32_T c2_i33;
  int32_T c2_i34;
  int32_T c2_i35;
  int32_T c2_i36;
  int32_T c2_i37;
  int32_T c2_i38;
  int32_T c2_i39;
  int32_T c2_i4;
  int32_T c2_i40;
  int32_T c2_i41;
  int32_T c2_i42;
  int32_T c2_i43;
  int32_T c2_i44;
  int32_T c2_i45;
  int32_T c2_i46;
  int32_T c2_i47;
  int32_T c2_i48;
  int32_T c2_i49;
  int32_T c2_i5;
  int32_T c2_i50;
  int32_T c2_i51;
  int32_T c2_i52;
  int32_T c2_i53;
  int32_T c2_i54;
  int32_T c2_i55;
  int32_T c2_i56;
  int32_T c2_i57;
  int32_T c2_i58;
  int32_T c2_i59;
  int32_T c2_i6;
  int32_T c2_i60;
  int32_T c2_i61;
  int32_T c2_i62;
  int32_T c2_i63;
  int32_T c2_i64;
  int32_T c2_i65;
  int32_T c2_i66;
  int32_T c2_i67;
  int32_T c2_i68;
  int32_T c2_i69;
  int32_T c2_i7;
  int32_T c2_i70;
  int32_T c2_i71;
  int32_T c2_i72;
  int32_T c2_i73;
  int32_T c2_i74;
  int32_T c2_i75;
  int32_T c2_i76;
  int32_T c2_i77;
  int32_T c2_i78;
  int32_T c2_i79;
  int32_T c2_i8;
  int32_T c2_i80;
  int32_T c2_i81;
  int32_T c2_i82;
  int32_T c2_i83;
  int32_T c2_i84;
  int32_T c2_i85;
  int32_T c2_i86;
  int32_T c2_i87;
  int32_T c2_i88;
  int32_T c2_i89;
  int32_T c2_i9;
  int32_T c2_i90;
  int32_T c2_i91;
  int32_T c2_i92;
  int32_T c2_i93;
  int32_T c2_i94;
  int32_T c2_i95;
  int32_T c2_i96;
  int32_T c2_i97;
  int32_T c2_i98;
  int32_T c2_i99;
  int32_T c2_i_loop_ub;
  int32_T c2_k;
  int32_T c2_k_fis;
  int32_T c2_l_fis;
  int32_T c2_loop_ub;
  int32_T c2_m_fis;
  int32_T c2_mfID;
  int32_T c2_ret;
  int32_T c2_ruleID;
  int32_T c2_varID;
  char_T c2_a[7];
  boolean_T c2_b_bool;
  boolean_T c2_bool;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_c_st.prev = &c2_b_st;
  c2_c_st.tls = c2_b_st.tls;
  c2_d_st.prev = &c2_c_st;
  c2_d_st.tls = c2_c_st.tls;
  c2_st.site = &c2_e_emlrtRSI;
  for (c2_i = 0; c2_i < 7; c2_i++) {
    c2_c_fis.type[c2_i] = c2_fis->type[c2_i];
  }

  for (c2_i1 = 0; c2_i1 < 3; c2_i1++) {
    c2_c_fis.andMethod[c2_i1] = c2_fis->andMethod[c2_i1];
  }

  for (c2_i2 = 0; c2_i2 < 3; c2_i2++) {
    c2_c_fis.orMethod[c2_i2] = c2_fis->orMethod[c2_i2];
  }

  for (c2_i3 = 0; c2_i3 < 8; c2_i3++) {
    c2_c_fis.defuzzMethod[c2_i3] = c2_fis->defuzzMethod[c2_i3];
  }

  for (c2_i4 = 0; c2_i4 < 3; c2_i4++) {
    c2_c_fis.impMethod[c2_i4] = c2_fis->impMethod[c2_i4];
  }

  for (c2_i5 = 0; c2_i5 < 3; c2_i5++) {
    c2_c_fis.aggMethod[c2_i5] = c2_fis->aggMethod[c2_i5];
  }

  c2_b_st.site = &c2_g_emlrtRSI;
  for (c2_i6 = 0; c2_i6 < 2; c2_i6++) {
    c2_in[c2_i6] = c2_fis->input[c2_i6];
  }

  c2_mfStruct.type.size[0] = 1;
  c2_mfStruct.type.size[1] = 1;
  c2_mfStruct.type.data[0] = '\x00';
  c2_mfStruct.origTypeLength = 0.0;
  c2_mfStruct.params.size[0] = 1;
  c2_mfStruct.params.size[1] = 1;
  c2_mfStruct.params.data[0] = 0.0;
  c2_mfStruct.origParamLength = 0.0;
  c2_r.mf = c2_mfStruct;
  c2_varStruct.mf.size[0] = 1;
  c2_varStruct.mf.size[1] = 1;
  c2_varStruct.mf.data[0] = c2_r.mf;
  c2_varStruct.origNumMF = 0.0;
  for (c2_i7 = 0; c2_i7 < 2; c2_i7++) {
    c2_c_fis.inputMF[c2_i7] = c2_varStruct;
  }

  c2_maxNumMF = 0.0;
  c2_maxMFTypeLength = 0.0;
  c2_maxMFParamLength = 0.0;
  for (c2_varID = 0; c2_varID < 2; c2_varID++) {
    if (c2_maxNumMF < 5.0) {
      c2_maxNumMF = 5.0;
    }

    for (c2_mfID = 0; c2_mfID < 5; c2_mfID++) {
      if (c2_maxMFTypeLength < 5.0) {
        c2_maxMFTypeLength = 5.0;
      }

      if (c2_maxMFParamLength < 3.0) {
        c2_maxMFParamLength = 3.0;
      }
    }
  }

  for (c2_b_varID = 0; c2_b_varID < 2; c2_b_varID++) {
    c2_c_varID = (real_T)c2_b_varID + 1.0;
    c2_c_fis.inputMF[(int32_T)c2_c_varID - 1].origNumMF = 5.0;
    c2_c_st.site = &c2_j_emlrtRSI;
    c2_varargin_2 = c2_maxNumMF;
    c2_d_st.site = &c2_k_emlrtRSI;
    c2_assertValidSizeArg(chartInstance, &c2_d_st, c2_varargin_2);
    c2_tile_size[1] = (int32_T)c2_varargin_2;
    c2_outsize[1] = c2_tile_size[1];
    if (!((real_T)c2_outsize[1] == (real_T)c2_tile_size[1])) {
      c2_y = NULL;
      sf_mex_assign(&c2_y, sf_mex_create("y", c2_cv, 10, 0U, 1U, 0U, 2, 1, 15),
                    false);
      sf_mex_call(&c2_c_st, &c2_emlrtMCI, "error", 0U, 1U, 14, c2_y);
    }

    c2_c_fis.inputMF[(int32_T)c2_c_varID - 1].mf.size[0] = 1;
    c2_c_fis.inputMF[(int32_T)c2_c_varID - 1].mf.size[1] = c2_outsize[1];
    c2_loop_ub = c2_outsize[1] - 1;
    for (c2_i8 = 0; c2_i8 <= c2_loop_ub; c2_i8++) {
      c2_c_fis.inputMF[(int32_T)c2_c_varID - 1].mf.data[c2_i8] = c2_mfStruct;
    }

    c2_i9 = (int32_T)c2_maxNumMF - 1;
    for (c2_c_mfID = 0; c2_c_mfID <= c2_i9; c2_c_mfID++) {
      c2_d_mfID = (real_T)c2_c_mfID + 1.0;
      c2_i11 = (int32_T)c2_c_varID - 1;
      c2_varargin_1_size[0] = 1;
      c2_varargin_1_size[1] = (int32_T)c2_maxMFTypeLength;
      for (c2_i12 = 0; c2_i12 < 2; c2_i12++) {
        c2_numInputMFs[c2_i12] = (real_T)c2_varargin_1_size[c2_i12];
      }

      c2_d_fis = c2_c_fis.inputMF[c2_i11].mf.size[1];
      c2_i14 = (int32_T)c2_d_mfID;
      if (c2_i14 > c2_d_fis) {
        emlrtDynamicBoundsCheckR2012b(c2_i14, 1, c2_d_fis, &c2_f_emlrtBCI,
          &c2_b_st);
      }

      c2_i17 = c2_i14 - 1;
      c2_c_fis.inputMF[c2_i11].mf.data[c2_i17].type.size[0] = 1;
      c2_i21 = (int32_T)c2_d_mfID;
      if (c2_i21 > c2_d_fis) {
        emlrtDynamicBoundsCheckR2012b(c2_i21, 1, c2_d_fis, &c2_f_emlrtBCI,
          &c2_b_st);
      }

      c2_i22 = c2_i21 - 1;
      c2_c_fis.inputMF[c2_i11].mf.data[c2_i22].type.size[1] = (int32_T)
        c2_numInputMFs[1];
      c2_f_fis = c2_c_fis.inputMF[c2_i11].mf.size[1];
      for (c2_i26 = 0; c2_i26 < 2; c2_i26++) {
        c2_i27 = (int32_T)c2_d_mfID;
        if (c2_i27 > c2_f_fis) {
          emlrtDynamicBoundsCheckR2012b(c2_i27, 1, c2_f_fis, &c2_k_emlrtBCI,
            &c2_b_st);
        }

        c2_h_fis[c2_i26] = c2_c_fis.inputMF[c2_i11].mf.data[c2_i27 - 1].
          type.size[c2_i26];
      }

      c2_g_fis = c2_c_fis.inputMF[c2_i11].mf.size[1];
      c2_i28 = (int32_T)c2_d_mfID;
      if (c2_i28 > c2_g_fis) {
        emlrtDynamicBoundsCheckR2012b(c2_i28, 1, c2_g_fis, &c2_e_emlrtBCI,
          &c2_b_st);
      }

      c2_i30 = c2_i28 - 1;
      c2_c_fis.inputMF[c2_i11].mf.data[c2_i30].type.size[0] = 1;
      c2_i32 = (int32_T)c2_d_mfID;
      if (c2_i32 > c2_g_fis) {
        emlrtDynamicBoundsCheckR2012b(c2_i32, 1, c2_g_fis, &c2_e_emlrtBCI,
          &c2_b_st);
      }

      c2_i35 = c2_i32 - 1;
      c2_c_fis.inputMF[c2_i11].mf.data[c2_i35].type.size[1] = c2_h_fis[1];
      c2_i38 = (int32_T)c2_d_mfID;
      if (c2_i38 > c2_g_fis) {
        emlrtDynamicBoundsCheckR2012b(c2_i38, 1, c2_g_fis, &c2_e_emlrtBCI,
          &c2_b_st);
      }

      c2_i40 = (int32_T)c2_d_mfID;
      if (c2_i40 > c2_g_fis) {
        emlrtDynamicBoundsCheckR2012b(c2_i40, 1, c2_g_fis, &c2_e_emlrtBCI,
          &c2_b_st);
      }

      c2_e_loop_ub = c2_h_fis[0] * c2_h_fis[1] - 1;
      for (c2_i44 = 0; c2_i44 <= c2_e_loop_ub; c2_i44++) {
        c2_i47 = (int32_T)c2_d_mfID;
        if (c2_i47 > c2_g_fis) {
          emlrtDynamicBoundsCheckR2012b(c2_i47, 1, c2_g_fis, &c2_k_emlrtBCI,
            &c2_b_st);
        }

        c2_c_fis.inputMF[c2_i11].mf.data[c2_i47 - 1].type.data[c2_i44] = '\x00';
      }

      c2_i46 = (int32_T)c2_c_varID - 1;
      c2_i48 = (int32_T)c2_maxMFParamLength;
      c2_i50 = c2_c_fis.inputMF[c2_i46].mf.size[1];
      c2_i51 = (int32_T)c2_d_mfID;
      if (c2_i51 > c2_i50) {
        emlrtDynamicBoundsCheckR2012b(c2_i51, 1, c2_i50, &c2_d_emlrtBCI,
          &c2_b_st);
      }

      c2_i53 = c2_i51 - 1;
      c2_c_fis.inputMF[c2_i46].mf.data[c2_i53].params.size[0] = 1;
      c2_i57 = c2_c_fis.inputMF[c2_i46].mf.size[1];
      c2_i59 = (int32_T)c2_d_mfID;
      if (c2_i59 > c2_i57) {
        emlrtDynamicBoundsCheckR2012b(c2_i59, 1, c2_i57, &c2_d_emlrtBCI,
          &c2_b_st);
      }

      c2_i63 = c2_i59 - 1;
      c2_c_fis.inputMF[c2_i46].mf.data[c2_i63].params.size[1] = (int32_T)
        c2_maxMFParamLength;
      c2_k_fis = c2_c_fis.inputMF[c2_i46].mf.size[1];
      c2_l_fis = c2_c_fis.inputMF[c2_i46].mf.size[1];
      c2_i66 = (int32_T)c2_d_mfID;
      if (c2_i66 > c2_l_fis) {
        emlrtDynamicBoundsCheckR2012b(c2_i66, 1, c2_l_fis, &c2_d_emlrtBCI,
          &c2_b_st);
      }

      c2_m_fis = c2_c_fis.inputMF[c2_i46].mf.size[1];
      c2_i70 = (int32_T)c2_d_mfID;
      if (c2_i70 > c2_m_fis) {
        emlrtDynamicBoundsCheckR2012b(c2_i70, 1, c2_m_fis, &c2_d_emlrtBCI,
          &c2_b_st);
      }

      c2_g_loop_ub = c2_i48 - 1;
      for (c2_i72 = 0; c2_i72 <= c2_g_loop_ub; c2_i72++) {
        c2_i74 = (int32_T)c2_d_mfID;
        if (c2_i74 > c2_k_fis) {
          emlrtDynamicBoundsCheckR2012b(c2_i74, 1, c2_k_fis, &c2_l_emlrtBCI,
            &c2_b_st);
        }

        c2_c_fis.inputMF[c2_i46].mf.data[c2_i74 - 1].params.data[c2_i72] = 0.0;
      }

      c2_i73 = (int32_T)c2_c_varID - 1;
      c2_i75 = c2_c_fis.inputMF[c2_i73].mf.size[1];
      c2_i76 = (int32_T)c2_d_mfID;
      if (c2_i76 > c2_i75) {
        emlrtDynamicBoundsCheckR2012b(c2_i76, 1, c2_i75, &c2_g_emlrtBCI,
          &c2_b_st);
      }

      c2_c_fis.inputMF[c2_i73].mf.data[c2_i76 - 1].origTypeLength = 0.0;
      c2_i77 = (int32_T)c2_c_varID - 1;
      c2_i78 = c2_c_fis.inputMF[c2_i77].mf.size[1];
      c2_i79 = (int32_T)c2_d_mfID;
      if (c2_i79 > c2_i78) {
        emlrtDynamicBoundsCheckR2012b(c2_i79, 1, c2_i78, &c2_h_emlrtBCI,
          &c2_b_st);
      }

      c2_c_fis.inputMF[c2_i77].mf.data[c2_i79 - 1].origParamLength = 0.0;
      if (c2_d_mfID <= c2_c_fis.inputMF[(int32_T)c2_c_varID - 1].origNumMF) {
        c2_i80 = (int32_T)c2_c_varID - 1;
        c2_i81 = c2_c_fis.inputMF[c2_i80].mf.size[1];
        c2_i82 = (int32_T)c2_d_mfID;
        if (c2_i82 > c2_i81) {
          emlrtDynamicBoundsCheckR2012b(c2_i82, 1, c2_i81, &c2_b_emlrtBCI,
            &c2_b_st);
        }

        c2_i83 = c2_i82 - 1;
        c2_i84 = c2_c_fis.inputMF[c2_i80].mf.data[c2_i83].type.size[1];
        if (c2_i84 != 5) {
          emlrtSubAssignSizeCheck1dR2017a(c2_i84, 5, &c2_emlrtECI, &c2_b_st);
        }

        for (c2_i85 = 0; c2_i85 < 2; c2_i85++) {
          c2_n_fis[c2_i85] = c2_c_fis.inputMF[c2_i80].mf.data[c2_i83]
            .type.size[c2_i85];
        }

        c2_c_fis.inputMF[c2_i80].mf.data[c2_i83].type.size[0] = 1;
        c2_c_fis.inputMF[c2_i80].mf.data[c2_i83].type.size[1] = c2_n_fis[1];
        c2_h_loop_ub = c2_n_fis[0] * c2_n_fis[1] - 1;
        for (c2_i86 = 0; c2_i86 <= c2_h_loop_ub; c2_i86++) {
          c2_c_fis.inputMF[c2_i80].mf.data[c2_i83].type.data[c2_i86] = c2_in
            [(int32_T)c2_c_varID - 1].mf[(int32_T)c2_d_mfID - 1].type[c2_i86];
        }

        c2_i87 = (int32_T)c2_c_varID - 1;
        c2_i88 = c2_c_fis.inputMF[c2_i87].mf.size[1];
        c2_i89 = (int32_T)c2_d_mfID;
        if (c2_i89 > c2_i88) {
          emlrtDynamicBoundsCheckR2012b(c2_i89, 1, c2_i88, &c2_i_emlrtBCI,
            &c2_b_st);
        }

        c2_c_fis.inputMF[c2_i87].mf.data[c2_i89 - 1].origTypeLength = 5.0;
        c2_i90 = (int32_T)c2_c_varID - 1;
        c2_i91 = c2_c_fis.inputMF[c2_i90].mf.size[1];
        c2_i92 = (int32_T)c2_d_mfID;
        if (c2_i92 > c2_i91) {
          emlrtDynamicBoundsCheckR2012b(c2_i92, 1, c2_i91, &c2_c_emlrtBCI,
            &c2_b_st);
        }

        c2_i93 = c2_i92 - 1;
        c2_i94 = c2_c_fis.inputMF[c2_i90].mf.data[c2_i93].params.size[1];
        if (c2_i94 != 3) {
          emlrtSubAssignSizeCheck1dR2017a(c2_i94, 3, &c2_b_emlrtECI, &c2_b_st);
        }

        for (c2_i95 = 0; c2_i95 < 2; c2_i95++) {
          c2_o_fis[c2_i95] = c2_c_fis.inputMF[c2_i90].mf.data[c2_i93].
            params.size[c2_i95];
        }

        c2_c_fis.inputMF[c2_i90].mf.data[c2_i93].params.size[0] = 1;
        c2_c_fis.inputMF[c2_i90].mf.data[c2_i93].params.size[1] = c2_o_fis[1];
        c2_i_loop_ub = c2_o_fis[0] * c2_o_fis[1] - 1;
        for (c2_i96 = 0; c2_i96 <= c2_i_loop_ub; c2_i96++) {
          c2_c_fis.inputMF[c2_i90].mf.data[c2_i93].params.data[c2_i96] = c2_in
            [(int32_T)c2_c_varID - 1].mf[(int32_T)c2_d_mfID - 1].params[c2_i96];
        }

        c2_i97 = (int32_T)c2_c_varID - 1;
        c2_i98 = c2_c_fis.inputMF[c2_i97].mf.size[1];
        c2_i99 = (int32_T)c2_d_mfID;
        if (c2_i99 > c2_i98) {
          emlrtDynamicBoundsCheckR2012b(c2_i99, 1, c2_i98, &c2_j_emlrtBCI,
            &c2_b_st);
        }

        c2_c_fis.inputMF[c2_i97].mf.data[c2_i99 - 1].origParamLength = 3.0;
      }
    }
  }

  c2_b_st.site = &c2_h_emlrtRSI;
  c2_b_in = c2_fis->output;
  c2_b_mfStruct.type.size[0] = 1;
  c2_b_mfStruct.type.size[1] = 1;
  c2_b_mfStruct.type.data[0] = '\x00';
  c2_b_mfStruct.origTypeLength = 0.0;
  c2_b_mfStruct.params.size[0] = 1;
  c2_b_mfStruct.params.size[1] = 1;
  c2_b_mfStruct.params.data[0] = 0.0;
  c2_b_mfStruct.origParamLength = 0.0;
  c2_b_maxMFTypeLength = 0.0;
  c2_b_maxMFParamLength = 0.0;
  for (c2_b_mfID = 0; c2_b_mfID < 5; c2_b_mfID++) {
    if (c2_b_maxMFTypeLength < 5.0) {
      c2_b_maxMFTypeLength = 5.0;
    }

    if (c2_b_maxMFParamLength < 3.0) {
      c2_b_maxMFParamLength = 3.0;
    }
  }

  c2_c_fis.outputMF.origNumMF = 5.0;
  c2_c_st.site = &c2_j_emlrtRSI;
  c2_d_st.site = &c2_k_emlrtRSI;
  c2_assertValidSizeArg(chartInstance, &c2_d_st, 5.0);
  c2_c_fis.outputMF.mf.size[0] = 1;
  c2_c_fis.outputMF.mf.size[1] = 5;
  for (c2_i10 = 0; c2_i10 < 5; c2_i10++) {
    c2_c_fis.outputMF.mf.data[c2_i10] = c2_b_mfStruct;
  }

  for (c2_e_mfID = 0; c2_e_mfID < 5; c2_e_mfID++) {
    c2_f_mfID = (real_T)c2_e_mfID + 1.0;
    c2_varargin_1_size[0] = 1;
    c2_varargin_1_size[1] = (int32_T)c2_b_maxMFTypeLength;
    for (c2_i15 = 0; c2_i15 < 2; c2_i15++) {
      c2_numInputMFs[c2_i15] = (real_T)c2_varargin_1_size[c2_i15];
    }

    c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].type.size[0] = 1;
    c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].type.size[1] = (int32_T)
      c2_numInputMFs[1];
    for (c2_i20 = 0; c2_i20 < 2; c2_i20++) {
      c2_e_fis[c2_i20] = c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].
        type.size[c2_i20];
    }

    c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].type.size[0] = 1;
    c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].type.size[1] = c2_e_fis[1];
    c2_b_loop_ub = c2_e_fis[0] * c2_e_fis[1] - 1;
    for (c2_i24 = 0; c2_i24 <= c2_b_loop_ub; c2_i24++) {
      c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].type.data[c2_i24] =
        '\x00';
    }

    c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].params.size[0] = 1;
    c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].params.size[1] = (int32_T)
      c2_b_maxMFParamLength;
    c2_c_loop_ub = (int32_T)c2_b_maxMFParamLength - 1;
    for (c2_i29 = 0; c2_i29 <= c2_c_loop_ub; c2_i29++) {
      c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].params.data[c2_i29] =
        0.0;
    }

    c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].origTypeLength = 0.0;
    c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].origParamLength = 0.0;
    c2_i31 = (int32_T)c2_f_mfID - 1;
    c2_i33 = c2_c_fis.outputMF.mf.data[c2_i31].type.size[1];
    if (c2_i33 != 5) {
      emlrtSubAssignSizeCheck1dR2017a(c2_i33, 5, &c2_emlrtECI, &c2_b_st);
    }

    for (c2_i37 = 0; c2_i37 < 2; c2_i37++) {
      c2_i_fis[c2_i37] = c2_c_fis.outputMF.mf.data[c2_i31].type.size[c2_i37];
    }

    c2_c_fis.outputMF.mf.data[c2_i31].type.size[0] = 1;
    c2_c_fis.outputMF.mf.data[c2_i31].type.size[1] = c2_i_fis[1];
    c2_d_loop_ub = c2_i_fis[0] * c2_i_fis[1] - 1;
    for (c2_i41 = 0; c2_i41 <= c2_d_loop_ub; c2_i41++) {
      c2_c_fis.outputMF.mf.data[c2_i31].type.data[c2_i41] = c2_b_in.mf[(int32_T)
        c2_f_mfID - 1].type[c2_i41];
    }

    c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].origTypeLength = 5.0;
    c2_i43 = (int32_T)c2_f_mfID - 1;
    c2_i45 = c2_c_fis.outputMF.mf.data[c2_i43].params.size[1];
    if (c2_i45 != 3) {
      emlrtSubAssignSizeCheck1dR2017a(c2_i45, 3, &c2_b_emlrtECI, &c2_b_st);
    }

    for (c2_i49 = 0; c2_i49 < 2; c2_i49++) {
      c2_j_fis[c2_i49] = c2_c_fis.outputMF.mf.data[c2_i43].params.size[c2_i49];
    }

    c2_c_fis.outputMF.mf.data[c2_i43].params.size[0] = 1;
    c2_c_fis.outputMF.mf.data[c2_i43].params.size[1] = c2_j_fis[1];
    c2_f_loop_ub = c2_j_fis[0] * c2_j_fis[1] - 1;
    for (c2_i56 = 0; c2_i56 <= c2_f_loop_ub; c2_i56++) {
      c2_c_fis.outputMF.mf.data[c2_i43].params.data[c2_i56] = c2_b_in.mf
        [(int32_T)c2_f_mfID - 1].params[c2_i56];
    }

    c2_c_fis.outputMF.mf.data[(int32_T)c2_f_mfID - 1].origParamLength = 3.0;
  }

  for (c2_i13 = 0; c2_i13 < 2; c2_i13++) {
    c2_in[c2_i13] = c2_fis->input[c2_i13];
  }

  for (c2_d_varID = 0; c2_d_varID < 2; c2_d_varID++) {
    c2_e_varID = (real_T)c2_d_varID + 1.0;
    c2_f_varID = (int32_T)c2_e_varID - 1;
    for (c2_i18 = 0; c2_i18 < 2; c2_i18++) {
      c2_c_fis.inputRange[c2_f_varID + (c2_i18 << 1)] = c2_in[(int32_T)
        c2_e_varID - 1].range[c2_i18];
    }
  }

  c2_b_in = c2_fis->output;
  for (c2_i16 = 0; c2_i16 < 2; c2_i16++) {
    c2_c_fis.outputRange[c2_i16] = c2_b_in.range[c2_i16];
  }

  for (c2_i19 = 0; c2_i19 < 24; c2_i19++) {
    c2_rule[c2_i19] = c2_fis->rule[c2_i19];
  }

  for (c2_ruleID = 0; c2_ruleID < 24; c2_ruleID++) {
    c2_b_ruleID = (real_T)c2_ruleID + 1.0;
    c2_c_ruleID = (int32_T)c2_b_ruleID - 1;
    for (c2_i25 = 0; c2_i25 < 2; c2_i25++) {
      c2_c_fis.antecedent[c2_c_ruleID + 24 * c2_i25] = c2_rule[(int32_T)
        c2_b_ruleID - 1].antecedent[c2_i25];
    }
  }

  for (c2_i23 = 0; c2_i23 < 24; c2_i23++) {
    c2_rule[c2_i23] = c2_fis->rule[c2_i23];
  }

  for (c2_d_ruleID = 0; c2_d_ruleID < 24; c2_d_ruleID++) {
    c2_f_ruleID = (real_T)c2_d_ruleID + 1.0;
    c2_c_fis.consequent[(int32_T)c2_f_ruleID - 1] = c2_rule[(int32_T)c2_f_ruleID
      - 1].consequent;
  }

  for (c2_e_ruleID = 0; c2_e_ruleID < 24; c2_e_ruleID++) {
    c2_h_ruleID = (real_T)c2_e_ruleID + 1.0;
    c2_c_fis.connection[(int32_T)c2_h_ruleID - 1] = 1.0;
  }

  for (c2_g_ruleID = 0; c2_g_ruleID < 24; c2_g_ruleID++) {
    c2_i_ruleID = (real_T)c2_g_ruleID + 1.0;
    c2_c_fis.weight[(int32_T)c2_i_ruleID - 1] = 1.0;
  }

  c2_c_fis.numSamples = 101.0;
  c2_c_fis.numInputs = 2.0;
  c2_c_fis.numOutputs = 1.0;
  c2_c_fis.numRules = 24.0;
  for (c2_i34 = 0; c2_i34 < 2; c2_i34++) {
    c2_c_fis.numInputMFs[c2_i34] = 5.0;
  }

  for (c2_i36 = 0; c2_i36 < 2; c2_i36++) {
    c2_x[c2_i36] = 5.0;
  }

  c2_x[1] = 10.0;
  for (c2_i39 = 0; c2_i39 < 2; c2_i39++) {
    c2_c_fis.numCumInputMFs[c2_i39] = c2_x[c2_i39] - 5.0;
  }

  c2_c_fis.numOutputMFs = 5.0;
  c2_c_fis.numCumOutputMFs = 0.0;
  c2_b_st.site = &c2_i_emlrtRSI;
  for (c2_i42 = 0; c2_i42 < 7; c2_i42++) {
    c2_a[c2_i42] = c2_fis->type[c2_i42];
  }

  c2_ret = memcmp(&c2_a[0], &c2_b[0], 7);
  c2_bool = (c2_ret == 0);
  if (c2_bool) {
    c2_c_fis.outputSamplePoints.size[0] = 1;
    c2_c_fis.outputSamplePoints.size[1] = 101;
    for (c2_i52 = 0; c2_i52 < 101; c2_i52++) {
      c2_c_fis.outputSamplePoints.data[c2_i52] = 0.0;
    }

    for (c2_i55 = 0; c2_i55 < 101; c2_i55++) {
      c2_tmp_data[c2_i55] = c2_i55;
    }

    for (c2_i58 = 0; c2_i58 < 2; c2_i58++) {
      c2_iv[c2_i58] = 100 * c2_i58 + 1;
    }

    for (c2_i60 = 0; c2_i60 < 2; c2_i60++) {
      c2_iv1[c2_i60] = 100 * c2_i60 + 1;
    }

    emlrtSubAssignSizeCheckR2012b(&c2_iv[0], 2, &c2_iv1[0], 2, &c2_c_emlrtECI,
      &c2_b_st);
    c2_b_y[100] = 0.05;
    c2_b_y[0] = -0.05;
    for (c2_k = 0; c2_k < 99; c2_k++) {
      c2_b_b = c2_k + 2;
      c2_c_y = (c2_b_b << 1) - 102;
      c2_b_y[c2_k + 1] = (real_T)c2_c_y * 0.0005;
    }

    c2_b_y[50] = 0.0;
    for (c2_i69 = 0; c2_i69 < 101; c2_i69++) {
      c2_c_fis.outputSamplePoints.data[c2_tmp_data[c2_i69]] = c2_b_y[c2_i69];
    }
  } else {
    c2_c_fis.outputSamplePoints.size[0] = 1;
    c2_c_fis.outputSamplePoints.size[1] = 1;
    c2_c_fis.outputSamplePoints.data[0] = 0.0;
  }

  for (c2_i54 = 0; c2_i54 < 7; c2_i54++) {
    c2_a[c2_i54] = c2_fis->type[c2_i54];
  }

  c2_b_ret = memcmp(&c2_a[0], &c2_b[0], 7);
  c2_b_bool = (c2_b_ret == 0);
  if (c2_b_bool) {
    for (c2_i62 = 0; c2_i62 < 2; c2_i62++) {
      c2_c_fis.orrSize[c2_i62] = -77.0 * (real_T)c2_i62 + 101.0;
    }

    for (c2_i65 = 0; c2_i65 < 2; c2_i65++) {
      c2_c_fis.aggSize[c2_i65] = -100.0 * (real_T)c2_i65 + 101.0;
    }
  } else {
    for (c2_i61 = 0; c2_i61 < 2; c2_i61++) {
      c2_c_fis.orrSize[c2_i61] = -23.0 * (real_T)c2_i61 + 24.0;
    }

    for (c2_i64 = 0; c2_i64 < 2; c2_i64++) {
      c2_c_fis.aggSize[c2_i64] = 1.0;
    }
  }

  for (c2_i67 = 0; c2_i67 < 2; c2_i67++) {
    c2_c_fis.irrSize[c2_i67] = -22.0 * (real_T)c2_i67 + 24.0;
  }

  for (c2_i68 = 0; c2_i68 < 2; c2_i68++) {
    c2_c_fis.rfsSize[c2_i68] = -23.0 * (real_T)c2_i68 + 24.0;
  }

  for (c2_i71 = 0; c2_i71 < 2; c2_i71++) {
    c2_c_fis.sumSize[c2_i71] = 1.0;
  }

  c2_c_fis.inputFuzzySetType = 1.0;
  c2_st.site = &c2_f_emlrtRSI;
  c2_setDataType(chartInstance, &c2_st, &c2_c_fis, c2_b_fis);
}

static void c2_assertValidSizeArg(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_varargin_2)
{
  static char_T c2_b_cv[28] = { 'C', 'o', 'd', 'e', 'r', ':', 'M', 'A', 'T', 'L',
    'A', 'B', ':', 'N', 'o', 'n', 'I', 'n', 't', 'e', 'g', 'e', 'r', 'I', 'n',
    'p', 'u', 't' };

  const mxArray *c2_b_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_y = NULL;
  real_T c2_arg;
  int32_T c2_b_u;
  int32_T c2_u;
  boolean_T c2_b;
  boolean_T c2_p;
  (void)chartInstance;
  c2_arg = c2_varargin_2;
  if (c2_arg != c2_arg) {
    c2_p = false;
  } else {
    c2_p = true;
  }

  if (c2_p) {
    c2_b = true;
  } else {
    c2_b = false;
  }

  if (!c2_b) {
    c2_y = NULL;
    sf_mex_assign(&c2_y, sf_mex_create("y", c2_b_cv, 10, 0U, 1U, 0U, 2, 1, 28),
                  false);
    c2_b_y = NULL;
    sf_mex_assign(&c2_b_y, sf_mex_create("y", c2_b_cv, 10, 0U, 1U, 0U, 2, 1, 28),
                  false);
    c2_u = MIN_int32_T;
    c2_c_y = NULL;
    sf_mex_assign(&c2_c_y, sf_mex_create("y", &c2_u, 6, 0U, 0U, 0U, 0), false);
    c2_b_u = MAX_int32_T;
    c2_d_y = NULL;
    sf_mex_assign(&c2_d_y, sf_mex_create("y", &c2_b_u, 6, 0U, 0U, 0U, 0), false);
    sf_mex_call(c2_sp, &c2_b_emlrtMCI, "error", 0U, 2U, 14, c2_y, 14,
                sf_mex_call(c2_sp, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (c2_sp, NULL, "message", 1U, 3U, 14, c2_b_y, 14, c2_c_y, 14, c2_d_y)));
  }
}

static boolean_T c2_strcmp(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, char_T c2_a[7])
{
  static char_T c2_b[7] = { 'm', 'a', 'm', 'd', 'a', 'n', 'i' };

  int32_T c2_ret;
  (void)chartInstance;
  c2_ret = memcmp(&c2_a[0], &c2_b[0], 7);
  return c2_ret == 0;
}

static void c2_setDataType(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_s_GBys1jprGfE2uYETSBX2vH *c2_fisin,
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fisout)
{
  c2_emxArray_s_o4k2e0vdltB60WnSYJQF c2_r;
  c2_s_64TxJFgCtXBlX73DcwNLAB c2_b_varStruct;
  c2_s_64TxJFgCtXBlX73DcwNLAB c2_varStruct;
  c2_s_8hQCdWJdSJhbjCfdgdfm1F c2_c_mfStruct;
  c2_s_8hQCdWJdSJhbjCfdgdfm1F c2_mfStruct;
  c2_s_R1EPQmVtPqaprBGbq4jxhD c2_in[2];
  c2_s_R1EPQmVtPqaprBGbq4jxhD c2_b_in;
  emlrtStack c2_b_st;
  emlrtStack c2_c_st;
  emlrtStack c2_st;
  const mxArray *c2_y = NULL;
  real_T c2_b_tmp_data[3];
  real_T c2_dv[2];
  real_T c2_b_mfID;
  real_T c2_b_mfParamLength;
  real_T c2_b_mfTypeLength;
  real_T c2_b_varID;
  real_T c2_c_varargin_2;
  real_T c2_d;
  real_T c2_d1;
  real_T c2_d10;
  real_T c2_d11;
  real_T c2_d2;
  real_T c2_d3;
  real_T c2_d4;
  real_T c2_d5;
  real_T c2_d6;
  real_T c2_d7;
  real_T c2_d8;
  real_T c2_d9;
  real_T c2_d_mfID;
  real_T c2_mfParamLength;
  real_T c2_mfTypeLength;
  real_T c2_numMF;
  int32_T c2_b_mfStruct[2];
  int32_T c2_b_tmp_size[2];
  int32_T c2_d_mfStruct[2];
  int32_T c2_outsize[2];
  int32_T c2_tile_size[2];
  int32_T c2_tmp_size[2];
  int32_T c2_varargin_1_size[2];
  int32_T c2_b_loop_ub;
  int32_T c2_b_varargin_2;
  int32_T c2_c_loop_ub;
  int32_T c2_c_mfID;
  int32_T c2_d_loop_ub;
  int32_T c2_d_varargin_2;
  int32_T c2_e_loop_ub;
  int32_T c2_e_varargin_2;
  int32_T c2_f_loop_ub;
  int32_T c2_g_loop_ub;
  int32_T c2_h_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i19;
  int32_T c2_i2;
  int32_T c2_i20;
  int32_T c2_i21;
  int32_T c2_i22;
  int32_T c2_i23;
  int32_T c2_i24;
  int32_T c2_i25;
  int32_T c2_i26;
  int32_T c2_i27;
  int32_T c2_i28;
  int32_T c2_i29;
  int32_T c2_i3;
  int32_T c2_i30;
  int32_T c2_i31;
  int32_T c2_i32;
  int32_T c2_i33;
  int32_T c2_i34;
  int32_T c2_i35;
  int32_T c2_i36;
  int32_T c2_i37;
  int32_T c2_i38;
  int32_T c2_i39;
  int32_T c2_i4;
  int32_T c2_i40;
  int32_T c2_i41;
  int32_T c2_i42;
  int32_T c2_i43;
  int32_T c2_i44;
  int32_T c2_i45;
  int32_T c2_i46;
  int32_T c2_i47;
  int32_T c2_i48;
  int32_T c2_i49;
  int32_T c2_i5;
  int32_T c2_i50;
  int32_T c2_i51;
  int32_T c2_i52;
  int32_T c2_i53;
  int32_T c2_i54;
  int32_T c2_i55;
  int32_T c2_i56;
  int32_T c2_i57;
  int32_T c2_i58;
  int32_T c2_i59;
  int32_T c2_i6;
  int32_T c2_i60;
  int32_T c2_i61;
  int32_T c2_i62;
  int32_T c2_i63;
  int32_T c2_i64;
  int32_T c2_i65;
  int32_T c2_i66;
  int32_T c2_i67;
  int32_T c2_i68;
  int32_T c2_i69;
  int32_T c2_i7;
  int32_T c2_i70;
  int32_T c2_i71;
  int32_T c2_i72;
  int32_T c2_i73;
  int32_T c2_i74;
  int32_T c2_i75;
  int32_T c2_i76;
  int32_T c2_i77;
  int32_T c2_i78;
  int32_T c2_i79;
  int32_T c2_i8;
  int32_T c2_i80;
  int32_T c2_i81;
  int32_T c2_i82;
  int32_T c2_i83;
  int32_T c2_i84;
  int32_T c2_i85;
  int32_T c2_i86;
  int32_T c2_i87;
  int32_T c2_i88;
  int32_T c2_i89;
  int32_T c2_i9;
  int32_T c2_i90;
  int32_T c2_i91;
  int32_T c2_i92;
  int32_T c2_i93;
  int32_T c2_i94;
  int32_T c2_i_loop_ub;
  int32_T c2_j_loop_ub;
  int32_T c2_k_loop_ub;
  int32_T c2_l_loop_ub;
  int32_T c2_loop_ub;
  int32_T c2_m_loop_ub;
  int32_T c2_mfID;
  int32_T c2_n_loop_ub;
  int32_T c2_o_loop_ub;
  int32_T c2_p_loop_ub;
  int32_T c2_q_loop_ub;
  int32_T c2_r_loop_ub;
  int32_T c2_s_loop_ub;
  int32_T c2_t_loop_ub;
  int32_T c2_varID;
  int32_T c2_varargin_2;
  char_T c2_tmp_data[5];
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_c_st.prev = &c2_b_st;
  c2_c_st.tls = c2_b_st.tls;
  for (c2_i = 0; c2_i < 7; c2_i++) {
    c2_fisout->type[c2_i] = (uint8_T)c2_fisin->type[c2_i];
  }

  for (c2_i1 = 0; c2_i1 < 3; c2_i1++) {
    c2_fisout->andMethod[c2_i1] = (uint8_T)c2_fisin->andMethod[c2_i1];
  }

  for (c2_i2 = 0; c2_i2 < 3; c2_i2++) {
    c2_fisout->orMethod[c2_i2] = (uint8_T)c2_fisin->orMethod[c2_i2];
  }

  for (c2_i3 = 0; c2_i3 < 8; c2_i3++) {
    c2_fisout->defuzzMethod[c2_i3] = (uint8_T)c2_fisin->defuzzMethod[c2_i3];
  }

  for (c2_i4 = 0; c2_i4 < 3; c2_i4++) {
    c2_fisout->impMethod[c2_i4] = (uint8_T)c2_fisin->impMethod[c2_i4];
  }

  for (c2_i5 = 0; c2_i5 < 3; c2_i5++) {
    c2_fisout->aggMethod[c2_i5] = (uint8_T)c2_fisin->aggMethod[c2_i5];
  }

  for (c2_i6 = 0; c2_i6 < 4; c2_i6++) {
    c2_fisout->inputRange[c2_i6] = c2_fisin->inputRange[c2_i6];
  }

  for (c2_i7 = 0; c2_i7 < 2; c2_i7++) {
    c2_fisout->outputRange[c2_i7] = c2_fisin->outputRange[c2_i7];
  }

  c2_st.site = &c2_l_emlrtRSI;
  for (c2_i8 = 0; c2_i8 < 2; c2_i8++) {
    c2_in[c2_i8] = c2_fisin->inputMF[c2_i8];
  }

  c2_r.size[1] = c2_in[0].mf.size[1];
  c2_numMF = (real_T)c2_r.size[1];
  c2_r.size[1] = c2_in[0].mf.size[1];
  c2_loop_ub = c2_in[0].mf.size[0] * c2_in[0].mf.size[1] - 1;
  for (c2_i9 = 0; c2_i9 <= c2_loop_ub; c2_i9++) {
    c2_r.data[c2_i9] = c2_in[0].mf.data[c2_i9];
  }

  if (1 > c2_r.size[1]) {
    emlrtDynamicBoundsCheckR2012b(1, 1, c2_r.size[1], &c2_m_emlrtBCI, &c2_st);
  }

  c2_tmp_size[1] = c2_r.data[0].type.size[1];
  c2_varargin_2 = c2_tmp_size[1];
  c2_b_varargin_2 = c2_varargin_2;
  c2_mfTypeLength = (real_T)c2_b_varargin_2;
  c2_r.size[1] = c2_in[0].mf.size[1];
  c2_b_loop_ub = c2_in[0].mf.size[0] * c2_in[0].mf.size[1] - 1;
  for (c2_i10 = 0; c2_i10 <= c2_b_loop_ub; c2_i10++) {
    c2_r.data[c2_i10] = c2_in[0].mf.data[c2_i10];
  }

  if (1 > c2_r.size[1]) {
    emlrtDynamicBoundsCheckR2012b(1, 1, c2_r.size[1], &c2_n_emlrtBCI, &c2_st);
  }

  c2_b_tmp_size[1] = c2_r.data[0].params.size[1];
  c2_mfParamLength = (real_T)c2_b_tmp_size[1];
  c2_varargin_1_size[0] = 1;
  c2_varargin_1_size[1] = (int32_T)c2_mfTypeLength;
  for (c2_i11 = 0; c2_i11 < 2; c2_i11++) {
    c2_dv[c2_i11] = (real_T)c2_varargin_1_size[c2_i11];
  }

  c2_mfStruct.type.size[0] = 1;
  c2_mfStruct.type.size[1] = (int32_T)c2_dv[1];
  for (c2_i12 = 0; c2_i12 < 2; c2_i12++) {
    c2_b_mfStruct[c2_i12] = c2_mfStruct.type.size[c2_i12];
  }

  c2_mfStruct.type.size[0] = 1;
  c2_mfStruct.type.size[1] = c2_b_mfStruct[1];
  c2_c_loop_ub = c2_b_mfStruct[0] * c2_b_mfStruct[1] - 1;
  for (c2_i13 = 0; c2_i13 <= c2_c_loop_ub; c2_i13++) {
    c2_mfStruct.type.data[c2_i13] = '\x00';
  }

  c2_mfStruct.origTypeLength = 0;
  c2_mfStruct.params.size[0] = 1;
  c2_mfStruct.params.size[1] = (int32_T)c2_mfParamLength;
  c2_d_loop_ub = (int32_T)c2_mfParamLength - 1;
  for (c2_i14 = 0; c2_i14 <= c2_d_loop_ub; c2_i14++) {
    c2_mfStruct.params.data[c2_i14] = 0.0;
  }

  c2_mfStruct.origParamLength = 0;
  c2_b_st.site = &c2_n_emlrtRSI;
  c2_c_varargin_2 = c2_numMF;
  c2_c_st.site = &c2_k_emlrtRSI;
  c2_assertValidSizeArg(chartInstance, &c2_c_st, c2_c_varargin_2);
  c2_tile_size[1] = (int32_T)c2_c_varargin_2;
  c2_outsize[1] = c2_tile_size[1];
  if (!((real_T)c2_outsize[1] == (real_T)c2_tile_size[1])) {
    c2_y = NULL;
    sf_mex_assign(&c2_y, sf_mex_create("y", c2_cv, 10, 0U, 1U, 0U, 2, 1, 15),
                  false);
    sf_mex_call(&c2_b_st, &c2_emlrtMCI, "error", 0U, 1U, 14, c2_y);
  }

  c2_varStruct.mf.size[0] = 1;
  c2_varStruct.mf.size[1] = c2_outsize[1];
  c2_e_loop_ub = c2_outsize[1] - 1;
  for (c2_i15 = 0; c2_i15 <= c2_e_loop_ub; c2_i15++) {
    c2_varStruct.mf.data[c2_i15] = c2_mfStruct;
  }

  c2_varStruct.origNumMF = 0;
  for (c2_i16 = 0; c2_i16 < 2; c2_i16++) {
    c2_fisout->inputMF[c2_i16] = c2_varStruct;
  }

  for (c2_varID = 0; c2_varID < 2; c2_varID++) {
    c2_b_varID = (real_T)c2_varID + 1.0;
    c2_d = muDoubleScalarRound(c2_in[(int32_T)c2_b_varID - 1].origNumMF);
    if (c2_d < 2.147483648E+9) {
      if (c2_d >= -2.147483648E+9) {
        c2_i17 = (int32_T)c2_d;
      } else {
        c2_i17 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d >= 2.147483648E+9) {
      c2_i17 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i17 = 0;
    }

    c2_fisout->inputMF[(int32_T)c2_b_varID - 1].origNumMF = c2_i17;
    c2_i18 = (int32_T)c2_numMF - 1;
    for (c2_mfID = 0; c2_mfID <= c2_i18; c2_mfID++) {
      c2_b_mfID = (real_T)c2_mfID + 1.0;
      c2_r.size[1] = c2_in[(int32_T)c2_b_varID - 1].mf.size[1];
      c2_f_loop_ub = c2_in[(int32_T)c2_b_varID - 1].mf.size[0] * c2_in[(int32_T)
        c2_b_varID - 1].mf.size[1] - 1;
      for (c2_i21 = 0; c2_i21 <= c2_f_loop_ub; c2_i21++) {
        c2_r.data[c2_i21] = c2_in[(int32_T)c2_b_varID - 1].mf.data[c2_i21];
      }

      c2_i22 = (int32_T)c2_b_varID - 1;
      c2_i23 = c2_fisout->inputMF[c2_i22].mf.size[1];
      c2_i25 = (int32_T)c2_b_mfID;
      if ((c2_i25 < 1) || (c2_i25 > c2_i23)) {
        emlrtDynamicBoundsCheckR2012b(c2_i25, 1, c2_i23, &c2_o_emlrtBCI, &c2_st);
      }

      c2_i26 = c2_i25 - 1;
      c2_i27 = (int32_T)c2_b_mfID;
      if ((c2_i27 < 1) || (c2_i27 > c2_r.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i27, 1, c2_r.size[1], &c2_q_emlrtBCI,
          &c2_st);
      }

      c2_i29 = c2_i27 - 1;
      c2_tmp_size[1] = c2_r.data[c2_i29].type.size[1];
      c2_i30 = (int32_T)c2_b_mfID;
      if ((c2_i30 < 1) || (c2_i30 > c2_r.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i30, 1, c2_r.size[1], &c2_q_emlrtBCI,
          &c2_st);
      }

      c2_i31 = c2_i30 - 1;
      c2_i32 = (int32_T)c2_b_mfID;
      if ((c2_i32 < 1) || (c2_i32 > c2_r.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i32, 1, c2_r.size[1], &c2_q_emlrtBCI,
          &c2_st);
      }

      c2_i34 = c2_i32 - 1;
      c2_i_loop_ub = c2_r.data[c2_i31].type.size[0] * c2_r.data[c2_i34].
        type.size[1] - 1;
      for (c2_i35 = 0; c2_i35 <= c2_i_loop_ub; c2_i35++) {
        c2_i37 = (int32_T)c2_b_mfID;
        if ((c2_i37 < 1) || (c2_i37 > c2_r.size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i37, 1, c2_r.size[1], &c2_w_emlrtBCI,
            &c2_st);
        }

        c2_tmp_data[c2_i35] = c2_r.data[c2_i37 - 1].type.data[c2_i35];
      }

      c2_i36 = c2_fisout->inputMF[c2_i22].mf.data[c2_i26].type.size[1];
      if (c2_i36 != c2_tmp_size[1]) {
        emlrtSubAssignSizeCheck1dR2017a(c2_i36, c2_tmp_size[1], &c2_d_emlrtECI,
          &c2_st);
      }

      c2_fisout->inputMF[c2_i22].mf.data[c2_i26].type.size[0] = 1;
      c2_fisout->inputMF[c2_i22].mf.data[c2_i26].type.size[1] = c2_tmp_size[1];
      c2_k_loop_ub = c2_tmp_size[1] - 1;
      for (c2_i43 = 0; c2_i43 <= c2_k_loop_ub; c2_i43++) {
        c2_fisout->inputMF[c2_i22].mf.data[c2_i26].type.data[c2_i43] =
          c2_tmp_data[c2_i43];
      }

      c2_r.size[1] = c2_in[(int32_T)c2_b_varID - 1].mf.size[1];
      c2_l_loop_ub = c2_in[(int32_T)c2_b_varID - 1].mf.size[0] * c2_in[(int32_T)
        c2_b_varID - 1].mf.size[1] - 1;
      for (c2_i46 = 0; c2_i46 <= c2_l_loop_ub; c2_i46++) {
        c2_r.data[c2_i46] = c2_in[(int32_T)c2_b_varID - 1].mf.data[c2_i46];
      }

      c2_i47 = (int32_T)c2_b_varID - 1;
      c2_i50 = c2_fisout->inputMF[c2_i47].mf.size[1];
      c2_i51 = (int32_T)c2_b_mfID;
      if ((c2_i51 < 1) || (c2_i51 > c2_i50)) {
        emlrtDynamicBoundsCheckR2012b(c2_i51, 1, c2_i50, &c2_p_emlrtBCI, &c2_st);
      }

      c2_i54 = c2_i51 - 1;
      c2_i57 = (int32_T)c2_b_mfID;
      if ((c2_i57 < 1) || (c2_i57 > c2_r.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i57, 1, c2_r.size[1], &c2_r_emlrtBCI,
          &c2_st);
      }

      c2_i60 = c2_i57 - 1;
      c2_b_tmp_size[1] = c2_r.data[c2_i60].params.size[1];
      c2_i62 = (int32_T)c2_b_mfID;
      if ((c2_i62 < 1) || (c2_i62 > c2_r.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i62, 1, c2_r.size[1], &c2_r_emlrtBCI,
          &c2_st);
      }

      c2_i66 = c2_i62 - 1;
      c2_i67 = (int32_T)c2_b_mfID;
      if ((c2_i67 < 1) || (c2_i67 > c2_r.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i67, 1, c2_r.size[1], &c2_r_emlrtBCI,
          &c2_st);
      }

      c2_i71 = c2_i67 - 1;
      c2_q_loop_ub = c2_r.data[c2_i66].params.size[0] * c2_r.data[c2_i71].
        params.size[1] - 1;
      for (c2_i75 = 0; c2_i75 <= c2_q_loop_ub; c2_i75++) {
        c2_i78 = (int32_T)c2_b_mfID;
        if ((c2_i78 < 1) || (c2_i78 > c2_r.size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i78, 1, c2_r.size[1], &c2_x_emlrtBCI,
            &c2_st);
        }

        c2_b_tmp_data[c2_i75] = c2_r.data[c2_i78 - 1].params.data[c2_i75];
      }

      c2_i77 = c2_fisout->inputMF[c2_i47].mf.data[c2_i54].params.size[1];
      if (c2_i77 != c2_b_tmp_size[1]) {
        emlrtSubAssignSizeCheck1dR2017a(c2_i77, c2_b_tmp_size[1], &c2_e_emlrtECI,
          &c2_st);
      }

      c2_fisout->inputMF[c2_i47].mf.data[c2_i54].params.size[0] = 1;
      c2_fisout->inputMF[c2_i47].mf.data[c2_i54].params.size[1] = c2_b_tmp_size
        [1];
      c2_r_loop_ub = c2_b_tmp_size[1] - 1;
      for (c2_i82 = 0; c2_i82 <= c2_r_loop_ub; c2_i82++) {
        c2_fisout->inputMF[c2_i47].mf.data[c2_i54].params.data[c2_i82] =
          c2_b_tmp_data[c2_i82];
      }

      c2_r.size[1] = c2_in[(int32_T)c2_b_varID - 1].mf.size[1];
      c2_s_loop_ub = c2_in[(int32_T)c2_b_varID - 1].mf.size[0] * c2_in[(int32_T)
        c2_b_varID - 1].mf.size[1] - 1;
      for (c2_i83 = 0; c2_i83 <= c2_s_loop_ub; c2_i83++) {
        c2_r.data[c2_i83] = c2_in[(int32_T)c2_b_varID - 1].mf.data[c2_i83];
      }

      c2_i84 = (int32_T)c2_b_varID - 1;
      c2_i85 = (int32_T)c2_b_mfID;
      if ((c2_i85 < 1) || (c2_i85 > c2_r.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i85, 1, c2_r.size[1], &c2_s_emlrtBCI,
          &c2_st);
      }

      c2_i86 = c2_fisout->inputMF[c2_i84].mf.size[1];
      c2_i87 = (int32_T)c2_b_mfID;
      if ((c2_i87 < 1) || (c2_i87 > c2_i86)) {
        emlrtDynamicBoundsCheckR2012b(c2_i87, 1, c2_i86, &c2_t_emlrtBCI, &c2_st);
      }

      c2_d10 = muDoubleScalarRound(c2_r.data[c2_i85 - 1].origTypeLength);
      if (c2_d10 < 2.147483648E+9) {
        if (c2_d10 >= -2.147483648E+9) {
          c2_i88 = (int32_T)c2_d10;
        } else {
          c2_i88 = MIN_int32_T;
          sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
        }
      } else if (c2_d10 >= 2.147483648E+9) {
        c2_i88 = MAX_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      } else {
        c2_i88 = 0;
      }

      c2_fisout->inputMF[c2_i84].mf.data[c2_i87 - 1].origTypeLength = c2_i88;
      c2_r.size[1] = c2_in[(int32_T)c2_b_varID - 1].mf.size[1];
      c2_t_loop_ub = c2_in[(int32_T)c2_b_varID - 1].mf.size[0] * c2_in[(int32_T)
        c2_b_varID - 1].mf.size[1] - 1;
      for (c2_i89 = 0; c2_i89 <= c2_t_loop_ub; c2_i89++) {
        c2_r.data[c2_i89] = c2_in[(int32_T)c2_b_varID - 1].mf.data[c2_i89];
      }

      c2_i90 = (int32_T)c2_b_varID - 1;
      c2_i91 = (int32_T)c2_b_mfID;
      if ((c2_i91 < 1) || (c2_i91 > c2_r.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i91, 1, c2_r.size[1], &c2_u_emlrtBCI,
          &c2_st);
      }

      c2_i92 = c2_fisout->inputMF[c2_i90].mf.size[1];
      c2_i93 = (int32_T)c2_b_mfID;
      if ((c2_i93 < 1) || (c2_i93 > c2_i92)) {
        emlrtDynamicBoundsCheckR2012b(c2_i93, 1, c2_i92, &c2_v_emlrtBCI, &c2_st);
      }

      c2_d11 = muDoubleScalarRound(c2_r.data[c2_i91 - 1].origParamLength);
      if (c2_d11 < 2.147483648E+9) {
        if (c2_d11 >= -2.147483648E+9) {
          c2_i94 = (int32_T)c2_d11;
        } else {
          c2_i94 = MIN_int32_T;
          sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
        }
      } else if (c2_d11 >= 2.147483648E+9) {
        c2_i94 = MAX_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      } else {
        c2_i94 = 0;
      }

      c2_fisout->inputMF[c2_i90].mf.data[c2_i93 - 1].origParamLength = c2_i94;
    }
  }

  c2_st.site = &c2_m_emlrtRSI;
  c2_b_in = c2_fisin->outputMF;
  c2_tmp_size[1] = c2_b_in.mf.data[0].type.size[1];
  c2_d_varargin_2 = c2_tmp_size[1];
  c2_e_varargin_2 = c2_d_varargin_2;
  c2_b_mfTypeLength = (real_T)c2_e_varargin_2;
  c2_b_tmp_size[1] = c2_b_in.mf.data[0].params.size[1];
  c2_b_mfParamLength = (real_T)c2_b_tmp_size[1];
  c2_varargin_1_size[0] = 1;
  c2_varargin_1_size[1] = (int32_T)c2_b_mfTypeLength;
  for (c2_i19 = 0; c2_i19 < 2; c2_i19++) {
    c2_dv[c2_i19] = (real_T)c2_varargin_1_size[c2_i19];
  }

  c2_c_mfStruct.type.size[0] = 1;
  c2_c_mfStruct.type.size[1] = (int32_T)c2_dv[1];
  for (c2_i20 = 0; c2_i20 < 2; c2_i20++) {
    c2_d_mfStruct[c2_i20] = c2_c_mfStruct.type.size[c2_i20];
  }

  c2_c_mfStruct.type.size[0] = 1;
  c2_c_mfStruct.type.size[1] = c2_d_mfStruct[1];
  c2_g_loop_ub = c2_d_mfStruct[0] * c2_d_mfStruct[1] - 1;
  for (c2_i24 = 0; c2_i24 <= c2_g_loop_ub; c2_i24++) {
    c2_c_mfStruct.type.data[c2_i24] = '\x00';
  }

  c2_c_mfStruct.origTypeLength = 0;
  c2_c_mfStruct.params.size[0] = 1;
  c2_c_mfStruct.params.size[1] = (int32_T)c2_b_mfParamLength;
  c2_h_loop_ub = (int32_T)c2_b_mfParamLength - 1;
  for (c2_i28 = 0; c2_i28 <= c2_h_loop_ub; c2_i28++) {
    c2_c_mfStruct.params.data[c2_i28] = 0.0;
  }

  c2_c_mfStruct.origParamLength = 0;
  c2_b_st.site = &c2_n_emlrtRSI;
  c2_c_st.site = &c2_k_emlrtRSI;
  c2_assertValidSizeArg(chartInstance, &c2_c_st, 5.0);
  c2_b_varStruct.mf.size[0] = 1;
  c2_b_varStruct.mf.size[1] = 5;
  for (c2_i33 = 0; c2_i33 < 5; c2_i33++) {
    c2_b_varStruct.mf.data[c2_i33] = c2_c_mfStruct;
  }

  c2_b_varStruct.origNumMF = 0;
  c2_fisout->outputMF = c2_b_varStruct;
  c2_fisout->outputMF.origNumMF = 5;
  for (c2_c_mfID = 0; c2_c_mfID < 5; c2_c_mfID++) {
    c2_d_mfID = (real_T)c2_c_mfID + 1.0;
    c2_i39 = (int32_T)c2_d_mfID - 1;
    c2_tmp_size[1] = c2_b_in.mf.data[(int32_T)c2_d_mfID - 1].type.size[1];
    c2_j_loop_ub = c2_b_in.mf.data[(int32_T)c2_d_mfID - 1].type.size[0] *
      c2_b_in.mf.data[(int32_T)c2_d_mfID - 1].type.size[1] - 1;
    for (c2_i42 = 0; c2_i42 <= c2_j_loop_ub; c2_i42++) {
      c2_tmp_data[c2_i42] = c2_b_in.mf.data[(int32_T)c2_d_mfID - 1]
        .type.data[c2_i42];
    }

    c2_i45 = c2_fisout->outputMF.mf.data[c2_i39].type.size[1];
    if (c2_i45 != c2_tmp_size[1]) {
      emlrtSubAssignSizeCheck1dR2017a(c2_i45, c2_tmp_size[1], &c2_d_emlrtECI,
        &c2_st);
    }

    c2_fisout->outputMF.mf.data[c2_i39].type.size[0] = 1;
    c2_fisout->outputMF.mf.data[c2_i39].type.size[1] = c2_tmp_size[1];
    c2_m_loop_ub = c2_tmp_size[1] - 1;
    for (c2_i49 = 0; c2_i49 <= c2_m_loop_ub; c2_i49++) {
      c2_fisout->outputMF.mf.data[c2_i39].type.data[c2_i49] = c2_tmp_data[c2_i49];
    }

    c2_i53 = (int32_T)c2_d_mfID - 1;
    c2_b_tmp_size[1] = c2_b_in.mf.data[(int32_T)c2_d_mfID - 1].params.size[1];
    c2_n_loop_ub = c2_b_in.mf.data[(int32_T)c2_d_mfID - 1].params.size[0] *
      c2_b_in.mf.data[(int32_T)c2_d_mfID - 1].params.size[1] - 1;
    for (c2_i56 = 0; c2_i56 <= c2_n_loop_ub; c2_i56++) {
      c2_b_tmp_data[c2_i56] = c2_b_in.mf.data[(int32_T)c2_d_mfID - 1].
        params.data[c2_i56];
    }

    c2_i59 = c2_fisout->outputMF.mf.data[c2_i53].params.size[1];
    if (c2_i59 != c2_b_tmp_size[1]) {
      emlrtSubAssignSizeCheck1dR2017a(c2_i59, c2_b_tmp_size[1], &c2_e_emlrtECI,
        &c2_st);
    }

    c2_fisout->outputMF.mf.data[c2_i53].params.size[0] = 1;
    c2_fisout->outputMF.mf.data[c2_i53].params.size[1] = c2_b_tmp_size[1];
    c2_p_loop_ub = c2_b_tmp_size[1] - 1;
    for (c2_i65 = 0; c2_i65 <= c2_p_loop_ub; c2_i65++) {
      c2_fisout->outputMF.mf.data[c2_i53].params.data[c2_i65] =
        c2_b_tmp_data[c2_i65];
    }

    c2_d5 = muDoubleScalarRound(c2_b_in.mf.data[(int32_T)c2_d_mfID - 1].
      origTypeLength);
    if (c2_d5 < 2.147483648E+9) {
      if (c2_d5 >= -2.147483648E+9) {
        c2_i73 = (int32_T)c2_d5;
      } else {
        c2_i73 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d5 >= 2.147483648E+9) {
      c2_i73 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i73 = 0;
    }

    c2_fisout->outputMF.mf.data[(int32_T)c2_d_mfID - 1].origTypeLength = c2_i73;
    c2_d9 = muDoubleScalarRound(c2_b_in.mf.data[(int32_T)c2_d_mfID - 1].
      origParamLength);
    if (c2_d9 < 2.147483648E+9) {
      if (c2_d9 >= -2.147483648E+9) {
        c2_i81 = (int32_T)c2_d9;
      } else {
        c2_i81 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d9 >= 2.147483648E+9) {
      c2_i81 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i81 = 0;
    }

    c2_fisout->outputMF.mf.data[(int32_T)c2_d_mfID - 1].origParamLength = c2_i81;
  }

  for (c2_i38 = 0; c2_i38 < 48; c2_i38++) {
    c2_fisout->antecedent[c2_i38] = c2_fisin->antecedent[c2_i38];
  }

  for (c2_i40 = 0; c2_i40 < 24; c2_i40++) {
    c2_fisout->consequent[c2_i40] = c2_fisin->consequent[c2_i40];
  }

  for (c2_i41 = 0; c2_i41 < 24; c2_i41++) {
    c2_fisout->connection[c2_i41] = c2_fisin->connection[c2_i41];
  }

  for (c2_i44 = 0; c2_i44 < 24; c2_i44++) {
    c2_fisout->weight[c2_i44] = c2_fisin->weight[c2_i44];
  }

  c2_fisout->numSamples = 101;
  c2_fisout->numInputs = 2;
  c2_fisout->numOutputs = 1;
  c2_fisout->numRules = 24;
  for (c2_i48 = 0; c2_i48 < 2; c2_i48++) {
    c2_d1 = muDoubleScalarRound(c2_fisin->numInputMFs[c2_i48]);
    if (c2_d1 < 2.147483648E+9) {
      if (c2_d1 >= -2.147483648E+9) {
        c2_i55 = (int32_T)c2_d1;
      } else {
        c2_i55 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d1 >= 2.147483648E+9) {
      c2_i55 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i55 = 0;
    }

    c2_fisout->numInputMFs[c2_i48] = c2_i55;
  }

  for (c2_i52 = 0; c2_i52 < 2; c2_i52++) {
    c2_d2 = muDoubleScalarRound(c2_fisin->numCumInputMFs[c2_i52]);
    if (c2_d2 < 2.147483648E+9) {
      if (c2_d2 >= -2.147483648E+9) {
        c2_i58 = (int32_T)c2_d2;
      } else {
        c2_i58 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d2 >= 2.147483648E+9) {
      c2_i58 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i58 = 0;
    }

    c2_fisout->numCumInputMFs[c2_i52] = c2_i58;
  }

  c2_fisout->numOutputMFs = 5;
  c2_fisout->numCumOutputMFs = 0;
  c2_fisout->outputSamplePoints.size[0] = 1;
  c2_fisout->outputSamplePoints.size[1] = c2_fisin->outputSamplePoints.size[1];
  c2_o_loop_ub = c2_fisin->outputSamplePoints.size[0] *
    c2_fisin->outputSamplePoints.size[1] - 1;
  for (c2_i61 = 0; c2_i61 <= c2_o_loop_ub; c2_i61++) {
    c2_fisout->outputSamplePoints.data[c2_i61] =
      c2_fisin->outputSamplePoints.data[c2_i61];
  }

  for (c2_i63 = 0; c2_i63 < 2; c2_i63++) {
    c2_d3 = muDoubleScalarRound(c2_fisin->orrSize[c2_i63]);
    if (c2_d3 < 2.147483648E+9) {
      if (c2_d3 >= -2.147483648E+9) {
        c2_i69 = (int32_T)c2_d3;
      } else {
        c2_i69 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d3 >= 2.147483648E+9) {
      c2_i69 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i69 = 0;
    }

    c2_fisout->orrSize[c2_i63] = c2_i69;
  }

  for (c2_i64 = 0; c2_i64 < 2; c2_i64++) {
    c2_d4 = muDoubleScalarRound(c2_fisin->aggSize[c2_i64]);
    if (c2_d4 < 2.147483648E+9) {
      if (c2_d4 >= -2.147483648E+9) {
        c2_i72 = (int32_T)c2_d4;
      } else {
        c2_i72 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d4 >= 2.147483648E+9) {
      c2_i72 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i72 = 0;
    }

    c2_fisout->aggSize[c2_i64] = c2_i72;
  }

  for (c2_i68 = 0; c2_i68 < 2; c2_i68++) {
    c2_d6 = muDoubleScalarRound(c2_fisin->irrSize[c2_i68]);
    if (c2_d6 < 2.147483648E+9) {
      if (c2_d6 >= -2.147483648E+9) {
        c2_i76 = (int32_T)c2_d6;
      } else {
        c2_i76 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d6 >= 2.147483648E+9) {
      c2_i76 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i76 = 0;
    }

    c2_fisout->irrSize[c2_i68] = c2_i76;
  }

  for (c2_i70 = 0; c2_i70 < 2; c2_i70++) {
    c2_d7 = muDoubleScalarRound(c2_fisin->rfsSize[c2_i70]);
    if (c2_d7 < 2.147483648E+9) {
      if (c2_d7 >= -2.147483648E+9) {
        c2_i79 = (int32_T)c2_d7;
      } else {
        c2_i79 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d7 >= 2.147483648E+9) {
      c2_i79 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i79 = 0;
    }

    c2_fisout->rfsSize[c2_i70] = c2_i79;
  }

  for (c2_i74 = 0; c2_i74 < 2; c2_i74++) {
    c2_d8 = muDoubleScalarRound(c2_fisin->sumSize[c2_i74]);
    if (c2_d8 < 2.147483648E+9) {
      if (c2_d8 >= -2.147483648E+9) {
        c2_i80 = (int32_T)c2_d8;
      } else {
        c2_i80 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d8 >= 2.147483648E+9) {
      c2_i80 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i80 = 0;
    }

    c2_fisout->sumSize[c2_i74] = c2_i80;
  }

  c2_fisout->inputFuzzySetType = 1;
}

static void c2_createMamdaniOutputMFCache
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T
   c2_outputSamplePoints_data[], int32_T c2_outputSamplePoints_size[2],
   c2_emxArray_real_T *c2_outputMFCache)
{
  c2_cell_wrap_0 c2_outVarMF[1];
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 c2_r;
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 c2_r1;
  c2_s_64TxJFgCtXBlX73DcwNLAB c2_b_fis;
  emlrtStack c2_st;
  real_T c2_b_outputSamplePoints_data[101];
  real_T c2_b_tmp_data[101];
  real_T c2_y;
  int32_T c2_tmp_data[101];
  int32_T c2_b_outputSamplePoints_size[2];
  int32_T c2_c_outputSamplePoints_size[2];
  int32_T c2_iv[2];
  int32_T c2_iv1[2];
  int32_T c2_iv2[2];
  int32_T c2_iv3[2];
  int32_T c2_tmp_size[2];
  int32_T c2_b_loop_ub;
  int32_T c2_b_mfID;
  int32_T c2_c_loop_ub;
  int32_T c2_d_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_loop_ub;
  int32_T c2_mfID;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_y = c2_sumColumnB(chartInstance);
  if (c2_y != (real_T)(int32_T)muDoubleScalarFloor(c2_y)) {
    emlrtIntegerCheckR2012b(c2_y, &c2_emlrtDCI, (void *)c2_sp);
  }

  c2_iv[0] = (int32_T)c2_y;
  c2_iv[1] = 101;
  c2_i = c2_outputMFCache->size[0] * c2_outputMFCache->size[1];
  c2_outputMFCache->size[0] = c2_iv[0];
  c2_outputMFCache->size[1] = c2_iv[1];
  c2_st.site = &c2_oe_emlrtRSI;
  c2_emxEnsureCapacity_real_T(chartInstance, &c2_st, c2_outputMFCache, c2_i,
    &c2_kb_emlrtRTEI);
  c2_b_fis = c2_fis->outputMF;
  c2_st.site = &c2_db_emlrtRSI;
  c2_extractVarMF(chartInstance, &c2_st, &c2_b_fis, c2_outVarMF);
  for (c2_mfID = 0; c2_mfID < 5; c2_mfID++) {
    c2_b_mfID = c2_mfID;
    c2_i1 = c2_b_mfID;
    for (c2_i2 = 0; c2_i2 < 101; c2_i2++) {
      c2_tmp_data[c2_i2] = c2_i2;
    }

    c2_r.size[0] = 1;
    c2_r.size[1] = c2_outVarMF[0].f1.size[1];
    c2_loop_ub = c2_outVarMF[0].f1.size[0] * c2_outVarMF[0].f1.size[1] - 1;
    for (c2_i3 = 0; c2_i3 <= c2_loop_ub; c2_i3++) {
      c2_r.data[c2_i3] = c2_outVarMF[0].f1.data[c2_i3];
    }

    c2_r1.size[0] = 1;
    c2_r1.size[1] = c2_outVarMF[0].f1.size[1];
    c2_b_loop_ub = c2_outVarMF[0].f1.size[0] * c2_outVarMF[0].f1.size[1] - 1;
    for (c2_i4 = 0; c2_i4 <= c2_b_loop_ub; c2_i4++) {
      c2_r1.data[c2_i4] = c2_outVarMF[0].f1.data[c2_i4];
    }

    c2_i5 = c2_outputSamplePoints_size[1] - 1;
    c2_b_outputSamplePoints_size[0] = 1;
    c2_b_outputSamplePoints_size[1] = c2_i5 + 1;
    c2_c_loop_ub = c2_i5;
    for (c2_i6 = 0; c2_i6 <= c2_c_loop_ub; c2_i6++) {
      c2_b_outputSamplePoints_data[c2_i6] = c2_outputSamplePoints_data[c2_i6];
    }

    c2_st.site = &c2_eb_emlrtRSI;
    for (c2_i7 = 0; c2_i7 < 2; c2_i7++) {
      c2_iv1[c2_i7] = c2_r.data[c2_b_mfID].type.size[c2_i7];
    }

    for (c2_i8 = 0; c2_i8 < 2; c2_i8++) {
      c2_c_outputSamplePoints_size[c2_i8] = c2_b_outputSamplePoints_size[c2_i8];
    }

    for (c2_i9 = 0; c2_i9 < 2; c2_i9++) {
      c2_iv2[c2_i9] = c2_r1.data[c2_b_mfID].params.size[c2_i9];
    }

    c2_evaluateCommonMembershipFcn(chartInstance, &c2_st, c2_r.data[c2_b_mfID].
      type.data, c2_iv1, c2_b_outputSamplePoints_data,
      c2_c_outputSamplePoints_size, c2_r1.data[c2_b_mfID].params.data, c2_iv2,
      c2_b_tmp_data, c2_tmp_size);
    for (c2_i10 = 0; c2_i10 < 2; c2_i10++) {
      c2_iv3[c2_i10] = 1 + 100 * c2_i10;
    }

    emlrtSubAssignSizeCheckR2012b(&c2_iv3[0], 2, &c2_tmp_size[0], 2,
      &c2_f_emlrtECI, (void *)c2_sp);
    c2_d_loop_ub = c2_tmp_size[1] - 1;
    for (c2_i11 = 0; c2_i11 <= c2_d_loop_ub; c2_i11++) {
      c2_outputMFCache->data[c2_i1 + c2_outputMFCache->size[0] *
        c2_tmp_data[c2_i11]] = c2_b_tmp_data[c2_i11];
    }
  }
}

static real_T c2_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
  return 5.0;
}

static void c2_extractVarMF(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_s_64TxJFgCtXBlX73DcwNLAB *c2_varin,
  c2_cell_wrap_0 c2_varout[1])
{
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 c2_mf;
  c2_s_JbR9CE1JwmiHOtKI7rv0ED c2_r;
  real_T c2_b_tmp_data[3];
  int32_T c2_b_tmp_size[2];
  int32_T c2_tmp_size[2];
  int32_T c2_b_j;
  int32_T c2_b_loop_ub;
  int32_T c2_c_loop_ub;
  int32_T c2_d_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_j;
  int32_T c2_loop_ub;
  char_T c2_tmp_data[5];
  boolean_T c2_b;
  boolean_T c2_b1;
  (void)chartInstance;
  for (c2_j = 0; c2_j < 5; c2_j++) {
    c2_b_j = c2_j;
    c2_tmp_size[1] = c2_varin->mf.data[c2_b_j].type.size[1];
    c2_loop_ub = c2_varin->mf.data[c2_b_j].type.size[0] * c2_varin->
      mf.data[c2_b_j].type.size[1] - 1;
    for (c2_i1 = 0; c2_i1 <= c2_loop_ub; c2_i1++) {
      c2_tmp_data[c2_i1] = c2_varin->mf.data[c2_b_j].type.data[c2_i1];
    }

    c2_i2 = c2_varin->mf.data[c2_b_j].origTypeLength;
    c2_b = (1 > c2_i2);
    if (c2_b) {
      c2_i3 = -1;
    } else {
      if (1 > c2_tmp_size[1]) {
        emlrtDynamicBoundsCheckR2012b(1, 1, c2_tmp_size[1], &c2_y_emlrtBCI,
          (void *)c2_sp);
      }

      if ((c2_i2 < 1) || (c2_i2 > c2_tmp_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i2, 1, c2_tmp_size[1], &c2_ab_emlrtBCI,
          (void *)c2_sp);
      }

      c2_i3 = c2_i2 - 1;
    }

    c2_b_tmp_size[1] = c2_varin->mf.data[c2_b_j].params.size[1];
    c2_b_loop_ub = c2_varin->mf.data[c2_b_j].params.size[0] * c2_varin->
      mf.data[c2_b_j].params.size[1] - 1;
    for (c2_i4 = 0; c2_i4 <= c2_b_loop_ub; c2_i4++) {
      c2_b_tmp_data[c2_i4] = c2_varin->mf.data[c2_b_j].params.data[c2_i4];
    }

    c2_i5 = c2_varin->mf.data[c2_b_j].origParamLength;
    c2_b1 = (1 > c2_i5);
    if (c2_b1) {
      c2_i6 = -1;
    } else {
      if (1 > c2_b_tmp_size[1]) {
        emlrtDynamicBoundsCheckR2012b(1, 1, c2_b_tmp_size[1], &c2_bb_emlrtBCI,
          (void *)c2_sp);
      }

      if ((c2_i5 < 1) || (c2_i5 > c2_b_tmp_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i5, 1, c2_b_tmp_size[1],
          &c2_cb_emlrtBCI, (void *)c2_sp);
      }

      c2_i6 = c2_i5 - 1;
    }

    c2_r.type.size[0] = 1;
    c2_r.type.size[1] = c2_i3 + 1;
    c2_c_loop_ub = c2_i3;
    for (c2_i7 = 0; c2_i7 <= c2_c_loop_ub; c2_i7++) {
      c2_r.type.data[c2_i7] = c2_tmp_data[c2_i7];
    }

    c2_r.params.size[0] = 1;
    c2_r.params.size[1] = c2_i6 + 1;
    c2_d_loop_ub = c2_i6;
    for (c2_i8 = 0; c2_i8 <= c2_d_loop_ub; c2_i8++) {
      c2_r.params.data[c2_i8] = c2_b_tmp_data[c2_i8];
    }

    c2_mf.data[c2_b_j] = c2_r;
  }

  c2_varout[0].f1.size[0] = 1;
  c2_varout[0].f1.size[1] = 5;
  for (c2_i = 0; c2_i < 5; c2_i++) {
    c2_varout[0].f1.data[c2_i] = c2_mf.data[c2_i];
  }
}

static void c2_evaluateCommonMembershipFcn
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, char_T c2_mfType_data[], int32_T c2_mfType_size[2], real_T c2_x_data[],
   int32_T c2_x_size[2], real_T c2_params_data[], int32_T c2_params_size[2],
   real_T c2_y_data[], int32_T c2_y_size[2])
{
  static char_T c2_b_cv[7] = { 'f', 'p', 'r', 'i', 'n', 't', 'f' };

  static uint8_T c2_uv1[5] = { 116U, 114U, 105U, 109U, 102U };

  static uint8_T c2_uv3[5] = { 115U, 105U, 103U, 109U, 102U };

  static uint8_T c2_uv9[4] = { 112U, 105U, 109U, 102U };

  static uint8_T c2_uv5[3] = { 115U, 109U, 102U };

  static uint8_T c2_uv7[3] = { 122U, 109U, 102U };

  emlrtStack c2_b_st;
  emlrtStack c2_c_st;
  emlrtStack c2_st;
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_e_y = NULL;
  const mxArray *c2_f_y = NULL;
  const mxArray *c2_g_y = NULL;
  const mxArray *c2_y = NULL;
  real_T c2_b_x_data[101];
  real_T c2_b_y_data[101];
  real_T c2_c_x_data[101];
  real_T c2_d_x_data[101];
  real_T c2_e_x_data[101];
  real_T c2_b_params_data[3];
  real_T c2_c_params_data[3];
  real_T c2_d_params_data[3];
  real_T c2_e_params_data[3];
  real_T c2_dv[2];
  real_T c2_a;
  real_T c2_b_a;
  real_T c2_b_x;
  real_T c2_c;
  real_T c2_u;
  real_T c2_x;
  int32_T c2_b_mfType_size[2];
  int32_T c2_b_params_size[2];
  int32_T c2_b_x_size[2];
  int32_T c2_b_y_size[2];
  int32_T c2_c_mfType_size[2];
  int32_T c2_c_params_size[2];
  int32_T c2_c_x_size[2];
  int32_T c2_d_mfType_size[2];
  int32_T c2_d_params_size[2];
  int32_T c2_d_x_size[2];
  int32_T c2_e_mfType_size[2];
  int32_T c2_e_params_size[2];
  int32_T c2_e_x_size[2];
  int32_T c2_f_mfType_size[2];
  int32_T c2_b_k;
  int32_T c2_b_loop_ub;
  int32_T c2_c_loop_ub;
  int32_T c2_d_loop_ub;
  int32_T c2_e_loop_ub;
  int32_T c2_f_loop_ub;
  int32_T c2_g_loop_ub;
  int32_T c2_h_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i19;
  int32_T c2_i2;
  int32_T c2_i20;
  int32_T c2_i21;
  int32_T c2_i22;
  int32_T c2_i23;
  int32_T c2_i24;
  int32_T c2_i25;
  int32_T c2_i26;
  int32_T c2_i27;
  int32_T c2_i28;
  int32_T c2_i29;
  int32_T c2_i3;
  int32_T c2_i30;
  int32_T c2_i31;
  int32_T c2_i32;
  int32_T c2_i33;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_i_loop_ub;
  int32_T c2_j_loop_ub;
  int32_T c2_k;
  int32_T c2_k_loop_ub;
  int32_T c2_l_loop_ub;
  int32_T c2_loop_ub;
  int32_T c2_m_loop_ub;
  int32_T c2_n_loop_ub;
  int32_T c2_nx;
  int32_T c2_o_loop_ub;
  int32_T c2_p_loop_ub;
  int32_T c2_q_loop_ub;
  int32_T c2_r_loop_ub;
  int32_T c2_s_loop_ub;
  char_T c2_b_mfType_data[5];
  char_T c2_c_mfType_data[5];
  char_T c2_d_mfType_data[5];
  char_T c2_e_mfType_data[5];
  char_T c2_f_mfType_data[5];
  uint8_T c2_uv[5];
  uint8_T c2_uv2[5];
  uint8_T c2_uv8[4];
  uint8_T c2_uv4[3];
  uint8_T c2_uv6[3];
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_c_st.prev = &c2_b_st;
  c2_c_st.tls = c2_b_st.tls;
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_dv[c2_i] = (real_T)c2_x_size[c2_i];
  }

  c2_y_size[1] = (int32_T)c2_dv[1];
  for (c2_i1 = 0; c2_i1 < 2; c2_i1++) {
    c2_dv[c2_i1] = (real_T)c2_x_size[c2_i1];
  }

  c2_b_y_size[0] = 1;
  c2_b_y_size[1] = (int32_T)c2_dv[1];
  c2_loop_ub = (int32_T)c2_dv[1] - 1;
  for (c2_i2 = 0; c2_i2 <= c2_loop_ub; c2_i2++) {
    c2_b_y_data[c2_i2] = -1.0;
  }

  if (c2_y_size[1] != c2_b_y_size[1]) {
    emlrtSubAssignSizeCheck1dR2017a(c2_y_size[1], c2_b_y_size[1], &c2_l_emlrtECI,
      (void *)c2_sp);
  }

  c2_y_size[0] = 1;
  c2_y_size[1] = c2_b_y_size[1];
  c2_b_loop_ub = c2_b_y_size[0] * c2_b_y_size[1] - 1;
  for (c2_i3 = 0; c2_i3 <= c2_b_loop_ub; c2_i3++) {
    c2_y_data[c2_i3] = c2_b_y_data[c2_i3];
  }

  c2_b_mfType_size[0] = 1;
  c2_b_mfType_size[1] = c2_mfType_size[1];
  c2_c_loop_ub = c2_mfType_size[0] * c2_mfType_size[1] - 1;
  for (c2_i4 = 0; c2_i4 <= c2_c_loop_ub; c2_i4++) {
    c2_b_mfType_data[c2_i4] = c2_mfType_data[c2_i4];
  }

  for (c2_i5 = 0; c2_i5 < 5; c2_i5++) {
    c2_uv[c2_i5] = c2_uv1[c2_i5];
  }

  if (c2_isequal(chartInstance, c2_b_mfType_data, c2_b_mfType_size, c2_uv)) {
    c2_b_x_size[0] = 1;
    c2_b_x_size[1] = c2_x_size[1];
    c2_e_loop_ub = c2_x_size[0] * c2_x_size[1] - 1;
    for (c2_i7 = 0; c2_i7 <= c2_e_loop_ub; c2_i7++) {
      c2_b_x_data[c2_i7] = c2_x_data[c2_i7];
    }

    c2_b_params_size[0] = 1;
    c2_b_params_size[1] = c2_params_size[1];
    c2_f_loop_ub = c2_params_size[0] * c2_params_size[1] - 1;
    for (c2_i9 = 0; c2_i9 <= c2_f_loop_ub; c2_i9++) {
      c2_b_params_data[c2_i9] = c2_params_data[c2_i9];
    }

    c2_st.site = &c2_kb_emlrtRSI;
    c2_trimf(chartInstance, &c2_st, c2_b_x_data, c2_b_x_size, c2_b_params_data,
             c2_b_params_size, c2_y_data, c2_y_size);
    if (c2_b_y_size[1] != c2_y_size[1]) {
      emlrtSubAssignSizeCheck1dR2017a(c2_b_y_size[1], c2_y_size[1],
        &c2_k_emlrtECI, (void *)c2_sp);
    }
  } else {
    c2_c_mfType_size[0] = 1;
    c2_c_mfType_size[1] = c2_mfType_size[1];
    c2_d_loop_ub = c2_mfType_size[0] * c2_mfType_size[1] - 1;
    for (c2_i6 = 0; c2_i6 <= c2_d_loop_ub; c2_i6++) {
      c2_c_mfType_data[c2_i6] = c2_mfType_data[c2_i6];
    }

    for (c2_i8 = 0; c2_i8 < 5; c2_i8++) {
      c2_uv2[c2_i8] = c2_uv3[c2_i8];
    }

    if (c2_isequal(chartInstance, c2_c_mfType_data, c2_c_mfType_size, c2_uv2)) {
      c2_st.site = &c2_jb_emlrtRSI;
      c2_b_st.site = &c2_gc_emlrtRSI;
      if ((real_T)c2_params_size[1] < 2.0) {
        c2_y = NULL;
        sf_mex_assign(&c2_y, sf_mex_create("y", c2_cv1, 10, 0U, 1U, 0U, 2, 1, 41),
                      false);
        c2_b_y = NULL;
        sf_mex_assign(&c2_b_y, sf_mex_create("y", c2_cv1, 10, 0U, 1U, 0U, 2, 1,
          41), false);
        sf_mex_call(&c2_b_st, &c2_o_emlrtMCI, "error", 0U, 2U, 14, c2_y, 14,
                    sf_mex_call(&c2_b_st, NULL, "getString", 1U, 1U, 14,
          sf_mex_call(&c2_b_st, NULL, "message", 1U, 1U, 14, c2_b_y)));
      }

      c2_i11 = 1;
      if ((c2_i11 < 1) || (c2_i11 > c2_params_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i11, 1, c2_params_size[1],
          &c2_db_emlrtBCI, &c2_st);
      }

      c2_a = c2_params_data[0];
      c2_i13 = 2;
      if ((c2_i13 < 1) || (c2_i13 > c2_params_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i13, 1, c2_params_size[1],
          &c2_eb_emlrtBCI, &c2_st);
      }

      c2_c = c2_params_data[1];
      c2_b_a = -c2_a;
      c2_y_size[0] = 1;
      c2_y_size[1] = c2_x_size[1];
      c2_k_loop_ub = c2_x_size[0] * c2_x_size[1] - 1;
      for (c2_i18 = 0; c2_i18 <= c2_k_loop_ub; c2_i18++) {
        c2_y_data[c2_i18] = c2_x_data[c2_i18] - c2_c;
      }

      c2_i19 = c2_y_size[0] * c2_y_size[1];
      c2_y_size[0] = 1;
      c2_i22 = c2_i19;
      c2_n_loop_ub = c2_i22 - 1;
      for (c2_i24 = 0; c2_i24 <= c2_n_loop_ub; c2_i24++) {
        c2_y_data[c2_i24] *= c2_b_a;
      }

      c2_nx = c2_y_size[1] - 1;
      for (c2_k = 1; c2_k - 1 <= c2_nx; c2_k++) {
        c2_b_k = c2_k - 1;
        c2_x = c2_y_data[c2_b_k];
        c2_b_x = c2_x;
        c2_b_x = muDoubleScalarExp(c2_b_x);
        c2_y_data[c2_b_k] = c2_b_x;
      }

      c2_i27 = c2_y_size[0] * c2_y_size[1];
      c2_y_size[0] = 1;
      c2_i28 = c2_i27;
      c2_r_loop_ub = c2_i28 - 1;
      for (c2_i30 = 0; c2_i30 <= c2_r_loop_ub; c2_i30++) {
        c2_y_data[c2_i30]++;
      }

      c2_i31 = c2_y_size[0] * c2_y_size[1];
      c2_y_size[0] = 1;
      c2_i32 = c2_i31;
      c2_s_loop_ub = c2_i32 - 1;
      for (c2_i33 = 0; c2_i33 <= c2_s_loop_ub; c2_i33++) {
        c2_y_data[c2_i33] = 1.0 / c2_y_data[c2_i33];
      }

      if (c2_b_y_size[1] != c2_y_size[1]) {
        emlrtSubAssignSizeCheck1dR2017a(c2_b_y_size[1], c2_y_size[1],
          &c2_j_emlrtECI, (void *)c2_sp);
      }
    } else {
      c2_d_mfType_size[0] = 1;
      c2_d_mfType_size[1] = c2_mfType_size[1];
      c2_g_loop_ub = c2_mfType_size[0] * c2_mfType_size[1] - 1;
      for (c2_i10 = 0; c2_i10 <= c2_g_loop_ub; c2_i10++) {
        c2_d_mfType_data[c2_i10] = c2_mfType_data[c2_i10];
      }

      for (c2_i12 = 0; c2_i12 < 3; c2_i12++) {
        c2_uv4[c2_i12] = c2_uv5[c2_i12];
      }

      if (c2_b_isequal(chartInstance, c2_d_mfType_data, c2_d_mfType_size, c2_uv4))
      {
        c2_c_x_size[0] = 1;
        c2_c_x_size[1] = c2_x_size[1];
        c2_i_loop_ub = c2_x_size[0] * c2_x_size[1] - 1;
        for (c2_i15 = 0; c2_i15 <= c2_i_loop_ub; c2_i15++) {
          c2_c_x_data[c2_i15] = c2_x_data[c2_i15];
        }

        c2_c_params_size[0] = 1;
        c2_c_params_size[1] = c2_params_size[1];
        c2_j_loop_ub = c2_params_size[0] * c2_params_size[1] - 1;
        for (c2_i17 = 0; c2_i17 <= c2_j_loop_ub; c2_i17++) {
          c2_c_params_data[c2_i17] = c2_params_data[c2_i17];
        }

        c2_st.site = &c2_ib_emlrtRSI;
        c2_smf(chartInstance, &c2_st, c2_c_x_data, c2_c_x_size, c2_c_params_data,
               c2_c_params_size, c2_y_data, c2_y_size);
        if (c2_b_y_size[1] != c2_y_size[1]) {
          emlrtSubAssignSizeCheck1dR2017a(c2_b_y_size[1], c2_y_size[1],
            &c2_i_emlrtECI, (void *)c2_sp);
        }
      } else {
        c2_e_mfType_size[0] = 1;
        c2_e_mfType_size[1] = c2_mfType_size[1];
        c2_h_loop_ub = c2_mfType_size[0] * c2_mfType_size[1] - 1;
        for (c2_i14 = 0; c2_i14 <= c2_h_loop_ub; c2_i14++) {
          c2_e_mfType_data[c2_i14] = c2_mfType_data[c2_i14];
        }

        for (c2_i16 = 0; c2_i16 < 3; c2_i16++) {
          c2_uv6[c2_i16] = c2_uv7[c2_i16];
        }

        if (c2_b_isequal(chartInstance, c2_e_mfType_data, c2_e_mfType_size,
                         c2_uv6)) {
          c2_d_x_size[0] = 1;
          c2_d_x_size[1] = c2_x_size[1];
          c2_m_loop_ub = c2_x_size[0] * c2_x_size[1] - 1;
          for (c2_i21 = 0; c2_i21 <= c2_m_loop_ub; c2_i21++) {
            c2_d_x_data[c2_i21] = c2_x_data[c2_i21];
          }

          c2_d_params_size[0] = 1;
          c2_d_params_size[1] = c2_params_size[1];
          c2_o_loop_ub = c2_params_size[0] * c2_params_size[1] - 1;
          for (c2_i25 = 0; c2_i25 <= c2_o_loop_ub; c2_i25++) {
            c2_d_params_data[c2_i25] = c2_params_data[c2_i25];
          }

          c2_st.site = &c2_hb_emlrtRSI;
          c2_zmf(chartInstance, &c2_st, c2_d_x_data, c2_d_x_size,
                 c2_d_params_data, c2_d_params_size, c2_y_data, c2_y_size);
          if (c2_b_y_size[1] != c2_y_size[1]) {
            emlrtSubAssignSizeCheck1dR2017a(c2_b_y_size[1], c2_y_size[1],
              &c2_h_emlrtECI, (void *)c2_sp);
          }
        } else {
          c2_f_mfType_size[0] = 1;
          c2_f_mfType_size[1] = c2_mfType_size[1];
          c2_l_loop_ub = c2_mfType_size[0] * c2_mfType_size[1] - 1;
          for (c2_i20 = 0; c2_i20 <= c2_l_loop_ub; c2_i20++) {
            c2_f_mfType_data[c2_i20] = c2_mfType_data[c2_i20];
          }

          for (c2_i23 = 0; c2_i23 < 4; c2_i23++) {
            c2_uv8[c2_i23] = c2_uv9[c2_i23];
          }

          if (c2_c_isequal(chartInstance, c2_f_mfType_data, c2_f_mfType_size,
                           c2_uv8)) {
            c2_e_x_size[0] = 1;
            c2_e_x_size[1] = c2_x_size[1];
            c2_p_loop_ub = c2_x_size[0] * c2_x_size[1] - 1;
            for (c2_i26 = 0; c2_i26 <= c2_p_loop_ub; c2_i26++) {
              c2_e_x_data[c2_i26] = c2_x_data[c2_i26];
            }

            c2_e_params_size[0] = 1;
            c2_e_params_size[1] = c2_params_size[1];
            c2_q_loop_ub = c2_params_size[0] * c2_params_size[1] - 1;
            for (c2_i29 = 0; c2_i29 <= c2_q_loop_ub; c2_i29++) {
              c2_e_params_data[c2_i29] = c2_params_data[c2_i29];
            }

            c2_st.site = &c2_gb_emlrtRSI;
            c2_pimf(chartInstance, &c2_st, c2_e_x_data, c2_e_x_size,
                    c2_e_params_data, c2_e_params_size, c2_y_data, c2_y_size);
            if (c2_b_y_size[1] != c2_y_size[1]) {
              emlrtSubAssignSizeCheck1dR2017a(c2_b_y_size[1], c2_y_size[1],
                &c2_g_emlrtECI, (void *)c2_sp);
            }
          } else {
            c2_st.site = &c2_fb_emlrtRSI;
            c2_b_st.site = &c2_xc_emlrtRSI;
            c2_c_y = NULL;
            sf_mex_assign(&c2_c_y, sf_mex_create("y", c2_b_cv, 10, 0U, 1U, 0U, 2,
              1, 7), false);
            c2_u = 1.0;
            c2_d_y = NULL;
            sf_mex_assign(&c2_d_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0),
                          false);
            c2_e_y = NULL;
            sf_mex_assign(&c2_e_y, sf_mex_create("y", c2_cv2, 10, 0U, 1U, 0U, 2,
              1, 91), false);
            c2_f_y = NULL;
            sf_mex_assign(&c2_f_y, sf_mex_create("y", c2_cv3, 10, 0U, 1U, 0U, 2,
              1, 10), false);
            c2_g_y = NULL;
            sf_mex_assign(&c2_g_y, sf_mex_create("y", (void *)c2_mfType_data, 10,
              0U, 1U, 0U, 2, c2_mfType_size[0], c2_mfType_size[1]), false);
            c2_c_st.site = &c2_yc_emlrtRSI;
            c2_emlrt_marshallIn(chartInstance, c2_feval(chartInstance, &c2_c_st,
              c2_c_y, c2_d_y, c2_e_y, c2_f_y, c2_g_y), "<output of feval>");
            c2_st.site = &c2_lb_emlrtRSI;
            exit(0);
          }
        }
      }
    }
  }
}

static boolean_T c2_isequal(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, char_T c2_varargin_1_data[], int32_T c2_varargin_1_size[2],
  uint8_T c2_varargin_2[5])
{
  real_T c2_b_k;
  int32_T c2_k;
  char_T c2_x1;
  uint8_T c2_x2;
  boolean_T c2_b;
  boolean_T c2_b_p;
  boolean_T c2_c_p;
  boolean_T c2_d_p;
  boolean_T c2_e_p;
  boolean_T c2_exitg1;
  boolean_T c2_p;
  (void)chartInstance;
  c2_p = false;
  c2_b_p = false;
  if (!((real_T)c2_varargin_1_size[1] != 5.0)) {
    c2_b_p = true;
  }

  if (c2_b_p) {
    c2_c_p = true;
  } else {
    c2_c_p = false;
  }

  c2_d_p = c2_c_p;
  if (c2_c_p) {
    c2_b = (c2_varargin_1_size[1] == 0);
    if (!c2_b) {
      c2_k = 0;
      c2_exitg1 = false;
      while ((!c2_exitg1) && (c2_k < 5)) {
        c2_b_k = (real_T)c2_k + 1.0;
        c2_x1 = c2_varargin_1_data[(int32_T)c2_b_k - 1];
        c2_x2 = c2_varargin_2[(int32_T)c2_b_k - 1];
        c2_e_p = ((uint8_T)c2_x1 == c2_x2);
        if (!c2_e_p) {
          c2_d_p = false;
          c2_exitg1 = true;
        } else {
          c2_k++;
        }
      }
    }
  }

  if (c2_d_p) {
    c2_p = true;
  }

  return c2_p;
}

static void c2_trimf(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
                     const emlrtStack *c2_sp, real_T c2_x_data[], int32_T
                     c2_x_size[2], real_T c2_params_data[], int32_T
                     c2_params_size[2], real_T c2_y_data[], int32_T c2_y_size[2])
{
  emlrtStack c2_st;
  real_T c2_b_params_data[3];
  real_T c2_dv[2];
  real_T c2_a;
  real_T c2_b;
  real_T c2_c;
  real_T c2_c_i;
  real_T c2_d;
  int32_T c2_b_params_size[2];
  int32_T c2_b_i;
  int32_T c2_b_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_loop_ub;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_params_size[0] = 1;
  c2_b_params_size[1] = c2_params_size[1];
  c2_loop_ub = c2_params_size[0] * c2_params_size[1] - 1;
  for (c2_i = 0; c2_i <= c2_loop_ub; c2_i++) {
    c2_b_params_data[c2_i] = c2_params_data[c2_i];
  }

  c2_st.site = &c2_mb_emlrtRSI;
  c2_validateTriMFParameterValues(chartInstance, &c2_st, c2_b_params_data,
    c2_b_params_size);
  c2_st.site = &c2_nb_emlrtRSI;
  c2_i1 = 1;
  if ((c2_i1 < 1) || (c2_i1 > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i1, 1, c2_params_size[1], &c2_fb_emlrtBCI,
      &c2_st);
  }

  c2_a = c2_params_data[0];
  c2_i2 = 2;
  if ((c2_i2 < 1) || (c2_i2 > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i2, 1, c2_params_size[1], &c2_gb_emlrtBCI,
      &c2_st);
  }

  c2_b = c2_params_data[1];
  c2_i3 = 3;
  if ((c2_i3 < 1) || (c2_i3 > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i3, 1, c2_params_size[1], &c2_hb_emlrtBCI,
      &c2_st);
  }

  c2_c = c2_params_data[2];
  for (c2_i4 = 0; c2_i4 < 2; c2_i4++) {
    c2_dv[c2_i4] = (real_T)c2_x_size[c2_i4];
  }

  c2_y_size[0] = 1;
  c2_y_size[1] = (int32_T)c2_dv[1];
  c2_b_loop_ub = (int32_T)c2_dv[1] - 1;
  for (c2_i5 = 0; c2_i5 <= c2_b_loop_ub; c2_i5++) {
    c2_y_data[c2_i5] = 0.0;
  }

  c2_d = (real_T)c2_x_size[1];
  c2_i6 = (int32_T)c2_d - 1;
  for (c2_b_i = 0; c2_b_i <= c2_i6; c2_b_i++) {
    c2_c_i = (real_T)c2_b_i + 1.0;
    if (c2_a != c2_b) {
      c2_i7 = (int32_T)c2_c_i;
      if ((c2_i7 < 1) || (c2_i7 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i7, 1, c2_x_size[1], &c2_ib_emlrtBCI,
          &c2_st);
      }

      if (c2_a < c2_x_data[c2_i7 - 1]) {
        c2_i10 = (int32_T)c2_c_i;
        if ((c2_i10 < 1) || (c2_i10 > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i10, 1, c2_x_size[1], &c2_jb_emlrtBCI,
            &c2_st);
        }

        if (c2_x_data[c2_i10 - 1] < c2_b) {
          c2_i13 = (int32_T)c2_c_i;
          if ((c2_i13 < 1) || (c2_i13 > c2_x_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i13, 1, c2_x_size[1],
              &c2_mb_emlrtBCI, &c2_st);
          }

          c2_i15 = (int32_T)c2_c_i;
          if ((c2_i15 < 1) || (c2_i15 > c2_y_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i15, 1, c2_y_size[1],
              &c2_nb_emlrtBCI, &c2_st);
          }

          c2_y_data[c2_i15 - 1] = (c2_x_data[c2_i13 - 1] - c2_a) * (1.0 / (c2_b
            - c2_a));
        }
      }
    }

    if (c2_b != c2_c) {
      c2_i8 = (int32_T)c2_c_i;
      if ((c2_i8 < 1) || (c2_i8 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i8, 1, c2_x_size[1], &c2_kb_emlrtBCI,
          &c2_st);
      }

      if (c2_b < c2_x_data[c2_i8 - 1]) {
        c2_i11 = (int32_T)c2_c_i;
        if ((c2_i11 < 1) || (c2_i11 > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i11, 1, c2_x_size[1], &c2_lb_emlrtBCI,
            &c2_st);
        }

        if (c2_x_data[c2_i11 - 1] < c2_c) {
          c2_i14 = (int32_T)c2_c_i;
          if ((c2_i14 < 1) || (c2_i14 > c2_x_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i14, 1, c2_x_size[1],
              &c2_qb_emlrtBCI, &c2_st);
          }

          c2_i16 = (int32_T)c2_c_i;
          if ((c2_i16 < 1) || (c2_i16 > c2_y_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i16, 1, c2_y_size[1],
              &c2_rb_emlrtBCI, &c2_st);
          }

          c2_y_data[c2_i16 - 1] = (c2_c - c2_x_data[c2_i14 - 1]) * (1.0 / (c2_c
            - c2_b));
        }
      }
    }

    c2_i9 = (int32_T)c2_c_i;
    if ((c2_i9 < 1) || (c2_i9 > c2_x_size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_i9, 1, c2_x_size[1], &c2_ob_emlrtBCI,
        &c2_st);
    }

    if (c2_x_data[c2_i9 - 1] == c2_b) {
      c2_i12 = (int32_T)c2_c_i;
      if ((c2_i12 < 1) || (c2_i12 > c2_y_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i12, 1, c2_y_size[1], &c2_pb_emlrtBCI,
          &c2_st);
      }

      c2_y_data[c2_i12 - 1] = 1.0;
    }
  }
}

static void c2_validateTriMFParameterValues
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_params_data[], int32_T c2_params_size[2])
{
  static char_T c2_b_cv[41] = { 'f', 'u', 'z', 'z', 'y', ':', 'g', 'e', 'n', 'e',
    'r', 'a', 'l', ':', 'e', 'r', 'r', 'T', 'r', 'i', 'm', 'f', '_', 'I', 'n',
    'v', 'a', 'l', 'i', 'd', 'P', 'a', 'r', 'a', 'm', 'L', 'e', 'n', 'g', 't',
    'h' };

  static char_T c2_b_cv1[36] = { 'f', 'u', 'z', 'z', 'y', ':', 'g', 'e', 'n',
    'e', 'r', 'a', 'l', ':', 'e', 'r', 'r', 'T', 'r', 'i', 'm', 'f', '_', 'I',
    'n', 'v', 'a', 'l', 'i', 'd', 'P', 'a', 'r', 'a', 'm', 'A' };

  static char_T c2_b_cv2[36] = { 'f', 'u', 'z', 'z', 'y', ':', 'g', 'e', 'n',
    'e', 'r', 'a', 'l', ':', 'e', 'r', 'r', 'T', 'r', 'i', 'm', 'f', '_', 'I',
    'n', 'v', 'a', 'l', 'i', 'd', 'P', 'a', 'r', 'a', 'm', 'B' };

  const mxArray *c2_b_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_e_y = NULL;
  const mxArray *c2_f_y = NULL;
  const mxArray *c2_y = NULL;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_i3;
  (void)chartInstance;
  if ((real_T)c2_params_size[1] < 3.0) {
    c2_y = NULL;
    sf_mex_assign(&c2_y, sf_mex_create("y", c2_b_cv, 10, 0U, 1U, 0U, 2, 1, 41),
                  false);
    c2_b_y = NULL;
    sf_mex_assign(&c2_b_y, sf_mex_create("y", c2_b_cv, 10, 0U, 1U, 0U, 2, 1, 41),
                  false);
    sf_mex_call(c2_sp, &c2_d_emlrtMCI, "error", 0U, 2U, 14, c2_y, 14,
                sf_mex_call(c2_sp, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (c2_sp, NULL, "message", 1U, 1U, 14, c2_b_y)));
  }

  c2_i = 1;
  if ((c2_i < 1) || (c2_i > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i, 1, c2_params_size[1], &c2_sb_emlrtBCI,
      (void *)c2_sp);
  }

  c2_i1 = 2;
  if ((c2_i1 < 1) || (c2_i1 > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i1, 1, c2_params_size[1], &c2_tb_emlrtBCI,
      (void *)c2_sp);
  }

  if (c2_params_data[0] > c2_params_data[1]) {
    c2_c_y = NULL;
    sf_mex_assign(&c2_c_y, sf_mex_create("y", c2_b_cv1, 10, 0U, 1U, 0U, 2, 1, 36),
                  false);
    c2_d_y = NULL;
    sf_mex_assign(&c2_d_y, sf_mex_create("y", c2_b_cv1, 10, 0U, 1U, 0U, 2, 1, 36),
                  false);
    sf_mex_call(c2_sp, &c2_e_emlrtMCI, "error", 0U, 2U, 14, c2_c_y, 14,
                sf_mex_call(c2_sp, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (c2_sp, NULL, "message", 1U, 1U, 14, c2_d_y)));
  }

  c2_i2 = 2;
  if ((c2_i2 < 1) || (c2_i2 > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i2, 1, c2_params_size[1], &c2_ub_emlrtBCI,
      (void *)c2_sp);
  }

  c2_i3 = 3;
  if ((c2_i3 < 1) || (c2_i3 > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i3, 1, c2_params_size[1], &c2_vb_emlrtBCI,
      (void *)c2_sp);
  }

  if (c2_params_data[1] > c2_params_data[2]) {
    c2_e_y = NULL;
    sf_mex_assign(&c2_e_y, sf_mex_create("y", c2_b_cv2, 10, 0U, 1U, 0U, 2, 1, 36),
                  false);
    c2_f_y = NULL;
    sf_mex_assign(&c2_f_y, sf_mex_create("y", c2_b_cv2, 10, 0U, 1U, 0U, 2, 1, 36),
                  false);
    sf_mex_call(c2_sp, &c2_f_emlrtMCI, "error", 0U, 2U, 14, c2_e_y, 14,
                sf_mex_call(c2_sp, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (c2_sp, NULL, "message", 1U, 1U, 14, c2_f_y)));
  }
}

static boolean_T c2_b_isequal(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, char_T c2_varargin_1_data[], int32_T c2_varargin_1_size[2],
  uint8_T c2_varargin_2[3])
{
  real_T c2_b_k;
  int32_T c2_k;
  char_T c2_x1;
  uint8_T c2_x2;
  boolean_T c2_b;
  boolean_T c2_b_p;
  boolean_T c2_c_p;
  boolean_T c2_d_p;
  boolean_T c2_e_p;
  boolean_T c2_exitg1;
  boolean_T c2_p;
  (void)chartInstance;
  c2_p = false;
  c2_b_p = false;
  if (!((real_T)c2_varargin_1_size[1] != 3.0)) {
    c2_b_p = true;
  }

  if (c2_b_p) {
    c2_c_p = true;
  } else {
    c2_c_p = false;
  }

  c2_d_p = c2_c_p;
  if (c2_c_p) {
    c2_b = (c2_varargin_1_size[1] == 0);
    if (!c2_b) {
      c2_k = 0;
      c2_exitg1 = false;
      while ((!c2_exitg1) && (c2_k < 3)) {
        c2_b_k = (real_T)c2_k + 1.0;
        c2_x1 = c2_varargin_1_data[(int32_T)c2_b_k - 1];
        c2_x2 = c2_varargin_2[(int32_T)c2_b_k - 1];
        c2_e_p = ((uint8_T)c2_x1 == c2_x2);
        if (!c2_e_p) {
          c2_d_p = false;
          c2_exitg1 = true;
        } else {
          c2_k++;
        }
      }
    }
  }

  if (c2_d_p) {
    c2_p = true;
  }

  return c2_p;
}

static void c2_smf(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
                   const emlrtStack *c2_sp, real_T c2_x_data[], int32_T
                   c2_x_size[2], real_T c2_params_data[], int32_T
                   c2_params_size[2], real_T c2_y_data[], int32_T c2_y_size[2])
{
  emlrtStack c2_st;
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_y = NULL;
  real_T c2_dv[2];
  real_T c2_b_x0;
  real_T c2_c_i;
  real_T c2_d;
  real_T c2_value;
  real_T c2_x0;
  real_T c2_x1;
  int32_T c2_b_i;
  int32_T c2_b_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_loop_ub;
  (void)chartInstance;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_st.site = &c2_kc_emlrtRSI;
  if ((real_T)c2_params_size[1] < 2.0) {
    c2_y = NULL;
    sf_mex_assign(&c2_y, sf_mex_create("y", c2_cv4, 10, 0U, 1U, 0U, 2, 1, 39),
                  false);
    c2_b_y = NULL;
    sf_mex_assign(&c2_b_y, sf_mex_create("y", c2_cv4, 10, 0U, 1U, 0U, 2, 1, 39),
                  false);
    sf_mex_call(&c2_st, &c2_p_emlrtMCI, "error", 0U, 2U, 14, c2_y, 14,
                sf_mex_call(&c2_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c2_st, NULL, "message", 1U, 1U, 14, c2_b_y)));
  }

  c2_st.site = &c2_lc_emlrtRSI;
  c2_i = 1;
  if ((c2_i < 1) || (c2_i > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i, 1, c2_params_size[1], &c2_wb_emlrtBCI,
      &c2_st);
  }

  c2_x0 = c2_params_data[0];
  c2_i1 = 2;
  if ((c2_i1 < 1) || (c2_i1 > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i1, 1, c2_params_size[1], &c2_xb_emlrtBCI,
      &c2_st);
  }

  c2_x1 = c2_params_data[1];
  if (c2_x0 >= c2_x1) {
    c2_y_size[0] = 1;
    c2_y_size[1] = c2_x_size[1];
    c2_b_x0 = (c2_x0 + c2_x1) / 2.0;
    c2_loop_ub = c2_x_size[0] * c2_x_size[1] - 1;
    for (c2_i3 = 0; c2_i3 <= c2_loop_ub; c2_i3++) {
      c2_y_data[c2_i3] = (real_T)(c2_x_data[c2_i3] >= c2_b_x0);
    }
  } else {
    for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
      c2_dv[c2_i2] = (real_T)c2_x_size[c2_i2];
    }

    c2_y_size[0] = 1;
    c2_y_size[1] = (int32_T)c2_dv[1];
    c2_b_loop_ub = (int32_T)c2_dv[1] - 1;
    for (c2_i4 = 0; c2_i4 <= c2_b_loop_ub; c2_i4++) {
      c2_y_data[c2_i4] = 0.0;
    }

    c2_d = (real_T)c2_x_size[1];
    c2_i5 = (int32_T)c2_d - 1;
    for (c2_b_i = 0; c2_b_i <= c2_i5; c2_b_i++) {
      c2_c_i = (real_T)c2_b_i + 1.0;
      c2_i6 = (int32_T)c2_c_i;
      if ((c2_i6 < 1) || (c2_i6 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i6, 1, c2_x_size[1], &c2_yb_emlrtBCI,
          &c2_st);
      }

      if (c2_x0 < c2_x_data[c2_i6 - 1]) {
        c2_i7 = (int32_T)c2_c_i;
        if ((c2_i7 < 1) || (c2_i7 > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i7, 1, c2_x_size[1], &c2_ac_emlrtBCI,
            &c2_st);
        }

        if (c2_x_data[c2_i7 - 1] <= (c2_x0 + c2_x1) / 2.0) {
          c2_i9 = (int32_T)c2_c_i;
          if ((c2_i9 < 1) || (c2_i9 > c2_x_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i9, 1, c2_x_size[1],
              &c2_bc_emlrtBCI, &c2_st);
          }

          c2_value = (c2_x_data[c2_i9 - 1] - c2_x0) * (1.0 / (c2_x1 - c2_x0));
          c2_i12 = (int32_T)c2_c_i;
          if ((c2_i12 < 1) || (c2_i12 > c2_y_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i12, 1, c2_y_size[1],
              &c2_dc_emlrtBCI, &c2_st);
          }

          c2_y_data[c2_i12 - 1] = 2.0 * c2_value * c2_value;
        }
      }

      c2_i8 = (int32_T)c2_c_i;
      if ((c2_i8 < 1) || (c2_i8 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i8, 1, c2_x_size[1], &c2_cc_emlrtBCI,
          &c2_st);
      }

      if ((c2_x0 + c2_x1) / 2.0 < c2_x_data[c2_i8 - 1]) {
        c2_i10 = (int32_T)c2_c_i;
        if ((c2_i10 < 1) || (c2_i10 > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i10, 1, c2_x_size[1], &c2_ec_emlrtBCI,
            &c2_st);
        }

        if (c2_x_data[c2_i10 - 1] <= c2_x1) {
          c2_i13 = (int32_T)c2_c_i;
          if ((c2_i13 < 1) || (c2_i13 > c2_x_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i13, 1, c2_x_size[1],
              &c2_fc_emlrtBCI, &c2_st);
          }

          c2_value = (c2_x1 - c2_x_data[c2_i13 - 1]) * (1.0 / (c2_x1 - c2_x0));
          c2_i15 = (int32_T)c2_c_i;
          if ((c2_i15 < 1) || (c2_i15 > c2_y_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i15, 1, c2_y_size[1],
              &c2_hc_emlrtBCI, &c2_st);
          }

          c2_y_data[c2_i15 - 1] = 1.0 - 2.0 * c2_value * c2_value;
        }
      }

      c2_i11 = (int32_T)c2_c_i;
      if ((c2_i11 < 1) || (c2_i11 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i11, 1, c2_x_size[1], &c2_gc_emlrtBCI,
          &c2_st);
      }

      if (c2_x1 <= c2_x_data[c2_i11 - 1]) {
        c2_i14 = (int32_T)c2_c_i;
        if ((c2_i14 < 1) || (c2_i14 > c2_y_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i14, 1, c2_y_size[1], &c2_ic_emlrtBCI,
            &c2_st);
        }

        c2_y_data[c2_i14 - 1] = 1.0;
      }
    }
  }
}

static void c2_zmf(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
                   const emlrtStack *c2_sp, real_T c2_x_data[], int32_T
                   c2_x_size[2], real_T c2_params_data[], int32_T
                   c2_params_size[2], real_T c2_y_data[], int32_T c2_y_size[2])
{
  emlrtStack c2_st;
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_y = NULL;
  real_T c2_dv[2];
  real_T c2_b_x0;
  real_T c2_c_i;
  real_T c2_d;
  real_T c2_value;
  real_T c2_x0;
  real_T c2_x1;
  int32_T c2_b_i;
  int32_T c2_b_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_loop_ub;
  (void)chartInstance;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_st.site = &c2_mc_emlrtRSI;
  if ((real_T)c2_params_size[1] < 2.0) {
    c2_y = NULL;
    sf_mex_assign(&c2_y, sf_mex_create("y", c2_cv5, 10, 0U, 1U, 0U, 2, 1, 39),
                  false);
    c2_b_y = NULL;
    sf_mex_assign(&c2_b_y, sf_mex_create("y", c2_cv5, 10, 0U, 1U, 0U, 2, 1, 39),
                  false);
    sf_mex_call(&c2_st, &c2_q_emlrtMCI, "error", 0U, 2U, 14, c2_y, 14,
                sf_mex_call(&c2_st, NULL, "getString", 1U, 1U, 14, sf_mex_call
      (&c2_st, NULL, "message", 1U, 1U, 14, c2_b_y)));
  }

  c2_st.site = &c2_nc_emlrtRSI;
  c2_i = 1;
  if ((c2_i < 1) || (c2_i > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i, 1, c2_params_size[1], &c2_jc_emlrtBCI,
      &c2_st);
  }

  c2_x1 = c2_params_data[0];
  c2_i1 = 2;
  if ((c2_i1 < 1) || (c2_i1 > c2_params_size[1])) {
    emlrtDynamicBoundsCheckR2012b(c2_i1, 1, c2_params_size[1], &c2_kc_emlrtBCI,
      &c2_st);
  }

  c2_x0 = c2_params_data[1];
  if (c2_x1 >= c2_x0) {
    c2_y_size[0] = 1;
    c2_y_size[1] = c2_x_size[1];
    c2_b_x0 = (c2_x0 + c2_x1) / 2.0;
    c2_loop_ub = c2_x_size[0] * c2_x_size[1] - 1;
    for (c2_i3 = 0; c2_i3 <= c2_loop_ub; c2_i3++) {
      c2_y_data[c2_i3] = (real_T)(c2_x_data[c2_i3] <= c2_b_x0);
    }
  } else {
    for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
      c2_dv[c2_i2] = (real_T)c2_x_size[c2_i2];
    }

    c2_y_size[0] = 1;
    c2_y_size[1] = (int32_T)c2_dv[1];
    c2_b_loop_ub = (int32_T)c2_dv[1] - 1;
    for (c2_i4 = 0; c2_i4 <= c2_b_loop_ub; c2_i4++) {
      c2_y_data[c2_i4] = 0.0;
    }

    c2_d = (real_T)c2_x_size[1];
    c2_i5 = (int32_T)c2_d - 1;
    for (c2_b_i = 0; c2_b_i <= c2_i5; c2_b_i++) {
      c2_c_i = (real_T)c2_b_i + 1.0;
      c2_i6 = (int32_T)c2_c_i;
      if ((c2_i6 < 1) || (c2_i6 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i6, 1, c2_x_size[1], &c2_lc_emlrtBCI,
          &c2_st);
      }

      if (c2_x_data[c2_i6 - 1] <= c2_x1) {
        c2_i7 = (int32_T)c2_c_i;
        if ((c2_i7 < 1) || (c2_i7 > c2_y_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i7, 1, c2_y_size[1], &c2_mc_emlrtBCI,
            &c2_st);
        }

        c2_y_data[c2_i7 - 1] = 1.0;
      }

      c2_i8 = (int32_T)c2_c_i;
      if ((c2_i8 < 1) || (c2_i8 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i8, 1, c2_x_size[1], &c2_nc_emlrtBCI,
          &c2_st);
      }

      if (c2_x1 < c2_x_data[c2_i8 - 1]) {
        c2_i9 = (int32_T)c2_c_i;
        if ((c2_i9 < 1) || (c2_i9 > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i9, 1, c2_x_size[1], &c2_oc_emlrtBCI,
            &c2_st);
        }

        if (c2_x_data[c2_i9 - 1] <= (c2_x1 + c2_x0) / 2.0) {
          c2_i11 = (int32_T)c2_c_i;
          if ((c2_i11 < 1) || (c2_i11 > c2_x_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i11, 1, c2_x_size[1],
              &c2_pc_emlrtBCI, &c2_st);
          }

          c2_value = (c2_x_data[c2_i11 - 1] - c2_x1) * (1.0 / (c2_x1 - c2_x0));
          c2_i14 = (int32_T)c2_c_i;
          if ((c2_i14 < 1) || (c2_i14 > c2_y_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i14, 1, c2_y_size[1],
              &c2_rc_emlrtBCI, &c2_st);
          }

          c2_y_data[c2_i14 - 1] = 1.0 - 2.0 * c2_value * c2_value;
        }
      }

      c2_i10 = (int32_T)c2_c_i;
      if ((c2_i10 < 1) || (c2_i10 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i10, 1, c2_x_size[1], &c2_qc_emlrtBCI,
          &c2_st);
      }

      if ((c2_x1 + c2_x0) / 2.0 < c2_x_data[c2_i10 - 1]) {
        c2_i12 = (int32_T)c2_c_i;
        if ((c2_i12 < 1) || (c2_i12 > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i12, 1, c2_x_size[1], &c2_sc_emlrtBCI,
            &c2_st);
        }

        if (c2_x_data[c2_i12 - 1] <= c2_x0) {
          c2_i15 = (int32_T)c2_c_i;
          if ((c2_i15 < 1) || (c2_i15 > c2_x_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i15, 1, c2_x_size[1],
              &c2_tc_emlrtBCI, &c2_st);
          }

          c2_value = (c2_x0 - c2_x_data[c2_i15 - 1]) * (1.0 / (c2_x1 - c2_x0));
          c2_i17 = (int32_T)c2_c_i;
          if ((c2_i17 < 1) || (c2_i17 > c2_y_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i17, 1, c2_y_size[1],
              &c2_vc_emlrtBCI, &c2_st);
          }

          c2_y_data[c2_i17 - 1] = 2.0 * c2_value * c2_value;
        }
      }

      c2_i13 = (int32_T)c2_c_i;
      if ((c2_i13 < 1) || (c2_i13 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i13, 1, c2_x_size[1], &c2_uc_emlrtBCI,
          &c2_st);
      }

      if (c2_x0 <= c2_x_data[c2_i13 - 1]) {
        c2_i16 = (int32_T)c2_c_i;
        if ((c2_i16 < 1) || (c2_i16 > c2_y_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i16, 1, c2_y_size[1], &c2_wc_emlrtBCI,
            &c2_st);
        }

        c2_y_data[c2_i16 - 1] = 0.0;
      }
    }
  }
}

static boolean_T c2_c_isequal(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, char_T c2_varargin_1_data[], int32_T c2_varargin_1_size[2],
  uint8_T c2_varargin_2[4])
{
  real_T c2_b_k;
  int32_T c2_k;
  char_T c2_x1;
  uint8_T c2_x2;
  boolean_T c2_b;
  boolean_T c2_b_p;
  boolean_T c2_c_p;
  boolean_T c2_d_p;
  boolean_T c2_e_p;
  boolean_T c2_exitg1;
  boolean_T c2_p;
  (void)chartInstance;
  c2_p = false;
  c2_b_p = false;
  if (!((real_T)c2_varargin_1_size[1] != 4.0)) {
    c2_b_p = true;
  }

  if (c2_b_p) {
    c2_c_p = true;
  } else {
    c2_c_p = false;
  }

  c2_d_p = c2_c_p;
  if (c2_c_p) {
    c2_b = (c2_varargin_1_size[1] == 0);
    if (!c2_b) {
      c2_k = 0;
      c2_exitg1 = false;
      while ((!c2_exitg1) && (c2_k < 4)) {
        c2_b_k = (real_T)c2_k + 1.0;
        c2_x1 = c2_varargin_1_data[(int32_T)c2_b_k - 1];
        c2_x2 = c2_varargin_2[(int32_T)c2_b_k - 1];
        c2_e_p = ((uint8_T)c2_x1 == c2_x2);
        if (!c2_e_p) {
          c2_d_p = false;
          c2_exitg1 = true;
        } else {
          c2_k++;
        }
      }
    }
  }

  if (c2_d_p) {
    c2_p = true;
  }

  return c2_p;
}

static void c2_pimf(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
                    const emlrtStack *c2_sp, real_T c2_x_data[], int32_T
                    c2_x_size[2], real_T c2_params_data[], int32_T
                    c2_params_size[2], real_T c2_y_data[], int32_T c2_y_size[2])
{
  emlrtStack c2_b_st;
  emlrtStack c2_st;
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_y = NULL;
  real_T c2_tmp_data[101];
  real_T c2_b_params[2];
  real_T c2_b_value;
  real_T c2_b_x0;
  real_T c2_b_x1;
  real_T c2_c_i;
  real_T c2_c_x0;
  real_T c2_d;
  real_T c2_d1;
  real_T c2_d_x0;
  real_T c2_e_i;
  real_T c2_value;
  real_T c2_x0;
  real_T c2_x1;
  int32_T c2_tmp_size[2];
  int32_T c2_b_i;
  int32_T c2_b_loop_ub;
  int32_T c2_c_loop_ub;
  int32_T c2_c_params;
  int32_T c2_d_i;
  int32_T c2_d_loop_ub;
  int32_T c2_e_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i19;
  int32_T c2_i2;
  int32_T c2_i20;
  int32_T c2_i21;
  int32_T c2_i22;
  int32_T c2_i23;
  int32_T c2_i24;
  int32_T c2_i25;
  int32_T c2_i26;
  int32_T c2_i27;
  int32_T c2_i28;
  int32_T c2_i29;
  int32_T c2_i3;
  int32_T c2_i30;
  int32_T c2_i31;
  int32_T c2_i32;
  int32_T c2_i33;
  int32_T c2_i34;
  int32_T c2_i35;
  int32_T c2_i36;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_loop_ub;
  int32_T c2_params;
  (void)chartInstance;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_st.site = &c2_vc_emlrtRSI;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_cv6, 10, 0U, 1U, 0U, 2, 1, 40),
                false);
  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", c2_cv6, 10, 0U, 1U, 0U, 2, 1, 40),
                false);
  sf_mex_call(&c2_st, &c2_v_emlrtMCI, "error", 0U, 2U, 14, c2_y, 14, sf_mex_call
              (&c2_st, NULL, "getString", 1U, 1U, 14, sf_mex_call(&c2_st, NULL,
    "message", 1U, 1U, 14, c2_b_y)));
  c2_st.site = &c2_wc_emlrtRSI;
  c2_params = c2_params_size[1];
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_i1 = c2_i + 1;
    if ((c2_i1 < 1) || (c2_i1 > c2_params)) {
      emlrtDynamicBoundsCheckR2012b(c2_i1, 1, c2_params, &c2_xc_emlrtBCI, &c2_st);
    }

    c2_b_params[c2_i] = c2_params_data[c2_i1 - 1];
  }

  c2_b_st.site = &c2_lc_emlrtRSI;
  c2_x0 = c2_b_params[0];
  c2_x1 = c2_b_params[1];
  if (c2_x0 >= c2_x1) {
    c2_y_size[0] = 1;
    c2_y_size[1] = c2_x_size[1];
    c2_b_x0 = (c2_x0 + c2_x1) / 2.0;
    c2_loop_ub = c2_x_size[0] * c2_x_size[1] - 1;
    for (c2_i3 = 0; c2_i3 <= c2_loop_ub; c2_i3++) {
      c2_y_data[c2_i3] = (real_T)(c2_x_data[c2_i3] >= c2_b_x0);
    }
  } else {
    for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
      c2_b_params[c2_i2] = (real_T)c2_x_size[c2_i2];
    }

    c2_y_size[0] = 1;
    c2_y_size[1] = (int32_T)c2_b_params[1];
    c2_b_loop_ub = (int32_T)c2_b_params[1] - 1;
    for (c2_i4 = 0; c2_i4 <= c2_b_loop_ub; c2_i4++) {
      c2_y_data[c2_i4] = 0.0;
    }

    c2_d = (real_T)c2_x_size[1];
    c2_i5 = (int32_T)c2_d - 1;
    for (c2_b_i = 0; c2_b_i <= c2_i5; c2_b_i++) {
      c2_c_i = (real_T)c2_b_i + 1.0;
      c2_i8 = (int32_T)c2_c_i;
      if ((c2_i8 < 1) || (c2_i8 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i8, 1, c2_x_size[1], &c2_yb_emlrtBCI,
          &c2_b_st);
      }

      if (c2_x0 < c2_x_data[c2_i8 - 1]) {
        c2_i10 = (int32_T)c2_c_i;
        if ((c2_i10 < 1) || (c2_i10 > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i10, 1, c2_x_size[1], &c2_ac_emlrtBCI,
            &c2_b_st);
        }

        if (c2_x_data[c2_i10 - 1] <= (c2_x0 + c2_x1) / 2.0) {
          c2_i14 = (int32_T)c2_c_i;
          if ((c2_i14 < 1) || (c2_i14 > c2_x_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i14, 1, c2_x_size[1],
              &c2_bc_emlrtBCI, &c2_b_st);
          }

          c2_value = (c2_x_data[c2_i14 - 1] - c2_x0) * (1.0 / (c2_x1 - c2_x0));
          c2_i19 = (int32_T)c2_c_i;
          if ((c2_i19 < 1) || (c2_i19 > c2_y_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i19, 1, c2_y_size[1],
              &c2_dc_emlrtBCI, &c2_b_st);
          }

          c2_y_data[c2_i19 - 1] = 2.0 * c2_value * c2_value;
        }
      }

      c2_i11 = (int32_T)c2_c_i;
      if ((c2_i11 < 1) || (c2_i11 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i11, 1, c2_x_size[1], &c2_cc_emlrtBCI,
          &c2_b_st);
      }

      if ((c2_x0 + c2_x1) / 2.0 < c2_x_data[c2_i11 - 1]) {
        c2_i15 = (int32_T)c2_c_i;
        if ((c2_i15 < 1) || (c2_i15 > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i15, 1, c2_x_size[1], &c2_ec_emlrtBCI,
            &c2_b_st);
        }

        if (c2_x_data[c2_i15 - 1] <= c2_x1) {
          c2_i20 = (int32_T)c2_c_i;
          if ((c2_i20 < 1) || (c2_i20 > c2_x_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i20, 1, c2_x_size[1],
              &c2_fc_emlrtBCI, &c2_b_st);
          }

          c2_value = (c2_x1 - c2_x_data[c2_i20 - 1]) * (1.0 / (c2_x1 - c2_x0));
          c2_i25 = (int32_T)c2_c_i;
          if ((c2_i25 < 1) || (c2_i25 > c2_y_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i25, 1, c2_y_size[1],
              &c2_hc_emlrtBCI, &c2_b_st);
          }

          c2_y_data[c2_i25 - 1] = 1.0 - 2.0 * c2_value * c2_value;
        }
      }

      c2_i16 = (int32_T)c2_c_i;
      if ((c2_i16 < 1) || (c2_i16 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i16, 1, c2_x_size[1], &c2_gc_emlrtBCI,
          &c2_b_st);
      }

      if (c2_x1 <= c2_x_data[c2_i16 - 1]) {
        c2_i22 = (int32_T)c2_c_i;
        if ((c2_i22 < 1) || (c2_i22 > c2_y_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i22, 1, c2_y_size[1], &c2_ic_emlrtBCI,
            &c2_b_st);
        }

        c2_y_data[c2_i22 - 1] = 1.0;
      }
    }
  }

  c2_st.site = &c2_wc_emlrtRSI;
  c2_c_params = c2_params_size[1];
  for (c2_i6 = 0; c2_i6 < 2; c2_i6++) {
    c2_i7 = (int32_T)(3.0 + (real_T)c2_i6);
    if ((c2_i7 < 1) || (c2_i7 > c2_c_params)) {
      emlrtDynamicBoundsCheckR2012b(c2_i7, 1, c2_c_params, &c2_yc_emlrtBCI,
        &c2_st);
    }

    c2_b_params[c2_i6] = c2_params_data[c2_i7 - 1];
  }

  c2_b_st.site = &c2_nc_emlrtRSI;
  c2_b_x1 = c2_b_params[0];
  c2_c_x0 = c2_b_params[1];
  if (c2_b_x1 >= c2_c_x0) {
    c2_tmp_size[0] = 1;
    c2_tmp_size[1] = c2_x_size[1];
    c2_d_x0 = (c2_c_x0 + c2_b_x1) / 2.0;
    c2_c_loop_ub = c2_x_size[0] * c2_x_size[1] - 1;
    for (c2_i12 = 0; c2_i12 <= c2_c_loop_ub; c2_i12++) {
      c2_tmp_data[c2_i12] = (real_T)(c2_x_data[c2_i12] <= c2_d_x0);
    }
  } else {
    for (c2_i9 = 0; c2_i9 < 2; c2_i9++) {
      c2_b_params[c2_i9] = (real_T)c2_x_size[c2_i9];
    }

    c2_tmp_size[0] = 1;
    c2_tmp_size[1] = (int32_T)c2_b_params[1];
    c2_d_loop_ub = (int32_T)c2_b_params[1] - 1;
    for (c2_i13 = 0; c2_i13 <= c2_d_loop_ub; c2_i13++) {
      c2_tmp_data[c2_i13] = 0.0;
    }

    c2_d1 = (real_T)c2_x_size[1];
    c2_i17 = (int32_T)c2_d1 - 1;
    for (c2_d_i = 0; c2_d_i <= c2_i17; c2_d_i++) {
      c2_e_i = (real_T)c2_d_i + 1.0;
      c2_i23 = (int32_T)c2_e_i;
      if ((c2_i23 < 1) || (c2_i23 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i23, 1, c2_x_size[1], &c2_lc_emlrtBCI,
          &c2_b_st);
      }

      if (c2_x_data[c2_i23 - 1] <= c2_b_x1) {
        c2_i26 = (int32_T)c2_e_i;
        if ((c2_i26 < 1) || (c2_i26 > c2_tmp_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i26, 1, c2_tmp_size[1],
            &c2_mc_emlrtBCI, &c2_b_st);
        }

        c2_tmp_data[c2_i26 - 1] = 1.0;
      }

      c2_i27 = (int32_T)c2_e_i;
      if ((c2_i27 < 1) || (c2_i27 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i27, 1, c2_x_size[1], &c2_nc_emlrtBCI,
          &c2_b_st);
      }

      if (c2_b_x1 < c2_x_data[c2_i27 - 1]) {
        c2_i28 = (int32_T)c2_e_i;
        if ((c2_i28 < 1) || (c2_i28 > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i28, 1, c2_x_size[1], &c2_oc_emlrtBCI,
            &c2_b_st);
        }

        if (c2_x_data[c2_i28 - 1] <= (c2_b_x1 + c2_c_x0) / 2.0) {
          c2_i30 = (int32_T)c2_e_i;
          if ((c2_i30 < 1) || (c2_i30 > c2_x_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i30, 1, c2_x_size[1],
              &c2_pc_emlrtBCI, &c2_b_st);
          }

          c2_b_value = (c2_x_data[c2_i30 - 1] - c2_b_x1) * (1.0 / (c2_b_x1 -
            c2_c_x0));
          c2_i33 = (int32_T)c2_e_i;
          if ((c2_i33 < 1) || (c2_i33 > c2_tmp_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i33, 1, c2_tmp_size[1],
              &c2_rc_emlrtBCI, &c2_b_st);
          }

          c2_tmp_data[c2_i33 - 1] = 1.0 - 2.0 * c2_b_value * c2_b_value;
        }
      }

      c2_i29 = (int32_T)c2_e_i;
      if ((c2_i29 < 1) || (c2_i29 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i29, 1, c2_x_size[1], &c2_qc_emlrtBCI,
          &c2_b_st);
      }

      if ((c2_b_x1 + c2_c_x0) / 2.0 < c2_x_data[c2_i29 - 1]) {
        c2_i31 = (int32_T)c2_e_i;
        if ((c2_i31 < 1) || (c2_i31 > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i31, 1, c2_x_size[1], &c2_sc_emlrtBCI,
            &c2_b_st);
        }

        if (c2_x_data[c2_i31 - 1] <= c2_c_x0) {
          c2_i34 = (int32_T)c2_e_i;
          if ((c2_i34 < 1) || (c2_i34 > c2_x_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i34, 1, c2_x_size[1],
              &c2_tc_emlrtBCI, &c2_b_st);
          }

          c2_b_value = (c2_c_x0 - c2_x_data[c2_i34 - 1]) * (1.0 / (c2_b_x1 -
            c2_c_x0));
          c2_i36 = (int32_T)c2_e_i;
          if ((c2_i36 < 1) || (c2_i36 > c2_tmp_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i36, 1, c2_tmp_size[1],
              &c2_vc_emlrtBCI, &c2_b_st);
          }

          c2_tmp_data[c2_i36 - 1] = 2.0 * c2_b_value * c2_b_value;
        }
      }

      c2_i32 = (int32_T)c2_e_i;
      if ((c2_i32 < 1) || (c2_i32 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i32, 1, c2_x_size[1], &c2_uc_emlrtBCI,
          &c2_b_st);
      }

      if (c2_c_x0 <= c2_x_data[c2_i32 - 1]) {
        c2_i35 = (int32_T)c2_e_i;
        if ((c2_i35 < 1) || (c2_i35 > c2_tmp_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i35, 1, c2_tmp_size[1],
            &c2_wc_emlrtBCI, &c2_b_st);
        }

        c2_tmp_data[c2_i35 - 1] = 0.0;
      }
    }
  }

  if ((c2_y_size[0] != c2_tmp_size[0]) || (c2_y_size[1] != c2_tmp_size[1])) {
    emlrtSizeEqCheckNDR2012b(&c2_y_size[0], &c2_tmp_size[0], &c2_m_emlrtECI,
      (void *)c2_sp);
  }

  c2_i18 = c2_y_size[0] * c2_y_size[1];
  c2_y_size[0] = 1;
  c2_i21 = c2_i18;
  c2_e_loop_ub = c2_i21 - 1;
  for (c2_i24 = 0; c2_i24 <= c2_e_loop_ub; c2_i24++) {
    c2_y_data[c2_i24] *= c2_tmp_data[c2_i24];
  }
}

static void c2_b_extractVarMF(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_s_64TxJFgCtXBlX73DcwNLAB c2_varin
  [2], c2_cell_wrap_0 c2_varout[2])
{
  c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm c2_r1;
  c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm c2_r3;
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 c2_mf;
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 c2_r;
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 c2_r2;
  c2_s_JbR9CE1JwmiHOtKI7rv0ED c2_r4;
  c2_s_JbR9CE1JwmiHOtKI7rv0ED c2_r5;
  real_T c2_b_tmp_data[3];
  int32_T c2_b_tmp_size[2];
  int32_T c2_tmp_size[2];
  int32_T c2_b_j;
  int32_T c2_b_loop_ub;
  int32_T c2_c_j;
  int32_T c2_c_loop_ub;
  int32_T c2_d_loop_ub;
  int32_T c2_e_loop_ub;
  int32_T c2_f_loop_ub;
  int32_T c2_g_loop_ub;
  int32_T c2_h_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i19;
  int32_T c2_i2;
  int32_T c2_i20;
  int32_T c2_i21;
  int32_T c2_i22;
  int32_T c2_i23;
  int32_T c2_i24;
  int32_T c2_i25;
  int32_T c2_i26;
  int32_T c2_i27;
  int32_T c2_i28;
  int32_T c2_i29;
  int32_T c2_i3;
  int32_T c2_i30;
  int32_T c2_i31;
  int32_T c2_i32;
  int32_T c2_i33;
  int32_T c2_i34;
  int32_T c2_i35;
  int32_T c2_i36;
  int32_T c2_i37;
  int32_T c2_i38;
  int32_T c2_i39;
  int32_T c2_i4;
  int32_T c2_i40;
  int32_T c2_i41;
  int32_T c2_i42;
  int32_T c2_i43;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_i_loop_ub;
  int32_T c2_j;
  int32_T c2_j_loop_ub;
  int32_T c2_k_loop_ub;
  int32_T c2_l_loop_ub;
  int32_T c2_loop_ub;
  int32_T c2_m_loop_ub;
  int32_T c2_n_loop_ub;
  int32_T c2_o_loop_ub;
  int32_T c2_p_loop_ub;
  int32_T c2_q_loop_ub;
  int32_T c2_r_loop_ub;
  char_T c2_tmp_data[5];
  boolean_T c2_b;
  boolean_T c2_b1;
  boolean_T c2_b2;
  boolean_T c2_b3;
  (void)chartInstance;
  c2_r.size[0] = 1;
  c2_r.size[1] = c2_varin[0].origNumMF;
  c2_mf.size[0] = c2_r.size[0];
  c2_mf.size[1] = c2_r.size[1];
  c2_i = c2_varin[0].origNumMF - 1;
  for (c2_j = 1; c2_j - 1 <= c2_i; c2_j++) {
    c2_b_j = c2_j;
    c2_r1.size[1] = c2_varin[0].mf.size[1];
    c2_b_loop_ub = c2_varin[0].mf.size[0] * c2_varin[0].mf.size[1] - 1;
    for (c2_i2 = 0; c2_i2 <= c2_b_loop_ub; c2_i2++) {
      c2_r1.data[c2_i2] = c2_varin[0].mf.data[c2_i2];
    }

    c2_r3.size[1] = c2_varin[0].mf.size[1];
    c2_c_loop_ub = c2_varin[0].mf.size[0] * c2_varin[0].mf.size[1] - 1;
    for (c2_i3 = 0; c2_i3 <= c2_c_loop_ub; c2_i3++) {
      c2_r3.data[c2_i3] = c2_varin[0].mf.data[c2_i3];
    }

    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_ad_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i5 = c2_b_j - 1;
    c2_tmp_size[1] = c2_r1.data[c2_i5].type.size[1];
    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_ad_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i6 = c2_b_j - 1;
    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_ad_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i9 = c2_b_j - 1;
    c2_g_loop_ub = c2_r1.data[c2_i6].type.size[0] * c2_r1.data[c2_i9].type.size
      [1] - 1;
    for (c2_i11 = 0; c2_i11 <= c2_g_loop_ub; c2_i11++) {
      if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_dd_emlrtBCI,
          (void *)c2_sp);
      }

      c2_tmp_data[c2_i11] = c2_r1.data[c2_b_j - 1].type.data[c2_i11];
    }

    if ((c2_b_j < 1) || (c2_b_j > c2_r3.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r3.size[1], &c2_ab_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i13 = c2_r3.data[c2_b_j - 1].origTypeLength;
    c2_b = (1 > c2_i13);
    if (c2_b) {
      c2_i14 = -1;
    } else {
      if (1 > c2_tmp_size[1]) {
        emlrtDynamicBoundsCheckR2012b(1, 1, c2_tmp_size[1], &c2_y_emlrtBCI,
          (void *)c2_sp);
      }

      if ((c2_i13 < 1) || (c2_i13 > c2_tmp_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i13, 1, c2_tmp_size[1], &c2_ab_emlrtBCI,
          (void *)c2_sp);
      }

      c2_i14 = c2_i13 - 1;
    }

    c2_r1.size[1] = c2_varin[0].mf.size[1];
    c2_h_loop_ub = c2_varin[0].mf.size[0] * c2_varin[0].mf.size[1] - 1;
    for (c2_i17 = 0; c2_i17 <= c2_h_loop_ub; c2_i17++) {
      c2_r1.data[c2_i17] = c2_varin[0].mf.data[c2_i17];
    }

    c2_r3.size[1] = c2_varin[0].mf.size[1];
    c2_j_loop_ub = c2_varin[0].mf.size[0] * c2_varin[0].mf.size[1] - 1;
    for (c2_i19 = 0; c2_i19 <= c2_j_loop_ub; c2_i19++) {
      c2_r3.data[c2_i19] = c2_varin[0].mf.data[c2_i19];
    }

    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_bd_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i21 = c2_b_j - 1;
    c2_b_tmp_size[1] = c2_r1.data[c2_i21].params.size[1];
    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_bd_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i23 = c2_b_j - 1;
    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_bd_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i25 = c2_b_j - 1;
    c2_m_loop_ub = c2_r1.data[c2_i23].params.size[0] * c2_r1.data[c2_i25].
      params.size[1] - 1;
    for (c2_i27 = 0; c2_i27 <= c2_m_loop_ub; c2_i27++) {
      if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_ed_emlrtBCI,
          (void *)c2_sp);
      }

      c2_b_tmp_data[c2_i27] = c2_r1.data[c2_b_j - 1].params.data[c2_i27];
    }

    if ((c2_b_j < 1) || (c2_b_j > c2_r3.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r3.size[1], &c2_cb_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i29 = c2_r3.data[c2_b_j - 1].origParamLength;
    c2_b2 = (1 > c2_i29);
    if (c2_b2) {
      c2_i30 = -1;
    } else {
      if (1 > c2_b_tmp_size[1]) {
        emlrtDynamicBoundsCheckR2012b(1, 1, c2_b_tmp_size[1], &c2_bb_emlrtBCI,
          (void *)c2_sp);
      }

      if ((c2_i29 < 1) || (c2_i29 > c2_b_tmp_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i29, 1, c2_b_tmp_size[1],
          &c2_cb_emlrtBCI, (void *)c2_sp);
      }

      c2_i30 = c2_i29 - 1;
    }

    c2_r4.type.size[0] = 1;
    c2_r4.type.size[1] = c2_i14 + 1;
    c2_n_loop_ub = c2_i14;
    for (c2_i33 = 0; c2_i33 <= c2_n_loop_ub; c2_i33++) {
      c2_r4.type.data[c2_i33] = c2_tmp_data[c2_i33];
    }

    c2_r4.params.size[0] = 1;
    c2_r4.params.size[1] = c2_i30 + 1;
    c2_p_loop_ub = c2_i30;
    for (c2_i36 = 0; c2_i36 <= c2_p_loop_ub; c2_i36++) {
      c2_r4.params.data[c2_i36] = c2_b_tmp_data[c2_i36];
    }

    c2_i37 = c2_mf.size[1] - 1;
    c2_i39 = c2_b_j - 1;
    if ((c2_i39 < 0) || (c2_i39 > c2_i37)) {
      emlrtDynamicBoundsCheckR2012b(c2_i39, 0, c2_i37, &c2_cd_emlrtBCI, (void *)
        c2_sp);
    }

    c2_mf.data[c2_i39] = c2_r4;
  }

  c2_varout[0].f1.size[0] = 1;
  c2_varout[0].f1.size[1] = c2_mf.size[1];
  c2_loop_ub = c2_mf.size[0] * c2_mf.size[1] - 1;
  for (c2_i1 = 0; c2_i1 <= c2_loop_ub; c2_i1++) {
    c2_varout[0].f1.data[c2_i1] = c2_mf.data[c2_i1];
  }

  c2_r2.size[0] = 1;
  c2_r2.size[1] = c2_varin[1].origNumMF;
  c2_mf.size[0] = c2_r2.size[0];
  c2_mf.size[1] = c2_r2.size[1];
  c2_i4 = c2_varin[1].origNumMF - 1;
  for (c2_c_j = 1; c2_c_j - 1 <= c2_i4; c2_c_j++) {
    c2_b_j = c2_c_j;
    c2_r1.size[1] = c2_varin[1].mf.size[1];
    c2_e_loop_ub = c2_varin[1].mf.size[0] * c2_varin[1].mf.size[1] - 1;
    for (c2_i8 = 0; c2_i8 <= c2_e_loop_ub; c2_i8++) {
      c2_r1.data[c2_i8] = c2_varin[1].mf.data[c2_i8];
    }

    c2_r3.size[1] = c2_varin[1].mf.size[1];
    c2_f_loop_ub = c2_varin[1].mf.size[0] * c2_varin[1].mf.size[1] - 1;
    for (c2_i10 = 0; c2_i10 <= c2_f_loop_ub; c2_i10++) {
      c2_r3.data[c2_i10] = c2_varin[1].mf.data[c2_i10];
    }

    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_ad_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i12 = c2_b_j - 1;
    c2_tmp_size[1] = c2_r1.data[c2_i12].type.size[1];
    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_ad_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i15 = c2_b_j - 1;
    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_ad_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i16 = c2_b_j - 1;
    c2_i_loop_ub = c2_r1.data[c2_i15].type.size[0] * c2_r1.data[c2_i16].
      type.size[1] - 1;
    for (c2_i18 = 0; c2_i18 <= c2_i_loop_ub; c2_i18++) {
      if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_dd_emlrtBCI,
          (void *)c2_sp);
      }

      c2_tmp_data[c2_i18] = c2_r1.data[c2_b_j - 1].type.data[c2_i18];
    }

    if ((c2_b_j < 1) || (c2_b_j > c2_r3.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r3.size[1], &c2_ab_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i20 = c2_r3.data[c2_b_j - 1].origTypeLength;
    c2_b1 = (1 > c2_i20);
    if (c2_b1) {
      c2_i22 = -1;
    } else {
      if (1 > c2_tmp_size[1]) {
        emlrtDynamicBoundsCheckR2012b(1, 1, c2_tmp_size[1], &c2_y_emlrtBCI,
          (void *)c2_sp);
      }

      if ((c2_i20 < 1) || (c2_i20 > c2_tmp_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i20, 1, c2_tmp_size[1], &c2_ab_emlrtBCI,
          (void *)c2_sp);
      }

      c2_i22 = c2_i20 - 1;
    }

    c2_r1.size[1] = c2_varin[1].mf.size[1];
    c2_k_loop_ub = c2_varin[1].mf.size[0] * c2_varin[1].mf.size[1] - 1;
    for (c2_i24 = 0; c2_i24 <= c2_k_loop_ub; c2_i24++) {
      c2_r1.data[c2_i24] = c2_varin[1].mf.data[c2_i24];
    }

    c2_r3.size[1] = c2_varin[1].mf.size[1];
    c2_l_loop_ub = c2_varin[1].mf.size[0] * c2_varin[1].mf.size[1] - 1;
    for (c2_i26 = 0; c2_i26 <= c2_l_loop_ub; c2_i26++) {
      c2_r3.data[c2_i26] = c2_varin[1].mf.data[c2_i26];
    }

    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_bd_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i28 = c2_b_j - 1;
    c2_b_tmp_size[1] = c2_r1.data[c2_i28].params.size[1];
    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_bd_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i31 = c2_b_j - 1;
    if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_bd_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i32 = c2_b_j - 1;
    c2_o_loop_ub = c2_r1.data[c2_i31].params.size[0] * c2_r1.data[c2_i32].
      params.size[1] - 1;
    for (c2_i34 = 0; c2_i34 <= c2_o_loop_ub; c2_i34++) {
      if ((c2_b_j < 1) || (c2_b_j > c2_r1.size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r1.size[1], &c2_ed_emlrtBCI,
          (void *)c2_sp);
      }

      c2_b_tmp_data[c2_i34] = c2_r1.data[c2_b_j - 1].params.data[c2_i34];
    }

    if ((c2_b_j < 1) || (c2_b_j > c2_r3.size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_b_j, 1, c2_r3.size[1], &c2_cb_emlrtBCI,
        (void *)c2_sp);
    }

    c2_i35 = c2_r3.data[c2_b_j - 1].origParamLength;
    c2_b3 = (1 > c2_i35);
    if (c2_b3) {
      c2_i38 = -1;
    } else {
      if (1 > c2_b_tmp_size[1]) {
        emlrtDynamicBoundsCheckR2012b(1, 1, c2_b_tmp_size[1], &c2_bb_emlrtBCI,
          (void *)c2_sp);
      }

      if ((c2_i35 < 1) || (c2_i35 > c2_b_tmp_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i35, 1, c2_b_tmp_size[1],
          &c2_cb_emlrtBCI, (void *)c2_sp);
      }

      c2_i38 = c2_i35 - 1;
    }

    c2_r5.type.size[0] = 1;
    c2_r5.type.size[1] = c2_i22 + 1;
    c2_q_loop_ub = c2_i22;
    for (c2_i40 = 0; c2_i40 <= c2_q_loop_ub; c2_i40++) {
      c2_r5.type.data[c2_i40] = c2_tmp_data[c2_i40];
    }

    c2_r5.params.size[0] = 1;
    c2_r5.params.size[1] = c2_i38 + 1;
    c2_r_loop_ub = c2_i38;
    for (c2_i41 = 0; c2_i41 <= c2_r_loop_ub; c2_i41++) {
      c2_r5.params.data[c2_i41] = c2_b_tmp_data[c2_i41];
    }

    c2_i42 = c2_mf.size[1] - 1;
    c2_i43 = c2_b_j - 1;
    if ((c2_i43 < 0) || (c2_i43 > c2_i42)) {
      emlrtDynamicBoundsCheckR2012b(c2_i43, 0, c2_i42, &c2_cd_emlrtBCI, (void *)
        c2_sp);
    }

    c2_mf.data[c2_i43] = c2_r5;
  }

  c2_varout[1].f1.size[0] = 1;
  c2_varout[1].f1.size[1] = c2_mf.size[1];
  c2_d_loop_ub = c2_mf.size[0] * c2_mf.size[1] - 1;
  for (c2_i7 = 0; c2_i7 <= c2_d_loop_ub; c2_i7++) {
    c2_varout[1].f1.data[c2_i7] = c2_mf.data[c2_i7];
  }
}

static real_T c2_b_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance)
{
  real_T c2_y;
  (void)chartInstance;
  c2_y = 5.0;
  c2_y += 5.0;
  return c2_y;
}

static void c2_applyOperators(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_fuzzifiedInputs_data[],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_varargin_1_data[], real_T
  c2_varargin_2_data[], real_T c2_antecedentOutputs_data[], int32_T
  c2_antecedentOutputs_size[1], real_T *c2_sumAntecedentOutputs, real_T
  c2_irrOfOneRule_data[], int32_T c2_irrOfOneRule_size[1])
{
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_b_fis;
  real_T c2_b_fuzzifiedInputs_data[48];
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  c2_antecedentOutputs_size[0] = 24;
  for (c2_i = 0; c2_i < 24; c2_i++) {
    c2_antecedentOutputs_data[c2_i] = c2_varargin_1_data[c2_i];
  }

  c2_irrOfOneRule_size[0] = 2;
  for (c2_i1 = 0; c2_i1 < 2; c2_i1++) {
    c2_irrOfOneRule_data[c2_i1] = c2_varargin_2_data[c2_i1];
  }

  for (c2_i2 = 0; c2_i2 < 48; c2_i2++) {
    c2_b_fuzzifiedInputs_data[c2_i2] = c2_fuzzifiedInputs_data[c2_i2];
  }

  c2_b_fis = *c2_fis;
  *c2_sumAntecedentOutputs = c2_b_applyOperators(chartInstance, c2_sp,
    c2_b_fuzzifiedInputs_data, &c2_b_fis, c2_antecedentOutputs_data,
    c2_irrOfOneRule_data);
}

static real_T c2_c_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, real_T c2_x_data[], int32_T c2_vlen)
{
  real_T c2_y;
  int32_T c2_b_k;
  int32_T c2_b_vlen;
  int32_T c2_i;
  int32_T c2_k;
  (void)chartInstance;
  c2_b_vlen = c2_vlen - 1;
  c2_y = c2_x_data[0];
  c2_i = c2_b_vlen - 1;
  for (c2_k = 1; c2_k - 1 <= c2_i; c2_k++) {
    c2_b_k = c2_k;
    c2_y += c2_x_data[c2_b_k];
  }

  return c2_y;
}

static void c2_applyMamdaniImplicationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_antecedentOutputs_data[], c2_s_9DL33rUTgryGqqXf4f6A1E
   *c2_fis, c2_emxArray_real_T *c2_varargin_1, real_T c2_consequentOutputs_data[],
   int32_T c2_consequentOutputs_size[2])
{
  static char_T c2_d_varargin_1[11] = { 'i', 'm', 'p', 'l', 'i', 'c', 'a', 't',
    'i', 'o', 'n' };

  static char_T c2_b_cv[7] = { 'f', 'p', 'r', 'i', 'n', 't', 'f' };

  static uint8_T c2_uv[3] = { 109U, 105U, 110U };

  emlrtStack c2_b_st;
  emlrtStack c2_c_st;
  emlrtStack c2_st;
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_e_y = NULL;
  const mxArray *c2_f_y = NULL;
  real_T c2_e_varargin_1[2];
  real_T c2_x_data[2];
  real_T c2_b_k;
  real_T c2_b_x;
  real_T c2_c_x;
  real_T c2_d;
  real_T c2_d_x;
  real_T c2_e_x;
  real_T c2_minval;
  real_T c2_u;
  real_T c2_x;
  real_T c2_y;
  int32_T c2_iv[2];
  int32_T c2_b_ruleID;
  int32_T c2_b_sampleID;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_k;
  int32_T c2_loop_ub;
  int32_T c2_mfIndex;
  int32_T c2_ruleID;
  int32_T c2_sampleID;
  char_T c2_c_varargin_1[3];
  uint8_T c2_b_varargin_1[3];
  uint8_T c2_x1;
  uint8_T c2_x2;
  boolean_T c2_b;
  boolean_T c2_b_b;
  boolean_T c2_b_p;
  boolean_T c2_c_p;
  boolean_T c2_exitg1;
  boolean_T c2_p;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_c_st.prev = &c2_b_st;
  c2_c_st.tls = c2_b_st.tls;
  for (c2_i = 0; c2_i < 3; c2_i++) {
    c2_b_varargin_1[c2_i] = c2_fis->impMethod[c2_i];
  }

  c2_p = false;
  c2_b_p = true;
  c2_k = 0;
  c2_exitg1 = false;
  while ((!c2_exitg1) && (c2_k < 3)) {
    c2_b_k = (real_T)c2_k + 1.0;
    c2_x1 = c2_b_varargin_1[(int32_T)c2_b_k - 1];
    c2_x2 = c2_uv[(int32_T)c2_b_k - 1];
    c2_c_p = (c2_x1 == c2_x2);
    if (!c2_c_p) {
      c2_b_p = false;
      c2_exitg1 = true;
    } else {
      c2_k++;
    }
  }

  if (c2_b_p) {
    c2_p = true;
  }

  if (c2_p) {
    c2_st.site = &c2_ud_emlrtRSI;
    for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
      c2_iv[c2_i2] = c2_fis->orrSize[c2_i2];
    }

    c2_consequentOutputs_size[0] = c2_iv[0];
    c2_consequentOutputs_size[1] = c2_iv[1];
    for (c2_ruleID = 0; c2_ruleID < 24; c2_ruleID++) {
      c2_b_ruleID = c2_ruleID;
      c2_x = c2_fis->consequent[c2_b_ruleID];
      c2_b_x = c2_x;
      c2_c_x = c2_b_x;
      c2_y = c2_c_x;
      c2_d = muDoubleScalarRound(c2_y);
      if (c2_d < 2.147483648E+9) {
        if (c2_d >= -2.147483648E+9) {
          c2_i6 = (int32_T)c2_d;
        } else {
          c2_i6 = MIN_int32_T;
          sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
        }
      } else if (c2_d >= 2.147483648E+9) {
        c2_i6 = MAX_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      } else {
        c2_i6 = 0;
      }

      c2_mfIndex = c2_i6;
      for (c2_sampleID = 0; c2_sampleID < 101; c2_sampleID++) {
        c2_b_sampleID = c2_sampleID + 1;
        c2_i7 = c2_varargin_1->size[0];
        if ((c2_mfIndex < 1) || (c2_mfIndex > c2_i7)) {
          emlrtDynamicBoundsCheckR2012b(c2_mfIndex, 1, c2_i7, &c2_fd_emlrtBCI,
            &c2_st);
        }

        c2_i8 = c2_varargin_1->size[1];
        if ((c2_b_sampleID < 1) || (c2_b_sampleID > c2_i8)) {
          emlrtDynamicBoundsCheckR2012b(c2_b_sampleID, 1, c2_i8, &c2_fd_emlrtBCI,
            &c2_st);
        }

        if ((c2_b_sampleID < 1) || (c2_b_sampleID > c2_consequentOutputs_size[0]))
        {
          emlrtDynamicBoundsCheckR2012b(c2_b_sampleID, 1,
            c2_consequentOutputs_size[0], &c2_gd_emlrtBCI, &c2_st);
        }

        c2_i9 = c2_b_ruleID + 1;
        if ((c2_i9 < 1) || (c2_i9 > c2_consequentOutputs_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i9, 1, c2_consequentOutputs_size[1],
            &c2_gd_emlrtBCI, &c2_st);
        }

        c2_consequentOutputs_data[(c2_b_sampleID + c2_consequentOutputs_size[0] *
          (c2_i9 - 1)) - 1] = c2_varargin_1->data[(c2_mfIndex +
          c2_varargin_1->size[0] * (c2_b_sampleID - 1)) - 1];
        if ((c2_b_sampleID < 1) || (c2_b_sampleID > c2_consequentOutputs_size[0]))
        {
          emlrtDynamicBoundsCheckR2012b(c2_b_sampleID, 1,
            c2_consequentOutputs_size[0], &c2_hd_emlrtBCI, &c2_st);
        }

        c2_i10 = c2_b_ruleID + 1;
        if ((c2_i10 < 1) || (c2_i10 > c2_consequentOutputs_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i10, 1, c2_consequentOutputs_size[1],
            &c2_hd_emlrtBCI, &c2_st);
        }

        c2_e_varargin_1[0] = c2_consequentOutputs_data[(c2_b_sampleID +
          c2_consequentOutputs_size[0] * (c2_i10 - 1)) - 1];
        c2_e_varargin_1[1] = c2_antecedentOutputs_data[c2_b_ruleID];
        for (c2_i11 = 0; c2_i11 < 2; c2_i11++) {
          c2_x_data[c2_i11] = c2_e_varargin_1[c2_i11];
        }

        if (c2_x_data[0] > c2_x_data[1]) {
          c2_minval = c2_x_data[1];
        } else {
          c2_d_x = c2_x_data[0];
          c2_b = muDoubleScalarIsNaN(c2_d_x);
          if (c2_b) {
            c2_e_x = c2_x_data[1];
            c2_b_b = muDoubleScalarIsNaN(c2_e_x);
            if (!c2_b_b) {
              c2_minval = c2_x_data[1];
            } else {
              c2_minval = c2_x_data[0];
            }
          } else {
            c2_minval = c2_x_data[0];
          }
        }

        if ((c2_b_sampleID < 1) || (c2_b_sampleID > c2_consequentOutputs_size[0]))
        {
          emlrtDynamicBoundsCheckR2012b(c2_b_sampleID, 1,
            c2_consequentOutputs_size[0], &c2_id_emlrtBCI, &c2_st);
        }

        c2_i12 = c2_b_ruleID + 1;
        if ((c2_i12 < 1) || (c2_i12 > c2_consequentOutputs_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i12, 1, c2_consequentOutputs_size[1],
            &c2_id_emlrtBCI, &c2_st);
        }

        c2_consequentOutputs_data[(c2_b_sampleID + c2_consequentOutputs_size[0] *
          (c2_i12 - 1)) - 1] = c2_minval;
      }
    }
  } else {
    for (c2_i1 = 0; c2_i1 < 2; c2_i1++) {
      c2_iv[c2_i1] = c2_fis->orrSize[c2_i1];
    }

    c2_consequentOutputs_size[0] = c2_iv[0];
    c2_consequentOutputs_size[1] = c2_iv[1];
    c2_loop_ub = c2_iv[0] * c2_iv[1] - 1;
    for (c2_i3 = 0; c2_i3 <= c2_loop_ub; c2_i3++) {
      c2_consequentOutputs_data[c2_i3] = 0.0;
    }

    c2_st.site = &c2_vd_emlrtRSI;
    for (c2_i4 = 0; c2_i4 < 3; c2_i4++) {
      c2_b_varargin_1[c2_i4] = c2_fis->impMethod[c2_i4];
    }

    for (c2_i5 = 0; c2_i5 < 3; c2_i5++) {
      c2_c_varargin_1[c2_i5] = (char_T)(int8_T)c2_b_varargin_1[c2_i5];
    }

    c2_b_st.site = &c2_xc_emlrtRSI;
    c2_b_y = NULL;
    sf_mex_assign(&c2_b_y, sf_mex_create("y", c2_b_cv, 10, 0U, 1U, 0U, 2, 1, 7),
                  false);
    c2_u = 1.0;
    c2_c_y = NULL;
    sf_mex_assign(&c2_c_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0), false);
    c2_d_y = NULL;
    sf_mex_assign(&c2_d_y, sf_mex_create("y", c2_cv2, 10, 0U, 1U, 0U, 2, 1, 91),
                  false);
    c2_e_y = NULL;
    sf_mex_assign(&c2_e_y, sf_mex_create("y", c2_d_varargin_1, 10, 0U, 1U, 0U, 2,
      1, 11), false);
    c2_f_y = NULL;
    sf_mex_assign(&c2_f_y, sf_mex_create("y", c2_c_varargin_1, 10, 0U, 1U, 0U, 2,
      1, 3), false);
    c2_c_st.site = &c2_yc_emlrtRSI;
    c2_emlrt_marshallIn(chartInstance, c2_c_feval(chartInstance, &c2_c_st,
      c2_b_y, c2_c_y, c2_d_y, c2_e_y, c2_f_y), "<output of feval>");
    c2_st.site = &c2_td_emlrtRSI;
    exit(0);
  }
}

static void c2_applyMamdaniAggregationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_consequentOutputs_data[], int32_T
   c2_consequentOutputs_size[2], c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T
   c2_aggregatedOutputs_data[], int32_T c2_aggregatedOutputs_size[2])
{
  static char_T c2_c_varargin_1[11] = { 'a', 'g', 'g', 'r', 'e', 'g', 'a', 't',
    'i', 'o', 'n' };

  static char_T c2_b_cv[7] = { 'f', 'p', 'r', 'i', 'n', 't', 'f' };

  static uint8_T c2_uv[3] = { 109U, 97U, 120U };

  static uint8_T c2_uv1[3] = { 115U, 117U, 109U };

  emlrtStack c2_b_st;
  emlrtStack c2_c_st;
  emlrtStack c2_st;
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_e_y = NULL;
  const mxArray *c2_y = NULL;
  real_T c2_x[2];
  real_T c2_x_data[2];
  real_T c2_aggVal;
  real_T c2_b_aggVal;
  real_T c2_b_k;
  real_T c2_b_x;
  real_T c2_c_x;
  real_T c2_d_k;
  real_T c2_u;
  int32_T c2_iv[2];
  int32_T c2_b_id;
  int32_T c2_b_sampleID;
  int32_T c2_c_k;
  int32_T c2_c_sampleID;
  int32_T c2_d_sampleID;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_id;
  int32_T c2_k;
  int32_T c2_loop_ub;
  int32_T c2_sampleID;
  char_T c2_b_varargin_1[3];
  uint8_T c2_varargin_1[3];
  uint8_T c2_b_x1;
  uint8_T c2_b_x2;
  uint8_T c2_x1;
  uint8_T c2_x2;
  boolean_T c2_b;
  boolean_T c2_b_b;
  boolean_T c2_b_p;
  boolean_T c2_c_p;
  boolean_T c2_d_p;
  boolean_T c2_e_p;
  boolean_T c2_exitg1;
  boolean_T c2_f_p;
  boolean_T c2_p;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_c_st.prev = &c2_b_st;
  c2_c_st.tls = c2_b_st.tls;
  for (c2_i = 0; c2_i < 3; c2_i++) {
    c2_varargin_1[c2_i] = c2_fis->aggMethod[c2_i];
  }

  c2_p = false;
  c2_b_p = true;
  c2_k = 0;
  c2_exitg1 = false;
  while ((!c2_exitg1) && (c2_k < 3)) {
    c2_b_k = (real_T)c2_k + 1.0;
    c2_x1 = c2_varargin_1[(int32_T)c2_b_k - 1];
    c2_x2 = c2_uv[(int32_T)c2_b_k - 1];
    c2_c_p = (c2_x1 == c2_x2);
    if (!c2_c_p) {
      c2_b_p = false;
      c2_exitg1 = true;
    } else {
      c2_k++;
    }
  }

  if (c2_b_p) {
    c2_p = true;
  }

  if (c2_p) {
    c2_st.site = &c2_xd_emlrtRSI;
    for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
      c2_iv[c2_i2] = c2_fis->aggSize[c2_i2];
    }

    c2_aggregatedOutputs_size[0] = c2_iv[0];
    c2_aggregatedOutputs_size[1] = 1;
    for (c2_sampleID = 0; c2_sampleID < 101; c2_sampleID++) {
      c2_b_sampleID = c2_sampleID + 1;
      if ((c2_b_sampleID < 1) || (c2_b_sampleID > c2_consequentOutputs_size[0]))
      {
        emlrtDynamicBoundsCheckR2012b(c2_b_sampleID, 1,
          c2_consequentOutputs_size[0], &c2_jd_emlrtBCI, &c2_st);
      }

      c2_aggVal = c2_consequentOutputs_data[c2_b_sampleID - 1];
      for (c2_id = 0; c2_id < 23; c2_id++) {
        c2_x[0] = c2_aggVal;
        if ((c2_b_sampleID < 1) || (c2_b_sampleID > c2_consequentOutputs_size[0]))
        {
          emlrtDynamicBoundsCheckR2012b(c2_b_sampleID, 1,
            c2_consequentOutputs_size[0], &c2_ld_emlrtBCI, &c2_st);
        }

        c2_i6 = c2_id + 2;
        if ((c2_i6 < 1) || (c2_i6 > c2_consequentOutputs_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i6, 1, c2_consequentOutputs_size[1],
            &c2_ld_emlrtBCI, &c2_st);
        }

        c2_x[1] = c2_consequentOutputs_data[(c2_b_sampleID +
          c2_consequentOutputs_size[0] * (c2_i6 - 1)) - 1];
        for (c2_i8 = 0; c2_i8 < 2; c2_i8++) {
          c2_x_data[c2_i8] = c2_x[c2_i8];
        }

        if (c2_x_data[0] < c2_x_data[1]) {
          c2_aggVal = c2_x_data[1];
        } else {
          c2_b_x = c2_x_data[0];
          c2_b = muDoubleScalarIsNaN(c2_b_x);
          if (c2_b) {
            c2_c_x = c2_x_data[1];
            c2_b_b = muDoubleScalarIsNaN(c2_c_x);
            if (!c2_b_b) {
              c2_aggVal = c2_x_data[1];
            } else {
              c2_aggVal = c2_x_data[0];
            }
          } else {
            c2_aggVal = c2_x_data[0];
          }
        }
      }

      if ((c2_b_sampleID < 1) || (c2_b_sampleID > c2_aggregatedOutputs_size[0]))
      {
        emlrtDynamicBoundsCheckR2012b(c2_b_sampleID, 1,
          c2_aggregatedOutputs_size[0], &c2_kd_emlrtBCI, &c2_st);
      }

      c2_aggregatedOutputs_data[c2_b_sampleID - 1] = c2_aggVal;
    }
  } else {
    for (c2_i1 = 0; c2_i1 < 3; c2_i1++) {
      c2_varargin_1[c2_i1] = c2_fis->aggMethod[c2_i1];
    }

    c2_d_p = false;
    c2_e_p = true;
    c2_c_k = 0;
    c2_exitg1 = false;
    while ((!c2_exitg1) && (c2_c_k < 3)) {
      c2_d_k = (real_T)c2_c_k + 1.0;
      c2_b_x1 = c2_varargin_1[(int32_T)c2_d_k - 1];
      c2_b_x2 = c2_uv1[(int32_T)c2_d_k - 1];
      c2_f_p = (c2_b_x1 == c2_b_x2);
      if (!c2_f_p) {
        c2_e_p = false;
        c2_exitg1 = true;
      } else {
        c2_c_k++;
      }
    }

    if (c2_e_p) {
      c2_d_p = true;
    }

    if (c2_d_p) {
      c2_st.site = &c2_yd_emlrtRSI;
      for (c2_i4 = 0; c2_i4 < 2; c2_i4++) {
        c2_iv[c2_i4] = c2_fis->aggSize[c2_i4];
      }

      c2_aggregatedOutputs_size[0] = c2_iv[0];
      c2_aggregatedOutputs_size[1] = 1;
      for (c2_c_sampleID = 0; c2_c_sampleID < 101; c2_c_sampleID++) {
        c2_d_sampleID = c2_c_sampleID + 1;
        if ((c2_d_sampleID < 1) || (c2_d_sampleID > c2_consequentOutputs_size[0]))
        {
          emlrtDynamicBoundsCheckR2012b(c2_d_sampleID, 1,
            c2_consequentOutputs_size[0], &c2_jd_emlrtBCI, &c2_st);
        }

        c2_b_aggVal = c2_consequentOutputs_data[c2_d_sampleID - 1];
        for (c2_b_id = 0; c2_b_id < 23; c2_b_id++) {
          c2_x[0] = c2_b_aggVal;
          if ((c2_d_sampleID < 1) || (c2_d_sampleID > c2_consequentOutputs_size
               [0])) {
            emlrtDynamicBoundsCheckR2012b(c2_d_sampleID, 1,
              c2_consequentOutputs_size[0], &c2_ld_emlrtBCI, &c2_st);
          }

          c2_i10 = c2_b_id + 2;
          if ((c2_i10 < 1) || (c2_i10 > c2_consequentOutputs_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i10, 1, c2_consequentOutputs_size[1],
              &c2_ld_emlrtBCI, &c2_st);
          }

          c2_x[1] = c2_consequentOutputs_data[(c2_d_sampleID +
            c2_consequentOutputs_size[0] * (c2_i10 - 1)) - 1];
          c2_b_aggVal = c2_d_sumColumnB(chartInstance, c2_x);
        }

        if ((c2_d_sampleID < 1) || (c2_d_sampleID > c2_aggregatedOutputs_size[0]))
        {
          emlrtDynamicBoundsCheckR2012b(c2_d_sampleID, 1,
            c2_aggregatedOutputs_size[0], &c2_kd_emlrtBCI, &c2_st);
        }

        c2_aggregatedOutputs_data[c2_d_sampleID - 1] = c2_b_aggVal;
      }
    } else {
      for (c2_i3 = 0; c2_i3 < 2; c2_i3++) {
        c2_iv[c2_i3] = c2_fis->aggSize[c2_i3];
      }

      c2_aggregatedOutputs_size[0] = c2_iv[0];
      c2_aggregatedOutputs_size[1] = 1;
      c2_loop_ub = c2_iv[0] - 1;
      for (c2_i5 = 0; c2_i5 <= c2_loop_ub; c2_i5++) {
        c2_aggregatedOutputs_data[c2_i5] = 0.0;
      }

      c2_st.site = &c2_ae_emlrtRSI;
      for (c2_i7 = 0; c2_i7 < 3; c2_i7++) {
        c2_varargin_1[c2_i7] = c2_fis->aggMethod[c2_i7];
      }

      for (c2_i9 = 0; c2_i9 < 3; c2_i9++) {
        c2_b_varargin_1[c2_i9] = (char_T)(int8_T)c2_varargin_1[c2_i9];
      }

      c2_b_st.site = &c2_xc_emlrtRSI;
      c2_y = NULL;
      sf_mex_assign(&c2_y, sf_mex_create("y", c2_b_cv, 10, 0U, 1U, 0U, 2, 1, 7),
                    false);
      c2_u = 1.0;
      c2_b_y = NULL;
      sf_mex_assign(&c2_b_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0), false);
      c2_c_y = NULL;
      sf_mex_assign(&c2_c_y, sf_mex_create("y", c2_cv2, 10, 0U, 1U, 0U, 2, 1, 91),
                    false);
      c2_d_y = NULL;
      sf_mex_assign(&c2_d_y, sf_mex_create("y", c2_c_varargin_1, 10, 0U, 1U, 0U,
        2, 1, 11), false);
      c2_e_y = NULL;
      sf_mex_assign(&c2_e_y, sf_mex_create("y", c2_b_varargin_1, 10, 0U, 1U, 0U,
        2, 1, 3), false);
      c2_c_st.site = &c2_yc_emlrtRSI;
      c2_emlrt_marshallIn(chartInstance, c2_d_feval(chartInstance, &c2_c_st,
        c2_y, c2_b_y, c2_c_y, c2_d_y, c2_e_y), "<output of feval>");
      c2_st.site = &c2_wd_emlrtRSI;
      exit(0);
    }
  }
}

static real_T c2_d_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, real_T c2_x[2])
{
  real_T c2_y;
  (void)chartInstance;
  c2_y = c2_x[0];
  c2_y += c2_x[1];
  return c2_y;
}

static void c2_applyMamdaniDefuzzificationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_outputSamplePoints_data[], int32_T
   c2_outputSamplePoints_size[2], real_T c2_sumAntecedentOutputs, real_T
   c2_aggregatedOutputs_data[], int32_T c2_aggregatedOutputs_size[2],
   c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_defuzzifiedOutputs_data[],
   int32_T c2_defuzzifiedOutputs_size[1])
{
  emlrtStack c2_b_st;
  emlrtStack c2_st;
  real_T c2_membershipValueOfX_data[101];
  real_T c2_x_data[101];
  real_T c2_x[2];
  real_T c2_area;
  real_T c2_b_sumAntecedentOutputs;
  real_T c2_b_y;
  real_T c2_c_y;
  real_T c2_d_y;
  real_T c2_y;
  int32_T c2_x_size[2];
  int32_T c2_membershipValueOfX_size[1];
  int32_T c2_b_i;
  int32_T c2_b_loop_ub;
  int32_T c2_c_i;
  int32_T c2_d_i;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_loop_ub;
  int32_T c2_n;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_st.site = &c2_be_emlrtRSI;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_b_sumAntecedentOutputs = c2_sumAntecedentOutputs;
  c2_defuzzifiedOutputs_size[0] = 1;
  if (c2_b_sumAntecedentOutputs == 0.0) {
    for (c2_i = 0; c2_i < 2; c2_i++) {
      c2_x[c2_i] = c2_fis->outputRange[c2_i];
    }

    c2_y = c2_d_sumColumnB(chartInstance, c2_x);
    c2_b_y = c2_y / 2.0;
    c2_defuzzifiedOutputs_data[0] = c2_b_y;
  } else {
    c2_b_st.site = &c2_ce_emlrtRSI;
    c2_i1 = c2_outputSamplePoints_size[1] - 1;
    c2_x_size[1] = c2_i1 + 1;
    c2_loop_ub = c2_i1;
    for (c2_i2 = 0; c2_i2 <= c2_loop_ub; c2_i2++) {
      c2_x_data[c2_i2] = c2_outputSamplePoints_data[c2_i2];
    }

    c2_i3 = c2_aggregatedOutputs_size[0] - 1;
    c2_membershipValueOfX_size[0] = c2_i3 + 1;
    c2_b_loop_ub = c2_i3;
    for (c2_i4 = 0; c2_i4 <= c2_b_loop_ub; c2_i4++) {
      c2_membershipValueOfX_data[c2_i4] = c2_aggregatedOutputs_data[c2_i4];
    }

    c2_c_y = 0.0;
    c2_area = 0.0;
    c2_n = c2_x_size[1] - 1;
    for (c2_b_i = 1; c2_b_i - 1 <= c2_n; c2_b_i++) {
      c2_c_i = c2_b_i;
      if ((c2_c_i < 1) || (c2_c_i > c2_membershipValueOfX_size[0])) {
        emlrtDynamicBoundsCheckR2012b(c2_c_i, 1, c2_membershipValueOfX_size[0],
          &c2_md_emlrtBCI, &c2_b_st);
      }

      c2_area += c2_membershipValueOfX_data[c2_c_i - 1];
    }

    if (c2_area == 0.0) {
      c2_x[0] = c2_x_data[0];
      c2_i5 = c2_n + 1;
      if ((c2_i5 < 1) || (c2_i5 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i5, 1, c2_x_size[1], &c2_nd_emlrtBCI,
          &c2_b_st);
      }

      c2_x[1] = c2_x_data[c2_i5 - 1];
      c2_d_y = c2_d_sumColumnB(chartInstance, c2_x);
      c2_c_y = c2_d_y / 2.0;
    } else {
      for (c2_d_i = 1; c2_d_i - 1 <= c2_n; c2_d_i++) {
        c2_c_i = c2_d_i;
        if ((c2_c_i < 1) || (c2_c_i > c2_x_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_c_i, 1, c2_x_size[1], &c2_od_emlrtBCI,
            &c2_b_st);
        }

        if ((c2_c_i < 1) || (c2_c_i > c2_membershipValueOfX_size[0])) {
          emlrtDynamicBoundsCheckR2012b(c2_c_i, 1, c2_membershipValueOfX_size[0],
            &c2_pd_emlrtBCI, &c2_b_st);
        }

        c2_c_y += c2_x_data[c2_c_i - 1] * c2_membershipValueOfX_data[c2_c_i - 1];
      }

      c2_c_y *= 1.0 / c2_area;
    }

    c2_defuzzifiedOutputs_data[0] = c2_c_y;
  }
}

static void c2_applySugenoAggregationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, real_T
   c2_consequentOutputs_data[], int32_T c2_consequentOutputs_size[2], real_T
   c2_aggregatedOutputs_data[], int32_T c2_aggregatedOutputs_size[2])
{
  real_T c2_b_consequentOutputs_data[2424];
  real_T c2_sz[2];
  int32_T c2_b_consequentOutputs_size[2];
  int32_T c2_c_consequentOutputs_size[2];
  int32_T c2_b_col;
  int32_T c2_b_vlen;
  int32_T c2_c_vlen;
  int32_T c2_col;
  int32_T c2_d_vlen;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_loop_ub;
  int32_T c2_ncols;
  int32_T c2_vlen;
  c2_vlen = c2_consequentOutputs_size[0];
  c2_b_vlen = c2_vlen;
  c2_c_vlen = c2_b_vlen;
  c2_d_vlen = c2_c_vlen;
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_sz[c2_i] = (real_T)c2_consequentOutputs_size[c2_i];
  }

  c2_aggregatedOutputs_size[0] = 1;
  c2_aggregatedOutputs_size[1] = (int32_T)c2_sz[1];
  c2_ncols = c2_consequentOutputs_size[1] - 1;
  for (c2_col = 1; c2_col - 1 <= c2_ncols; c2_col++) {
    c2_b_col = c2_col;
    c2_b_consequentOutputs_size[0] = c2_consequentOutputs_size[0];
    c2_b_consequentOutputs_size[1] = c2_consequentOutputs_size[1];
    c2_loop_ub = c2_consequentOutputs_size[0] * c2_consequentOutputs_size[1] - 1;
    for (c2_i1 = 0; c2_i1 <= c2_loop_ub; c2_i1++) {
      c2_b_consequentOutputs_data[c2_i1] = c2_consequentOutputs_data[c2_i1];
    }

    for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
      c2_c_consequentOutputs_size[c2_i2] = c2_b_consequentOutputs_size[c2_i2];
    }

    c2_aggregatedOutputs_data[c2_b_col - 1] = c2_e_sumColumnB(chartInstance,
      c2_b_consequentOutputs_data, c2_c_consequentOutputs_size, c2_b_col,
      c2_d_vlen);
  }
}

static real_T c2_e_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, real_T c2_x_data[], int32_T c2_x_size[2], int32_T c2_col,
  int32_T c2_vlen)
{
  real_T c2_y;
  int32_T c2_b_col;
  int32_T c2_b_k;
  int32_T c2_b_vlen;
  int32_T c2_i;
  int32_T c2_i0;
  int32_T c2_k;
  (void)chartInstance;
  c2_b_col = c2_col - 1;
  c2_b_vlen = c2_vlen - 1;
  c2_i0 = c2_b_col * c2_x_size[0];
  c2_y = c2_x_data[c2_i0];
  c2_i = c2_b_vlen - 1;
  for (c2_k = 1; c2_k - 1 <= c2_i; c2_k++) {
    c2_b_k = c2_k;
    c2_y += c2_x_data[c2_i0 + c2_b_k];
  }

  return c2_y;
}

static void c2_applySugenoDefuzzificationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, real_T
   c2_sumAntecedentOutputs, real_T c2_aggregatedOutputs_data[],
   c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_defuzzifiedOutputs_data[],
   int32_T c2_defuzzifiedOutputs_size[1])
{
  real_T c2_b_x[2];
  real_T c2_b_sumAntecedentOutputs;
  real_T c2_b_y;
  real_T c2_c_y;
  real_T c2_d_y;
  real_T c2_membershipValueOfX;
  real_T c2_x;
  real_T c2_y;
  int32_T c2_i;
  c2_b_sumAntecedentOutputs = c2_sumAntecedentOutputs;
  c2_defuzzifiedOutputs_size[0] = 1;
  if (c2_b_sumAntecedentOutputs == 0.0) {
    for (c2_i = 0; c2_i < 2; c2_i++) {
      c2_b_x[c2_i] = c2_fis->outputRange[c2_i];
    }

    c2_y = c2_d_sumColumnB(chartInstance, c2_b_x);
    c2_c_y = c2_y / 2.0;
    c2_defuzzifiedOutputs_data[0] = c2_c_y;
  } else {
    c2_x = c2_aggregatedOutputs_data[0];
    c2_membershipValueOfX = c2_b_sumAntecedentOutputs;
    if (c2_membershipValueOfX == 0.0) {
      c2_b_x[0] = c2_x;
      c2_b_x[1] = c2_x;
      c2_d_y = c2_d_sumColumnB(chartInstance, c2_b_x);
      c2_b_y = c2_d_y / 2.0;
    } else {
      c2_b_y = c2_x * c2_membershipValueOfX;
      c2_b_y *= 1.0 / c2_membershipValueOfX;
    }

    c2_defuzzifiedOutputs_data[0] = c2_b_y;
  }
}

static void c2_b_applyMamdaniDefuzzificationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_outputSamplePoints_data[], int32_T
   c2_outputSamplePoints_size[2], real_T c2_sumAntecedentOutputs, real_T
   c2_aggregatedOutputs_data[], int32_T c2_aggregatedOutputs_size[2],
   c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_defuzzifiedOutputs_data[],
   int32_T c2_defuzzifiedOutputs_size[1])
{
  emlrtStack c2_b_st;
  emlrtStack c2_st;
  real_T c2_b_membershipValueOfX_data[101];
  real_T c2_membershipValueOfX_data[101];
  real_T c2_x_data[101];
  real_T c2_x[2];
  real_T c2_area;
  real_T c2_b_sumAntecedentOutputs;
  real_T c2_b_y;
  real_T c2_c_i;
  real_T c2_c_y;
  real_T c2_d;
  real_T c2_d_y;
  real_T c2_halfArea;
  real_T c2_halfAreaID;
  real_T c2_y;
  int32_T c2_x_size[2];
  int32_T c2_membershipValueOfX_size[1];
  int32_T c2_b_i;
  int32_T c2_b_loop_ub;
  int32_T c2_b_vlen;
  int32_T c2_c_loop_ub;
  int32_T c2_c_vlen;
  int32_T c2_d_vlen;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_loop_ub;
  int32_T c2_vlen;
  boolean_T c2_exitg1;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_st.site = &c2_be_emlrtRSI;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_b_sumAntecedentOutputs = c2_sumAntecedentOutputs;
  c2_defuzzifiedOutputs_size[0] = 1;
  if (c2_b_sumAntecedentOutputs == 0.0) {
    for (c2_i = 0; c2_i < 2; c2_i++) {
      c2_x[c2_i] = c2_fis->outputRange[c2_i];
    }

    c2_y = c2_d_sumColumnB(chartInstance, c2_x);
    c2_b_y = c2_y / 2.0;
    c2_defuzzifiedOutputs_data[0] = c2_b_y;
  } else {
    c2_b_st.site = &c2_ce_emlrtRSI;
    c2_i1 = c2_outputSamplePoints_size[1] - 1;
    c2_x_size[1] = c2_i1 + 1;
    c2_loop_ub = c2_i1;
    for (c2_i2 = 0; c2_i2 <= c2_loop_ub; c2_i2++) {
      c2_x_data[c2_i2] = c2_outputSamplePoints_data[c2_i2];
    }

    c2_i3 = c2_aggregatedOutputs_size[0] - 1;
    c2_membershipValueOfX_size[0] = c2_i3 + 1;
    c2_b_loop_ub = c2_i3;
    for (c2_i4 = 0; c2_i4 <= c2_b_loop_ub; c2_i4++) {
      c2_membershipValueOfX_data[c2_i4] = c2_aggregatedOutputs_data[c2_i4];
    }

    c2_vlen = c2_membershipValueOfX_size[0];
    c2_b_vlen = c2_vlen;
    c2_c_vlen = c2_b_vlen;
    c2_d_vlen = c2_c_vlen;
    c2_c_loop_ub = c2_membershipValueOfX_size[0] - 1;
    for (c2_i5 = 0; c2_i5 <= c2_c_loop_ub; c2_i5++) {
      c2_b_membershipValueOfX_data[c2_i5] = c2_membershipValueOfX_data[c2_i5];
    }

    c2_area = c2_c_sumColumnB(chartInstance, c2_b_membershipValueOfX_data,
      c2_d_vlen);
    if (c2_area == 0.0) {
      c2_x[0] = c2_x_data[0];
      c2_i6 = c2_x_size[1];
      if ((c2_i6 < 1) || (c2_i6 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i6, 1, c2_x_size[1], &c2_qd_emlrtBCI,
          &c2_b_st);
      }

      c2_x[1] = c2_x_data[c2_i6 - 1];
      c2_c_y = c2_d_sumColumnB(chartInstance, c2_x);
      c2_d_y = c2_c_y / 2.0;
    } else {
      c2_halfArea = c2_area / 2.0;
      c2_halfAreaID = 1.0;
      c2_area = 0.0;
      c2_d = (real_T)c2_x_size[1];
      c2_i7 = (int32_T)c2_d - 1;
      c2_b_i = 0;
      c2_exitg1 = false;
      while ((!c2_exitg1) && (c2_b_i <= c2_i7)) {
        c2_c_i = (real_T)c2_b_i + 1.0;
        c2_i9 = (int32_T)c2_c_i;
        if ((c2_i9 < 1) || (c2_i9 > c2_membershipValueOfX_size[0])) {
          emlrtDynamicBoundsCheckR2012b(c2_i9, 1, c2_membershipValueOfX_size[0],
            &c2_sd_emlrtBCI, &c2_b_st);
        }

        c2_area += c2_membershipValueOfX_data[c2_i9 - 1];
        if (c2_area >= c2_halfArea) {
          c2_halfAreaID = c2_c_i;
          c2_exitg1 = true;
        } else {
          c2_b_i++;
        }
      }

      c2_i8 = (int32_T)c2_halfAreaID;
      if ((c2_i8 < 1) || (c2_i8 > c2_x_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i8, 1, c2_x_size[1], &c2_rd_emlrtBCI,
          &c2_b_st);
      }

      c2_d_y = c2_x_data[c2_i8 - 1];
    }

    c2_defuzzifiedOutputs_data[0] = c2_d_y;
  }
}

static void c2_b_applySugenoDefuzzificationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, real_T
   c2_sumAntecedentOutputs, real_T c2_aggregatedOutputs_data[],
   c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_defuzzifiedOutputs_data[],
   int32_T c2_defuzzifiedOutputs_size[1])
{
  real_T c2_c_x[2];
  real_T c2_area;
  real_T c2_b_sumAntecedentOutputs;
  real_T c2_b_x;
  real_T c2_b_y;
  real_T c2_c_y;
  real_T c2_d_x;
  real_T c2_d_y;
  real_T c2_e_x;
  real_T c2_f_x;
  real_T c2_g_x;
  real_T c2_h_x;
  real_T c2_membershipValueOfX;
  real_T c2_x;
  real_T c2_y;
  int32_T c2_i;
  c2_b_sumAntecedentOutputs = c2_sumAntecedentOutputs;
  c2_defuzzifiedOutputs_size[0] = 1;
  if (c2_b_sumAntecedentOutputs == 0.0) {
    for (c2_i = 0; c2_i < 2; c2_i++) {
      c2_c_x[c2_i] = c2_fis->outputRange[c2_i];
    }

    c2_y = c2_d_sumColumnB(chartInstance, c2_c_x);
    c2_b_y = c2_y / 2.0;
    c2_defuzzifiedOutputs_data[0] = c2_b_y;
  } else {
    c2_x = c2_aggregatedOutputs_data[0];
    c2_membershipValueOfX = c2_b_sumAntecedentOutputs;
    c2_b_x = c2_membershipValueOfX;
    c2_d_x = c2_b_x;
    c2_e_x = c2_d_x;
    c2_f_x = c2_e_x;
    c2_g_x = c2_f_x;
    c2_h_x = c2_g_x;
    c2_area = c2_f_sumColumnB(chartInstance, c2_h_x);
    if (c2_area == 0.0) {
      c2_c_x[0] = c2_x;
      c2_c_x[1] = c2_x;
      c2_d_y = c2_d_sumColumnB(chartInstance, c2_c_x);
      c2_c_y = c2_d_y / 2.0;
    } else {
      c2_c_y = c2_x;
    }

    c2_defuzzifiedOutputs_data[0] = c2_c_y;
  }
}

static real_T c2_f_sumColumnB(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, real_T c2_x)
{
  real_T c2_b_x;
  (void)chartInstance;
  c2_b_x = c2_x;
  return c2_b_x;
}

static void c2_evaluateFIS(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_inputs[2],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_y_data[], int32_T c2_y_size[2])
{
  static char_T c2_c_varargin_1[15] = { 'd', 'e', 'f', 'u', 'z', 'z', 'i', 'f',
    'i', 'c', 'a', 't', 'i', 'o', 'n' };

  static char_T c2_b_cv[7] = { 'f', 'p', 'r', 'i', 'n', 't', 'f' };

  static uint8_T c2_uv[8] = { 99U, 101U, 110U, 116U, 114U, 111U, 105U, 100U };

  static uint8_T c2_uv1[8] = { 98U, 105U, 115U, 101U, 99U, 116U, 111U, 114U };

  c2_s_9DL33rUTgryGqqXf4f6A1E c2_b_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_c_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_d_fis;
  emlrtStack c2_b_st;
  emlrtStack c2_c_st;
  emlrtStack c2_st;
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_e_y = NULL;
  const mxArray *c2_y = NULL;
  real_T c2_orr_data[2424];
  real_T c2_unImpSugRuleOut_data[2424];
  real_T c2_arr_data[101];
  real_T c2_irr_data[48];
  real_T c2_rfs_data[24];
  real_T c2_b_inputs[2];
  real_T c2_c_inputs[2];
  real_T c2_b_k;
  real_T c2_d_k;
  real_T c2_u;
  int32_T c2_arr_size[2];
  int32_T c2_irr_size[2];
  int32_T c2_orr_size[2];
  int32_T c2_unImpSugRuleOut_size[2];
  int32_T c2_rfs_size[1];
  int32_T c2_c_k;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_k;
  char_T c2_b_varargin_1[8];
  uint8_T c2_varargin_1[8];
  uint8_T c2_b_x1;
  uint8_T c2_b_x2;
  uint8_T c2_x1;
  uint8_T c2_x2;
  boolean_T c2_b_p;
  boolean_T c2_c_p;
  boolean_T c2_d_p;
  boolean_T c2_e_p;
  boolean_T c2_exitg1;
  boolean_T c2_f_p;
  boolean_T c2_p;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_c_st.prev = &c2_b_st;
  c2_c_st.tls = c2_b_st.tls;
  for (c2_i = 0; c2_i < 8; c2_i++) {
    c2_varargin_1[c2_i] = c2_fis->defuzzMethod[c2_i];
  }

  c2_p = false;
  c2_b_p = true;
  c2_k = 0;
  c2_exitg1 = false;
  while ((!c2_exitg1) && (c2_k < 8)) {
    c2_b_k = (real_T)c2_k + 1.0;
    c2_x1 = c2_varargin_1[(int32_T)c2_b_k - 1];
    c2_x2 = c2_uv[(int32_T)c2_b_k - 1];
    c2_c_p = (c2_x1 == c2_x2);
    if (!c2_c_p) {
      c2_b_p = false;
      c2_exitg1 = true;
    } else {
      c2_k++;
    }
  }

  if (c2_b_p) {
    c2_p = true;
  }

  if (c2_p) {
    c2_b_fis = *c2_fis;
    c2_st.site = &c2_p_emlrtRSI;
    for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
      c2_b_inputs[c2_i2] = c2_inputs[c2_i2];
    }

    c2_runFIS(chartInstance, &c2_st, c2_b_inputs, &c2_b_fis, c2_y_data,
              c2_y_size, c2_irr_data, c2_irr_size, c2_orr_data, c2_orr_size,
              c2_arr_data, c2_arr_size, c2_rfs_data, c2_rfs_size,
              c2_unImpSugRuleOut_data, c2_unImpSugRuleOut_size);
  } else {
    for (c2_i1 = 0; c2_i1 < 8; c2_i1++) {
      c2_varargin_1[c2_i1] = c2_fis->defuzzMethod[c2_i1];
    }

    c2_d_p = false;
    c2_e_p = true;
    c2_c_k = 0;
    c2_exitg1 = false;
    while ((!c2_exitg1) && (c2_c_k < 8)) {
      c2_d_k = (real_T)c2_c_k + 1.0;
      c2_b_x1 = c2_varargin_1[(int32_T)c2_d_k - 1];
      c2_b_x2 = c2_uv1[(int32_T)c2_d_k - 1];
      c2_f_p = (c2_b_x1 == c2_b_x2);
      if (!c2_f_p) {
        c2_e_p = false;
        c2_exitg1 = true;
      } else {
        c2_c_k++;
      }
    }

    if (c2_e_p) {
      c2_d_p = true;
    }

    if (c2_d_p) {
      c2_d_fis = *c2_fis;
      c2_st.site = &c2_q_emlrtRSI;
      for (c2_i3 = 0; c2_i3 < 2; c2_i3++) {
        c2_c_inputs[c2_i3] = c2_inputs[c2_i3];
      }

      c2_b_runFIS(chartInstance, &c2_st, c2_c_inputs, &c2_d_fis, c2_y_data,
                  c2_y_size, c2_irr_data, c2_irr_size, c2_orr_data, c2_orr_size,
                  c2_arr_data, c2_arr_size, c2_rfs_data, c2_rfs_size,
                  c2_unImpSugRuleOut_data, c2_unImpSugRuleOut_size);
    } else {
      c2_c_fis = *c2_fis;
      c2_st.site = &c2_r_emlrtRSI;
      c2_b_initVariables(chartInstance, &c2_st, &c2_c_fis, c2_y_size,
                         c2_irr_size, c2_orr_size, c2_arr_size, c2_rfs_size,
                         c2_unImpSugRuleOut_data, c2_unImpSugRuleOut_size);
      c2_st.site = &c2_s_emlrtRSI;
      for (c2_i4 = 0; c2_i4 < 8; c2_i4++) {
        c2_varargin_1[c2_i4] = c2_fis->defuzzMethod[c2_i4];
      }

      for (c2_i5 = 0; c2_i5 < 8; c2_i5++) {
        c2_b_varargin_1[c2_i5] = (char_T)(int8_T)c2_varargin_1[c2_i5];
      }

      c2_b_st.site = &c2_xc_emlrtRSI;
      c2_y = NULL;
      sf_mex_assign(&c2_y, sf_mex_create("y", c2_b_cv, 10, 0U, 1U, 0U, 2, 1, 7),
                    false);
      c2_u = 1.0;
      c2_b_y = NULL;
      sf_mex_assign(&c2_b_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0), false);
      c2_c_y = NULL;
      sf_mex_assign(&c2_c_y, sf_mex_create("y", c2_cv2, 10, 0U, 1U, 0U, 2, 1, 91),
                    false);
      c2_d_y = NULL;
      sf_mex_assign(&c2_d_y, sf_mex_create("y", c2_c_varargin_1, 10, 0U, 1U, 0U,
        2, 1, 15), false);
      c2_e_y = NULL;
      sf_mex_assign(&c2_e_y, sf_mex_create("y", c2_b_varargin_1, 10, 0U, 1U, 0U,
        2, 1, 8), false);
      c2_c_st.site = &c2_yc_emlrtRSI;
      c2_emlrt_marshallIn(chartInstance, c2_e_feval(chartInstance, &c2_c_st,
        c2_y, c2_b_y, c2_c_y, c2_d_y, c2_e_y), "<output of feval>");
      c2_st.site = &c2_o_emlrtRSI;
      exit(0);
    }
  }
}

static void c2_runFIS(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
                      const emlrtStack *c2_sp, real_T c2_inputs[2],
                      c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_y_data[],
                      int32_T c2_y_size[2], real_T c2_irr_data[], int32_T
                      c2_irr_size[2], real_T c2_orr_data[], int32_T c2_orr_size
                      [2], real_T c2_arr_data[], int32_T c2_arr_size[2], real_T
                      c2_w_data[], int32_T c2_w_size[1], real_T
                      c2_unImpSugRuleOut_data[], int32_T
                      c2_unImpSugRuleOut_size[2])
{
  c2_cell_wrap_0 c2_inVarMF[2];
  c2_emxArray_real_T *c2_b_inputMFCache;
  c2_emxArray_real_T *c2_inputMFCache;
  c2_emxArray_real_T *c2_outputMFCache;
  c2_emxArray_real_T *c2_r;
  c2_s_64TxJFgCtXBlX73DcwNLAB c2_c_fis[2];
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_b_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_d_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_e_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_f_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_g_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_h_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_i_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_j_fis;
  emlrtStack c2_st;
  real_T c2_b_orr_data[2424];
  real_T c2_c_orr_data[2424];
  real_T c2_tmp_data[2424];
  real_T c2_c_arr_data[101];
  real_T c2_d_arr_data[101];
  real_T c2_fis_data[101];
  real_T c2_b_irr_data[48];
  real_T c2_b_arr_data[24];
  real_T c2_b_w_data[24];
  real_T c2_c_w_data[24];
  real_T c2_b_inputs[2];
  real_T c2_c_inputs[2];
  real_T c2_irrOfOneRule_data[2];
  real_T c2_c_tmp_data[1];
  real_T c2_d_tmp_data[1];
  real_T c2_sw;
  real_T c2_y;
  int32_T c2_b_arr_size[2];
  int32_T c2_b_orr_size[2];
  int32_T c2_c_arr_size[2];
  int32_T c2_c_orr_size[2];
  int32_T c2_c_tmp_size[2];
  int32_T c2_d_arr_size[2];
  int32_T c2_d_orr_size[2];
  int32_T c2_fis_size[2];
  int32_T c2_iv[2];
  int32_T c2_iv1[2];
  int32_T c2_tmp_size[2];
  int32_T c2_x[2];
  int32_T c2_b_tmp_data[1];
  int32_T c2_b_tmp_size[1];
  int32_T c2_b_loop_ub;
  int32_T c2_c_loop_ub;
  int32_T c2_d_loop_ub;
  int32_T c2_e_loop_ub;
  int32_T c2_f_loop_ub;
  int32_T c2_g_loop_ub;
  int32_T c2_h_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i19;
  int32_T c2_i2;
  int32_T c2_i20;
  int32_T c2_i21;
  int32_T c2_i22;
  int32_T c2_i23;
  int32_T c2_i24;
  int32_T c2_i25;
  int32_T c2_i26;
  int32_T c2_i27;
  int32_T c2_i28;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_loop_ub;
  char_T c2_b_y[7];
  uint8_T c2_varargin_1[7];
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_emxInit_real_T(chartInstance, c2_sp, &c2_outputMFCache, 2, &c2_se_emlrtRTEI);
  c2_b_fis = *c2_fis;
  c2_st.site = &c2_t_emlrtRSI;
  c2_initVariables(chartInstance, &c2_st, &c2_b_fis, c2_y_size, c2_irr_size,
                   c2_b_orr_size, c2_b_arr_size, c2_w_size,
                   c2_unImpSugRuleOut_data, c2_unImpSugRuleOut_size,
                   c2_outputMFCache);
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_c_fis[c2_i] = c2_fis->inputMF[c2_i];
  }

  c2_st.site = &c2_u_emlrtRSI;
  c2_b_extractVarMF(chartInstance, &c2_st, c2_c_fis, c2_inVarMF);
  c2_emxInit_real_T(chartInstance, c2_sp, &c2_inputMFCache, 2, &c2_re_emlrtRTEI);
  c2_y = c2_b_sumColumnB(chartInstance);
  c2_x[0] = 1;
  if (c2_y != (real_T)(int32_T)muDoubleScalarFloor(c2_y)) {
    emlrtIntegerCheckR2012b(c2_y, &c2_b_emlrtDCI, (void *)c2_sp);
  }

  c2_x[1] = (int32_T)c2_y;
  c2_i1 = c2_inputMFCache->size[0] * c2_inputMFCache->size[1];
  c2_inputMFCache->size[0] = c2_x[0];
  c2_inputMFCache->size[1] = c2_x[1];
  c2_st.site = &c2_le_emlrtRSI;
  c2_emxEnsureCapacity_real_T(chartInstance, &c2_st, c2_inputMFCache, c2_i1,
    &c2_td_emlrtRTEI);
  for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
    c2_irrOfOneRule_data[c2_i2] = 0.0;
  }

  c2_emxInit_real_T(chartInstance, c2_sp, &c2_b_inputMFCache, 2,
                    &c2_wd_emlrtRTEI);
  c2_d_fis = *c2_fis;
  c2_i3 = c2_b_inputMFCache->size[0] * c2_b_inputMFCache->size[1];
  c2_b_inputMFCache->size[0] = 1;
  c2_b_inputMFCache->size[1] = c2_inputMFCache->size[1];
  c2_st.site = &c2_ke_emlrtRSI;
  c2_emxEnsureCapacity_real_T(chartInstance, &c2_st, c2_b_inputMFCache, c2_i3,
    &c2_wd_emlrtRTEI);
  c2_loop_ub = c2_inputMFCache->size[0] * c2_inputMFCache->size[1] - 1;
  for (c2_i4 = 0; c2_i4 <= c2_loop_ub; c2_i4++) {
    c2_b_inputMFCache->data[c2_i4] = c2_inputMFCache->data[c2_i4];
  }

  c2_emxInit_real_T(chartInstance, c2_sp, &c2_r, 2, &c2_se_emlrtRTEI);
  c2_st.site = &c2_v_emlrtRSI;
  for (c2_i5 = 0; c2_i5 < 2; c2_i5++) {
    c2_b_inputs[c2_i5] = c2_inputs[c2_i5];
  }

  c2_b_fuzzifyInputs(chartInstance, &c2_st, c2_b_inputs, &c2_d_fis, c2_inVarMF,
                     c2_b_inputMFCache, c2_irr_data, c2_r);
  c2_i6 = c2_inputMFCache->size[1];
  c2_i7 = c2_r->size[1];
  if (c2_i6 != c2_i7) {
    emlrtSubAssignSizeCheck1dR2017a(c2_i6, c2_i7, &c2_n_emlrtECI, (void *)c2_sp);
  }

  c2_emxFree_real_T(chartInstance, &c2_b_inputMFCache);
  c2_emxFree_real_T(chartInstance, &c2_r);
  c2_emxFree_real_T(chartInstance, &c2_inputMFCache);
  for (c2_i8 = 0; c2_i8 < 48; c2_i8++) {
    c2_b_irr_data[c2_i8] = c2_irr_data[c2_i8];
  }

  c2_e_fis = *c2_fis;
  c2_st.site = &c2_w_emlrtRSI;
  c2_sw = c2_b_applyOperators(chartInstance, &c2_st, c2_b_irr_data, &c2_e_fis,
    c2_w_data, c2_irrOfOneRule_data);
  for (c2_i9 = 0; c2_i9 < 7; c2_i9++) {
    c2_varargin_1[c2_i9] = c2_fis->type[c2_i9];
  }

  for (c2_i10 = 0; c2_i10 < 7; c2_i10++) {
    c2_b_y[c2_i10] = (char_T)(int8_T)c2_varargin_1[c2_i10];
  }

  if (c2_strcmp(chartInstance, c2_b_y)) {
    for (c2_i12 = 0; c2_i12 < 24; c2_i12++) {
      c2_c_w_data[c2_i12] = c2_w_data[c2_i12];
    }

    c2_g_fis = *c2_fis;
    c2_st.site = &c2_x_emlrtRSI;
    c2_applyMamdaniImplicationMethod(chartInstance, &c2_st, c2_c_w_data,
      &c2_g_fis, c2_outputMFCache, c2_orr_data, c2_orr_size);
    c2_i14 = c2_b_orr_size[0] * c2_b_orr_size[1];
    c2_i15 = c2_orr_size[0] * c2_orr_size[1];
    if (c2_i14 != c2_i15) {
      emlrtSubAssignSizeCheck1dR2017a(c2_i14, c2_i15, &c2_o_emlrtECI, (void *)
        c2_sp);
    }

    c2_c_orr_size[0] = c2_orr_size[0];
    c2_c_orr_size[1] = c2_orr_size[1];
    c2_b_loop_ub = c2_orr_size[0] * c2_orr_size[1] - 1;
    for (c2_i20 = 0; c2_i20 <= c2_b_loop_ub; c2_i20++) {
      c2_b_orr_data[c2_i20] = c2_orr_data[c2_i20];
    }

    c2_h_fis = *c2_fis;
    c2_st.site = &c2_y_emlrtRSI;
    c2_applyMamdaniAggregationMethod(chartInstance, &c2_st, c2_b_orr_data,
      c2_c_orr_size, &c2_h_fis, c2_arr_data, c2_arr_size);
    if (c2_b_arr_size[0] != c2_arr_size[0]) {
      emlrtSubAssignSizeCheck1dR2017a(c2_b_arr_size[0], c2_arr_size[0],
        &c2_p_emlrtECI, (void *)c2_sp);
    }

    c2_b_tmp_data[0] = 0;
    c2_fis_size[0] = 1;
    c2_fis_size[1] = c2_fis->outputSamplePoints.size[1];
    c2_e_loop_ub = c2_fis->outputSamplePoints.size[0] *
      c2_fis->outputSamplePoints.size[1] - 1;
    for (c2_i23 = 0; c2_i23 <= c2_e_loop_ub; c2_i23++) {
      c2_fis_data[c2_i23] = c2_fis->outputSamplePoints.data[c2_i23];
    }

    c2_d_arr_size[0] = c2_arr_size[0];
    c2_d_arr_size[1] = 1;
    c2_f_loop_ub = c2_arr_size[0] * c2_arr_size[1] - 1;
    for (c2_i24 = 0; c2_i24 <= c2_f_loop_ub; c2_i24++) {
      c2_c_arr_data[c2_i24] = c2_arr_data[c2_i24];
    }

    c2_i_fis = *c2_fis;
    c2_st.site = &c2_ab_emlrtRSI;
    c2_applyMamdaniDefuzzificationMethod(chartInstance, &c2_st, c2_fis_data,
      c2_fis_size, c2_sw, c2_c_arr_data, c2_d_arr_size, &c2_i_fis, c2_c_tmp_data,
      c2_b_tmp_size);
    c2_c_tmp_size[0] = 1;
    c2_c_tmp_size[1] = 1;
    c2_d_tmp_data[0] = c2_c_tmp_data[0];
    for (c2_i27 = 0; c2_i27 < 2; c2_i27++) {
      c2_iv[c2_i27] = 1;
    }

    emlrtSubAssignSizeCheckR2012b(&c2_iv[0], 2, &c2_c_tmp_size[0], 2,
      &c2_s_emlrtECI, (void *)c2_sp);
    c2_y_data[c2_b_tmp_data[0]] = c2_d_tmp_data[0];
  } else {
    for (c2_i11 = 0; c2_i11 < 24; c2_i11++) {
      c2_b_w_data[c2_i11] = c2_w_data[c2_i11];
    }

    c2_f_fis = *c2_fis;
    c2_st.site = &c2_bb_emlrtRSI;
    for (c2_i13 = 0; c2_i13 < 2; c2_i13++) {
      c2_c_inputs[c2_i13] = c2_inputs[c2_i13];
    }

    c2_applySugenoImplicationMethod(chartInstance, &c2_st, c2_c_inputs,
      c2_b_w_data, &c2_f_fis, c2_orr_data, c2_orr_size, c2_tmp_data, c2_tmp_size);
    c2_i16 = c2_b_orr_size[0] * c2_b_orr_size[1];
    c2_i17 = c2_orr_size[0] * c2_orr_size[1];
    if (c2_i16 != c2_i17) {
      emlrtSubAssignSizeCheck1dR2017a(c2_i16, c2_i17, &c2_q_emlrtECI, (void *)
        c2_sp);
    }

    c2_i18 = c2_unImpSugRuleOut_size[0] * c2_unImpSugRuleOut_size[1];
    c2_i19 = c2_tmp_size[0] * c2_tmp_size[1];
    if (c2_i18 != c2_i19) {
      emlrtSubAssignSizeCheck1dR2017a(c2_i18, c2_i19, &c2_u_emlrtECI, (void *)
        c2_sp);
    }

    c2_unImpSugRuleOut_size[0] = c2_tmp_size[0];
    c2_unImpSugRuleOut_size[1] = c2_tmp_size[1];
    c2_c_loop_ub = c2_tmp_size[0] * c2_tmp_size[1] - 1;
    for (c2_i21 = 0; c2_i21 <= c2_c_loop_ub; c2_i21++) {
      c2_unImpSugRuleOut_data[c2_i21] = c2_tmp_data[c2_i21];
    }

    c2_d_orr_size[0] = c2_orr_size[0];
    c2_d_orr_size[1] = c2_orr_size[1];
    c2_d_loop_ub = c2_orr_size[0] * c2_orr_size[1] - 1;
    for (c2_i22 = 0; c2_i22 <= c2_d_loop_ub; c2_i22++) {
      c2_c_orr_data[c2_i22] = c2_orr_data[c2_i22];
    }

    c2_applySugenoAggregationMethod(chartInstance, c2_c_orr_data, c2_d_orr_size,
      c2_b_arr_data, c2_c_arr_size);
    if (c2_b_arr_size[0] != c2_c_arr_size[1]) {
      emlrtSubAssignSizeCheck1dR2017a(c2_b_arr_size[0], c2_c_arr_size[1],
        &c2_r_emlrtECI, (void *)c2_sp);
    }

    c2_arr_size[0] = c2_b_arr_size[0];
    c2_arr_size[1] = 1;
    c2_g_loop_ub = c2_b_arr_size[0] * c2_b_arr_size[1] - 1;
    for (c2_i25 = 0; c2_i25 <= c2_g_loop_ub; c2_i25++) {
      c2_arr_data[c2_i25] = c2_b_arr_data[c2_i25];
    }

    c2_b_tmp_data[0] = 0;
    c2_h_loop_ub = c2_arr_size[0] * c2_arr_size[1] - 1;
    for (c2_i26 = 0; c2_i26 <= c2_h_loop_ub; c2_i26++) {
      c2_d_arr_data[c2_i26] = c2_arr_data[c2_i26];
    }

    c2_j_fis = *c2_fis;
    c2_applySugenoDefuzzificationMethod(chartInstance, c2_sw, c2_d_arr_data,
      &c2_j_fis, c2_c_tmp_data, c2_b_tmp_size);
    c2_c_tmp_size[0] = 1;
    c2_c_tmp_size[1] = 1;
    c2_d_tmp_data[0] = c2_c_tmp_data[0];
    for (c2_i28 = 0; c2_i28 < 2; c2_i28++) {
      c2_iv1[c2_i28] = 1;
    }

    emlrtSubAssignSizeCheckR2012b(&c2_iv1[0], 2, &c2_c_tmp_size[0], 2,
      &c2_t_emlrtECI, (void *)c2_sp);
    c2_y_data[c2_b_tmp_data[0]] = c2_d_tmp_data[0];
  }

  c2_emxFree_real_T(chartInstance, &c2_outputMFCache);
}

static void c2_initVariables(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis,
  int32_T c2_y_size[2], int32_T c2_irr_size[2], int32_T c2_orr_size[2], int32_T
  c2_arr_size[2], int32_T c2_rfs_size[1], real_T c2_unImpSugRuleOut_data[],
  int32_T c2_unImpSugRuleOut_size[2], c2_emxArray_real_T *c2_outputMFCache)
{
  static char_T c2_b[7] = { 'm', 'a', 'm', 'd', 'a', 'n', 'i' };

  c2_emxArray_real_T *c2_r;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_b_fis;
  emlrtStack c2_st;
  real_T c2_fis_data[101];
  int32_T c2_fis_size[2];
  int32_T c2_iv[2];
  int32_T c2_b_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_loop_ub;
  int32_T c2_ret;
  char_T c2_y[7];
  uint8_T c2_varargin_1[7];
  boolean_T c2_bool;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_y_size[0] = 1;
  c2_y_size[1] = 1;
  c2_irr_size[0] = 24;
  c2_irr_size[1] = 2;
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_iv[c2_i] = c2_fis->orrSize[c2_i];
  }

  c2_orr_size[0] = c2_iv[0];
  c2_orr_size[1] = c2_iv[1];
  for (c2_i1 = 0; c2_i1 < 2; c2_i1++) {
    c2_iv[c2_i1] = c2_fis->aggSize[c2_i1];
  }

  c2_arr_size[0] = c2_iv[0];
  c2_arr_size[1] = 1;
  c2_rfs_size[0] = 24;
  for (c2_i2 = 0; c2_i2 < 7; c2_i2++) {
    c2_varargin_1[c2_i2] = c2_fis->type[c2_i2];
  }

  for (c2_i3 = 0; c2_i3 < 7; c2_i3++) {
    c2_y[c2_i3] = (char_T)(int8_T)c2_varargin_1[c2_i3];
  }

  c2_ret = memcmp(&c2_y[0], &c2_b[0], 7);
  c2_bool = (c2_ret == 0);
  if (c2_bool) {
    c2_b_fis = *c2_fis;
    c2_fis_size[0] = 1;
    c2_fis_size[1] = c2_fis->outputSamplePoints.size[1];
    c2_loop_ub = c2_fis->outputSamplePoints.size[0] *
      c2_fis->outputSamplePoints.size[1] - 1;
    for (c2_i5 = 0; c2_i5 <= c2_loop_ub; c2_i5++) {
      c2_fis_data[c2_i5] = c2_fis->outputSamplePoints.data[c2_i5];
    }

    c2_emxInit_real_T(chartInstance, c2_sp, &c2_r, 2, &c2_ff_emlrtRTEI);
    c2_st.site = &c2_cb_emlrtRSI;
    c2_createMamdaniOutputMFCache(chartInstance, &c2_st, &c2_b_fis, c2_fis_data,
      c2_fis_size, c2_r);
    c2_i7 = c2_outputMFCache->size[0] * c2_outputMFCache->size[1];
    c2_outputMFCache->size[0] = c2_r->size[0];
    c2_outputMFCache->size[1] = 101;
    c2_st.site = &c2_me_emlrtRSI;
    c2_emxEnsureCapacity_real_T(chartInstance, &c2_st, c2_outputMFCache, c2_i7,
      &c2_df_emlrtRTEI);
    c2_b_loop_ub = c2_r->size[0] * c2_r->size[1] - 1;
    for (c2_i8 = 0; c2_i8 <= c2_b_loop_ub; c2_i8++) {
      c2_outputMFCache->data[c2_i8] = c2_r->data[c2_i8];
    }

    c2_emxFree_real_T(chartInstance, &c2_r);
    c2_unImpSugRuleOut_size[0] = 1;
    c2_unImpSugRuleOut_size[1] = 1;
    c2_unImpSugRuleOut_data[0] = 0.0;
  } else {
    c2_i4 = c2_outputMFCache->size[0] * c2_outputMFCache->size[1];
    c2_outputMFCache->size[0] = 1;
    c2_outputMFCache->size[1] = 1;
    c2_st.site = &c2_ne_emlrtRSI;
    c2_emxEnsureCapacity_real_T(chartInstance, &c2_st, c2_outputMFCache, c2_i4,
      &c2_af_emlrtRTEI);
    c2_outputMFCache->data[0] = 0.0;
    for (c2_i6 = 0; c2_i6 < 2; c2_i6++) {
      c2_iv[c2_i6] = c2_fis->orrSize[c2_i6];
    }

    c2_unImpSugRuleOut_size[0] = c2_iv[0];
    c2_unImpSugRuleOut_size[1] = c2_iv[1];
  }
}

static void c2_fuzzifyInputs(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_inputs[2],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, c2_cell_wrap_0 c2_varargin_1[2],
  c2_emxArray_real_T *c2_varargin_2, real_T c2_varargin_3_data[], real_T
  c2_fuzzifiedInputs_data[], int32_T c2_fuzzifiedInputs_size[2],
  c2_emxArray_real_T *c2_inputMFCache)
{
  c2_cell_wrap_0 c2_b_varargin_1[2];
  c2_emxArray_real_T *c2_b_varargin_2;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_b_fis;
  real_T c2_b_inputs[2];
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_loop_ub;
  c2_fuzzifiedInputs_size[0] = 24;
  c2_fuzzifiedInputs_size[1] = 2;
  for (c2_i = 0; c2_i < 48; c2_i++) {
    c2_fuzzifiedInputs_data[c2_i] = c2_varargin_3_data[c2_i];
  }

  c2_b_fis = *c2_fis;
  for (c2_i1 = 0; c2_i1 < 2; c2_i1++) {
    c2_b_varargin_1[c2_i1] = c2_varargin_1[c2_i1];
  }

  c2_emxInit_real_T(chartInstance, c2_sp, &c2_b_varargin_2, 2, &c2_gf_emlrtRTEI);
  c2_i2 = c2_b_varargin_2->size[0] * c2_b_varargin_2->size[1];
  c2_b_varargin_2->size[0] = 1;
  c2_b_varargin_2->size[1] = c2_varargin_2->size[1];
  c2_emxEnsureCapacity_real_T(chartInstance, c2_sp, c2_b_varargin_2, c2_i2,
    &c2_gf_emlrtRTEI);
  c2_loop_ub = c2_varargin_2->size[0] * c2_varargin_2->size[1] - 1;
  for (c2_i3 = 0; c2_i3 <= c2_loop_ub; c2_i3++) {
    c2_b_varargin_2->data[c2_i3] = c2_varargin_2->data[c2_i3];
  }

  for (c2_i4 = 0; c2_i4 < 2; c2_i4++) {
    c2_b_inputs[c2_i4] = c2_inputs[c2_i4];
  }

  c2_b_fuzzifyInputs(chartInstance, c2_sp, c2_b_inputs, &c2_b_fis,
                     c2_b_varargin_1, c2_b_varargin_2, c2_fuzzifiedInputs_data,
                     c2_inputMFCache);
  c2_emxFree_real_T(chartInstance, &c2_b_varargin_2);
}

static void c2_applySugenoImplicationMethod
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, real_T c2_inputs[2], real_T c2_antecedentOutputs_data[],
   c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_consequentOutputs_data[],
   int32_T c2_consequentOutputs_size[2], real_T c2_unscaledOutputs_data[],
   int32_T c2_unscaledOutputs_size[2])
{
  c2_cell_wrap_0 c2_outVarMF[1];
  c2_emxArray_real_T *c2_outputMFCache;
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 c2_r;
  c2_s_64TxJFgCtXBlX73DcwNLAB c2_b_fis;
  emlrtStack c2_b_st;
  emlrtStack c2_c_st;
  emlrtStack c2_st;
  real_T c2_params_data[3];
  real_T c2_b_y;
  real_T c2_c_i;
  real_T c2_d;
  real_T c2_y;
  int32_T c2_iv[2];
  int32_T c2_params_size[2];
  int32_T c2_b_i;
  int32_T c2_b_loop_ub;
  int32_T c2_b_mfID;
  int32_T c2_b_ruleID;
  int32_T c2_c_loop_ub;
  int32_T c2_d_loop_ub;
  int32_T c2_e_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_loop_ub;
  int32_T c2_mfID;
  int32_T c2_mfIndex;
  int32_T c2_ruleID;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_c_st.prev = &c2_b_st;
  c2_c_st.tls = c2_b_st.tls;
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_iv[c2_i] = c2_fis->orrSize[c2_i];
  }

  c2_consequentOutputs_size[0] = c2_iv[0];
  c2_consequentOutputs_size[1] = c2_iv[1];
  c2_loop_ub = c2_iv[0] * c2_iv[1] - 1;
  for (c2_i1 = 0; c2_i1 <= c2_loop_ub; c2_i1++) {
    c2_consequentOutputs_data[c2_i1] = 0.0;
  }

  for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
    c2_iv[c2_i2] = c2_fis->orrSize[c2_i2];
  }

  c2_unscaledOutputs_size[0] = c2_iv[0];
  c2_unscaledOutputs_size[1] = c2_iv[1];
  c2_b_loop_ub = c2_iv[0] * c2_iv[1] - 1;
  for (c2_i3 = 0; c2_i3 <= c2_b_loop_ub; c2_i3++) {
    c2_unscaledOutputs_data[c2_i3] = 0.0;
  }

  c2_emxInit_real_T1(chartInstance, c2_sp, &c2_outputMFCache, 1,
                     &c2_jf_emlrtRTEI);
  c2_st.site = &c2_de_emlrtRSI;
  c2_y = c2_sumColumnB(chartInstance);
  c2_i4 = c2_outputMFCache->size[0];
  if (c2_y != (real_T)(int32_T)muDoubleScalarFloor(c2_y)) {
    emlrtIntegerCheckR2012b(c2_y, &c2_c_emlrtDCI, &c2_st);
  }

  c2_outputMFCache->size[0] = (int32_T)c2_y;
  c2_emxEnsureCapacity_real_T1(chartInstance, &c2_st, c2_outputMFCache, c2_i4,
    &c2_jf_emlrtRTEI);
  if (c2_y != (real_T)(int32_T)muDoubleScalarFloor(c2_y)) {
    emlrtIntegerCheckR2012b(c2_y, &c2_c_emlrtDCI, &c2_st);
  }

  c2_c_loop_ub = (int32_T)c2_y - 1;
  for (c2_i5 = 0; c2_i5 <= c2_c_loop_ub; c2_i5++) {
    c2_outputMFCache->data[c2_i5] = 0.0;
  }

  c2_b_fis = c2_fis->outputMF;
  c2_b_st.site = &c2_ee_emlrtRSI;
  c2_extractVarMF(chartInstance, &c2_b_st, &c2_b_fis, c2_outVarMF);
  for (c2_mfID = 0; c2_mfID < 5; c2_mfID++) {
    c2_b_mfID = c2_mfID;
    c2_d_loop_ub = c2_outVarMF[0].f1.size[0] * c2_outVarMF[0].f1.size[1] - 1;
    for (c2_i6 = 0; c2_i6 <= c2_d_loop_ub; c2_i6++) {
      c2_r.data[c2_i6] = c2_outVarMF[0].f1.data[c2_i6];
    }

    c2_b_st.site = &c2_fe_emlrtRSI;
    c2_params_size[1] = c2_r.data[c2_b_mfID].params.size[1];
    c2_e_loop_ub = c2_r.data[c2_b_mfID].params.size[0] * c2_r.data[c2_b_mfID].
      params.size[1] - 1;
    for (c2_i8 = 0; c2_i8 <= c2_e_loop_ub; c2_i8++) {
      c2_params_data[c2_i8] = c2_r.data[c2_b_mfID].params.data[c2_i8];
    }

    c2_c_st.site = &c2_ge_emlrtRSI;
    c2_b_y = 0.0;
    for (c2_b_i = 0; c2_b_i < 2; c2_b_i++) {
      c2_c_i = (real_T)c2_b_i + 1.0;
      c2_i10 = (int32_T)c2_c_i;
      if ((c2_i10 < 1) || (c2_i10 > c2_params_size[1])) {
        emlrtDynamicBoundsCheckR2012b(c2_i10, 1, c2_params_size[1],
          &c2_ud_emlrtBCI, &c2_c_st);
      }

      c2_b_y += c2_inputs[(int32_T)c2_c_i - 1] * c2_params_data[c2_i10 - 1];
    }

    c2_i9 = 3;
    if ((c2_i9 < 1) || (c2_i9 > c2_params_size[1])) {
      emlrtDynamicBoundsCheckR2012b(c2_i9, 1, c2_params_size[1], &c2_td_emlrtBCI,
        &c2_c_st);
    }

    c2_b_y += c2_params_data[2];
    c2_outputMFCache->data[c2_b_mfID] = c2_b_y;
  }

  for (c2_ruleID = 0; c2_ruleID < 24; c2_ruleID++) {
    c2_b_ruleID = c2_ruleID;
    c2_d = muDoubleScalarRound(c2_fis->consequent[c2_b_ruleID]);
    if (c2_d < 2.147483648E+9) {
      if (c2_d >= -2.147483648E+9) {
        c2_i7 = (int32_T)c2_d;
      } else {
        c2_i7 = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      }
    } else if (c2_d >= 2.147483648E+9) {
      c2_i7 = MAX_int32_T;
      sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
    } else {
      c2_i7 = 0;
    }

    c2_mfIndex = c2_i7 - 1;
    c2_unscaledOutputs_data[c2_b_ruleID] = c2_outputMFCache->data[c2_mfIndex];
    c2_consequentOutputs_data[c2_b_ruleID] = c2_outputMFCache->data[c2_mfIndex] *
      c2_antecedentOutputs_data[c2_b_ruleID];
  }

  c2_emxFree_real_T(chartInstance, &c2_outputMFCache);
}

static void c2_b_runFIS(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_inputs[2],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_y_data[], int32_T c2_y_size[2],
  real_T c2_irr_data[], int32_T c2_irr_size[2], real_T c2_orr_data[], int32_T
  c2_orr_size[2], real_T c2_arr_data[], int32_T c2_arr_size[2], real_T
  c2_w_data[], int32_T c2_w_size[1], real_T c2_unImpSugRuleOut_data[], int32_T
  c2_unImpSugRuleOut_size[2])
{
  c2_cell_wrap_0 c2_inVarMF[2];
  c2_emxArray_real_T *c2_b_inputMFCache;
  c2_emxArray_real_T *c2_inputMFCache;
  c2_emxArray_real_T *c2_outputMFCache;
  c2_emxArray_real_T *c2_r;
  c2_s_64TxJFgCtXBlX73DcwNLAB c2_c_fis[2];
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_b_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_d_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_e_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_f_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_g_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_h_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_i_fis;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_j_fis;
  emlrtStack c2_st;
  real_T c2_b_orr_data[2424];
  real_T c2_c_orr_data[2424];
  real_T c2_tmp_data[2424];
  real_T c2_c_arr_data[101];
  real_T c2_d_arr_data[101];
  real_T c2_fis_data[101];
  real_T c2_b_irr_data[48];
  real_T c2_b_arr_data[24];
  real_T c2_b_w_data[24];
  real_T c2_c_w_data[24];
  real_T c2_b_inputs[2];
  real_T c2_c_inputs[2];
  real_T c2_irrOfOneRule_data[2];
  real_T c2_c_tmp_data[1];
  real_T c2_d_tmp_data[1];
  real_T c2_sw;
  real_T c2_y;
  int32_T c2_b_arr_size[2];
  int32_T c2_b_orr_size[2];
  int32_T c2_c_arr_size[2];
  int32_T c2_c_orr_size[2];
  int32_T c2_c_tmp_size[2];
  int32_T c2_d_arr_size[2];
  int32_T c2_d_orr_size[2];
  int32_T c2_fis_size[2];
  int32_T c2_iv[2];
  int32_T c2_iv1[2];
  int32_T c2_tmp_size[2];
  int32_T c2_x[2];
  int32_T c2_b_tmp_data[1];
  int32_T c2_b_tmp_size[1];
  int32_T c2_b_loop_ub;
  int32_T c2_c_loop_ub;
  int32_T c2_d_loop_ub;
  int32_T c2_e_loop_ub;
  int32_T c2_f_loop_ub;
  int32_T c2_g_loop_ub;
  int32_T c2_h_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i19;
  int32_T c2_i2;
  int32_T c2_i20;
  int32_T c2_i21;
  int32_T c2_i22;
  int32_T c2_i23;
  int32_T c2_i24;
  int32_T c2_i25;
  int32_T c2_i26;
  int32_T c2_i27;
  int32_T c2_i28;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_loop_ub;
  char_T c2_b_y[7];
  uint8_T c2_varargin_1[7];
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_emxInit_real_T(chartInstance, c2_sp, &c2_outputMFCache, 2, &c2_se_emlrtRTEI);
  c2_b_fis = *c2_fis;
  c2_st.site = &c2_t_emlrtRSI;
  c2_initVariables(chartInstance, &c2_st, &c2_b_fis, c2_y_size, c2_irr_size,
                   c2_b_orr_size, c2_b_arr_size, c2_w_size,
                   c2_unImpSugRuleOut_data, c2_unImpSugRuleOut_size,
                   c2_outputMFCache);
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_c_fis[c2_i] = c2_fis->inputMF[c2_i];
  }

  c2_st.site = &c2_u_emlrtRSI;
  c2_b_extractVarMF(chartInstance, &c2_st, c2_c_fis, c2_inVarMF);
  c2_emxInit_real_T(chartInstance, c2_sp, &c2_inputMFCache, 2, &c2_re_emlrtRTEI);
  c2_y = c2_b_sumColumnB(chartInstance);
  c2_x[0] = 1;
  if (c2_y != (real_T)(int32_T)muDoubleScalarFloor(c2_y)) {
    emlrtIntegerCheckR2012b(c2_y, &c2_b_emlrtDCI, (void *)c2_sp);
  }

  c2_x[1] = (int32_T)c2_y;
  c2_i1 = c2_inputMFCache->size[0] * c2_inputMFCache->size[1];
  c2_inputMFCache->size[0] = c2_x[0];
  c2_inputMFCache->size[1] = c2_x[1];
  c2_st.site = &c2_le_emlrtRSI;
  c2_emxEnsureCapacity_real_T(chartInstance, &c2_st, c2_inputMFCache, c2_i1,
    &c2_td_emlrtRTEI);
  for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
    c2_irrOfOneRule_data[c2_i2] = 0.0;
  }

  c2_emxInit_real_T(chartInstance, c2_sp, &c2_b_inputMFCache, 2,
                    &c2_wd_emlrtRTEI);
  c2_d_fis = *c2_fis;
  c2_i3 = c2_b_inputMFCache->size[0] * c2_b_inputMFCache->size[1];
  c2_b_inputMFCache->size[0] = 1;
  c2_b_inputMFCache->size[1] = c2_inputMFCache->size[1];
  c2_st.site = &c2_ke_emlrtRSI;
  c2_emxEnsureCapacity_real_T(chartInstance, &c2_st, c2_b_inputMFCache, c2_i3,
    &c2_wd_emlrtRTEI);
  c2_loop_ub = c2_inputMFCache->size[0] * c2_inputMFCache->size[1] - 1;
  for (c2_i4 = 0; c2_i4 <= c2_loop_ub; c2_i4++) {
    c2_b_inputMFCache->data[c2_i4] = c2_inputMFCache->data[c2_i4];
  }

  c2_emxInit_real_T(chartInstance, c2_sp, &c2_r, 2, &c2_se_emlrtRTEI);
  c2_st.site = &c2_v_emlrtRSI;
  for (c2_i5 = 0; c2_i5 < 2; c2_i5++) {
    c2_b_inputs[c2_i5] = c2_inputs[c2_i5];
  }

  c2_b_fuzzifyInputs(chartInstance, &c2_st, c2_b_inputs, &c2_d_fis, c2_inVarMF,
                     c2_b_inputMFCache, c2_irr_data, c2_r);
  c2_i6 = c2_inputMFCache->size[1];
  c2_i7 = c2_r->size[1];
  if (c2_i6 != c2_i7) {
    emlrtSubAssignSizeCheck1dR2017a(c2_i6, c2_i7, &c2_n_emlrtECI, (void *)c2_sp);
  }

  c2_emxFree_real_T(chartInstance, &c2_b_inputMFCache);
  c2_emxFree_real_T(chartInstance, &c2_r);
  c2_emxFree_real_T(chartInstance, &c2_inputMFCache);
  for (c2_i8 = 0; c2_i8 < 48; c2_i8++) {
    c2_b_irr_data[c2_i8] = c2_irr_data[c2_i8];
  }

  c2_e_fis = *c2_fis;
  c2_st.site = &c2_w_emlrtRSI;
  c2_sw = c2_b_applyOperators(chartInstance, &c2_st, c2_b_irr_data, &c2_e_fis,
    c2_w_data, c2_irrOfOneRule_data);
  for (c2_i9 = 0; c2_i9 < 7; c2_i9++) {
    c2_varargin_1[c2_i9] = c2_fis->type[c2_i9];
  }

  for (c2_i10 = 0; c2_i10 < 7; c2_i10++) {
    c2_b_y[c2_i10] = (char_T)(int8_T)c2_varargin_1[c2_i10];
  }

  if (c2_strcmp(chartInstance, c2_b_y)) {
    for (c2_i12 = 0; c2_i12 < 24; c2_i12++) {
      c2_c_w_data[c2_i12] = c2_w_data[c2_i12];
    }

    c2_g_fis = *c2_fis;
    c2_st.site = &c2_x_emlrtRSI;
    c2_applyMamdaniImplicationMethod(chartInstance, &c2_st, c2_c_w_data,
      &c2_g_fis, c2_outputMFCache, c2_orr_data, c2_orr_size);
    c2_i14 = c2_b_orr_size[0] * c2_b_orr_size[1];
    c2_i15 = c2_orr_size[0] * c2_orr_size[1];
    if (c2_i14 != c2_i15) {
      emlrtSubAssignSizeCheck1dR2017a(c2_i14, c2_i15, &c2_o_emlrtECI, (void *)
        c2_sp);
    }

    c2_c_orr_size[0] = c2_orr_size[0];
    c2_c_orr_size[1] = c2_orr_size[1];
    c2_b_loop_ub = c2_orr_size[0] * c2_orr_size[1] - 1;
    for (c2_i20 = 0; c2_i20 <= c2_b_loop_ub; c2_i20++) {
      c2_b_orr_data[c2_i20] = c2_orr_data[c2_i20];
    }

    c2_h_fis = *c2_fis;
    c2_st.site = &c2_y_emlrtRSI;
    c2_applyMamdaniAggregationMethod(chartInstance, &c2_st, c2_b_orr_data,
      c2_c_orr_size, &c2_h_fis, c2_arr_data, c2_arr_size);
    if (c2_b_arr_size[0] != c2_arr_size[0]) {
      emlrtSubAssignSizeCheck1dR2017a(c2_b_arr_size[0], c2_arr_size[0],
        &c2_p_emlrtECI, (void *)c2_sp);
    }

    c2_b_tmp_data[0] = 0;
    c2_fis_size[0] = 1;
    c2_fis_size[1] = c2_fis->outputSamplePoints.size[1];
    c2_e_loop_ub = c2_fis->outputSamplePoints.size[0] *
      c2_fis->outputSamplePoints.size[1] - 1;
    for (c2_i23 = 0; c2_i23 <= c2_e_loop_ub; c2_i23++) {
      c2_fis_data[c2_i23] = c2_fis->outputSamplePoints.data[c2_i23];
    }

    c2_d_arr_size[0] = c2_arr_size[0];
    c2_d_arr_size[1] = 1;
    c2_f_loop_ub = c2_arr_size[0] * c2_arr_size[1] - 1;
    for (c2_i24 = 0; c2_i24 <= c2_f_loop_ub; c2_i24++) {
      c2_c_arr_data[c2_i24] = c2_arr_data[c2_i24];
    }

    c2_i_fis = *c2_fis;
    c2_st.site = &c2_ab_emlrtRSI;
    c2_b_applyMamdaniDefuzzificationMethod(chartInstance, &c2_st, c2_fis_data,
      c2_fis_size, c2_sw, c2_c_arr_data, c2_d_arr_size, &c2_i_fis, c2_c_tmp_data,
      c2_b_tmp_size);
    c2_c_tmp_size[0] = 1;
    c2_c_tmp_size[1] = 1;
    c2_d_tmp_data[0] = c2_c_tmp_data[0];
    for (c2_i27 = 0; c2_i27 < 2; c2_i27++) {
      c2_iv[c2_i27] = 1;
    }

    emlrtSubAssignSizeCheckR2012b(&c2_iv[0], 2, &c2_c_tmp_size[0], 2,
      &c2_s_emlrtECI, (void *)c2_sp);
    c2_y_data[c2_b_tmp_data[0]] = c2_d_tmp_data[0];
  } else {
    for (c2_i11 = 0; c2_i11 < 24; c2_i11++) {
      c2_b_w_data[c2_i11] = c2_w_data[c2_i11];
    }

    c2_f_fis = *c2_fis;
    c2_st.site = &c2_bb_emlrtRSI;
    for (c2_i13 = 0; c2_i13 < 2; c2_i13++) {
      c2_c_inputs[c2_i13] = c2_inputs[c2_i13];
    }

    c2_applySugenoImplicationMethod(chartInstance, &c2_st, c2_c_inputs,
      c2_b_w_data, &c2_f_fis, c2_orr_data, c2_orr_size, c2_tmp_data, c2_tmp_size);
    c2_i16 = c2_b_orr_size[0] * c2_b_orr_size[1];
    c2_i17 = c2_orr_size[0] * c2_orr_size[1];
    if (c2_i16 != c2_i17) {
      emlrtSubAssignSizeCheck1dR2017a(c2_i16, c2_i17, &c2_q_emlrtECI, (void *)
        c2_sp);
    }

    c2_i18 = c2_unImpSugRuleOut_size[0] * c2_unImpSugRuleOut_size[1];
    c2_i19 = c2_tmp_size[0] * c2_tmp_size[1];
    if (c2_i18 != c2_i19) {
      emlrtSubAssignSizeCheck1dR2017a(c2_i18, c2_i19, &c2_u_emlrtECI, (void *)
        c2_sp);
    }

    c2_unImpSugRuleOut_size[0] = c2_tmp_size[0];
    c2_unImpSugRuleOut_size[1] = c2_tmp_size[1];
    c2_c_loop_ub = c2_tmp_size[0] * c2_tmp_size[1] - 1;
    for (c2_i21 = 0; c2_i21 <= c2_c_loop_ub; c2_i21++) {
      c2_unImpSugRuleOut_data[c2_i21] = c2_tmp_data[c2_i21];
    }

    c2_d_orr_size[0] = c2_orr_size[0];
    c2_d_orr_size[1] = c2_orr_size[1];
    c2_d_loop_ub = c2_orr_size[0] * c2_orr_size[1] - 1;
    for (c2_i22 = 0; c2_i22 <= c2_d_loop_ub; c2_i22++) {
      c2_c_orr_data[c2_i22] = c2_orr_data[c2_i22];
    }

    c2_applySugenoAggregationMethod(chartInstance, c2_c_orr_data, c2_d_orr_size,
      c2_b_arr_data, c2_c_arr_size);
    if (c2_b_arr_size[0] != c2_c_arr_size[1]) {
      emlrtSubAssignSizeCheck1dR2017a(c2_b_arr_size[0], c2_c_arr_size[1],
        &c2_r_emlrtECI, (void *)c2_sp);
    }

    c2_arr_size[0] = c2_b_arr_size[0];
    c2_arr_size[1] = 1;
    c2_g_loop_ub = c2_b_arr_size[0] * c2_b_arr_size[1] - 1;
    for (c2_i25 = 0; c2_i25 <= c2_g_loop_ub; c2_i25++) {
      c2_arr_data[c2_i25] = c2_b_arr_data[c2_i25];
    }

    c2_b_tmp_data[0] = 0;
    c2_h_loop_ub = c2_arr_size[0] * c2_arr_size[1] - 1;
    for (c2_i26 = 0; c2_i26 <= c2_h_loop_ub; c2_i26++) {
      c2_d_arr_data[c2_i26] = c2_arr_data[c2_i26];
    }

    c2_j_fis = *c2_fis;
    c2_b_applySugenoDefuzzificationMethod(chartInstance, c2_sw, c2_d_arr_data,
      &c2_j_fis, c2_c_tmp_data, c2_b_tmp_size);
    c2_c_tmp_size[0] = 1;
    c2_c_tmp_size[1] = 1;
    c2_d_tmp_data[0] = c2_c_tmp_data[0];
    for (c2_i28 = 0; c2_i28 < 2; c2_i28++) {
      c2_iv1[c2_i28] = 1;
    }

    emlrtSubAssignSizeCheckR2012b(&c2_iv1[0], 2, &c2_c_tmp_size[0], 2,
      &c2_t_emlrtECI, (void *)c2_sp);
    c2_y_data[c2_b_tmp_data[0]] = c2_d_tmp_data[0];
  }

  c2_emxFree_real_T(chartInstance, &c2_outputMFCache);
}

static void c2_b_initVariables(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis,
  int32_T c2_y_size[2], int32_T c2_irr_size[2], int32_T c2_orr_size[2], int32_T
  c2_arr_size[2], int32_T c2_rfs_size[1], real_T c2_unImpSugRuleOut_data[],
  int32_T c2_unImpSugRuleOut_size[2])
{
  static char_T c2_b[7] = { 'm', 'a', 'm', 'd', 'a', 'n', 'i' };

  c2_emxArray_real_T *c2_pe_emlrtRSI;
  c2_s_9DL33rUTgryGqqXf4f6A1E c2_b_fis;
  emlrtStack c2_st;
  real_T c2_fis_data[101];
  int32_T c2_fis_size[2];
  int32_T c2_iv[2];
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_loop_ub;
  int32_T c2_ret;
  char_T c2_y[7];
  uint8_T c2_varargin_1[7];
  boolean_T c2_bool;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_y_size[0] = 1;
  c2_y_size[1] = 1;
  c2_irr_size[0] = 24;
  c2_irr_size[1] = 2;
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_iv[c2_i] = c2_fis->orrSize[c2_i];
  }

  c2_orr_size[0] = c2_iv[0];
  c2_orr_size[1] = c2_iv[1];
  for (c2_i1 = 0; c2_i1 < 2; c2_i1++) {
    c2_iv[c2_i1] = c2_fis->aggSize[c2_i1];
  }

  c2_arr_size[0] = c2_iv[0];
  c2_arr_size[1] = 1;
  c2_rfs_size[0] = 24;
  for (c2_i2 = 0; c2_i2 < 7; c2_i2++) {
    c2_varargin_1[c2_i2] = c2_fis->type[c2_i2];
  }

  for (c2_i3 = 0; c2_i3 < 7; c2_i3++) {
    c2_y[c2_i3] = (char_T)(int8_T)c2_varargin_1[c2_i3];
  }

  c2_ret = memcmp(&c2_y[0], &c2_b[0], 7);
  c2_bool = (c2_ret == 0);
  if (c2_bool) {
    c2_b_fis = *c2_fis;
    c2_fis_size[0] = 1;
    c2_fis_size[1] = c2_fis->outputSamplePoints.size[1];
    c2_loop_ub = c2_fis->outputSamplePoints.size[0] *
      c2_fis->outputSamplePoints.size[1] - 1;
    for (c2_i5 = 0; c2_i5 <= c2_loop_ub; c2_i5++) {
      c2_fis_data[c2_i5] = c2_fis->outputSamplePoints.data[c2_i5];
    }

    c2_emxInit_real_T(chartInstance, c2_sp, &c2_pe_emlrtRSI, 2, &c2_mf_emlrtRTEI);
    c2_st.site = &c2_cb_emlrtRSI;
    c2_createMamdaniOutputMFCache(chartInstance, &c2_st, &c2_b_fis, c2_fis_data,
      c2_fis_size, c2_pe_emlrtRSI);
    c2_unImpSugRuleOut_size[0] = 1;
    c2_unImpSugRuleOut_size[1] = 1;
    c2_unImpSugRuleOut_data[0] = 0.0;
    c2_emxFree_real_T(chartInstance, &c2_pe_emlrtRSI);
  } else {
    for (c2_i4 = 0; c2_i4 < 2; c2_i4++) {
      c2_iv[c2_i4] = c2_fis->orrSize[c2_i4];
    }

    c2_unImpSugRuleOut_size[0] = c2_iv[0];
    c2_unImpSugRuleOut_size[1] = c2_iv[1];
  }
}

static real_T c2_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_a__output_of_feval_, const char_T
  *c2_identifier)
{
  emlrtMsgIdentifier c2_thisId;
  real_T c2_y;
  c2_thisId.fIdentifier = (const char_T *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_a__output_of_feval_),
    &c2_thisId);
  sf_mex_destroy(&c2_a__output_of_feval_);
  return c2_y;
}

static real_T c2_b_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  real_T c2_d;
  real_T c2_y;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_d, 1, 0, 0U, 0, 0U, 0);
  c2_y = c2_d;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static const mxArray *c2_emlrt_marshallOut
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const
   c2_suvN3HkMprFcIaMRVdi47eC c2_u[5])
{
  static const char_T *c2_b_sv[6] = { "name", "origNameLength", "type",
    "origTypeLength", "params", "origParamLength" };

  const c2_suvN3HkMprFcIaMRVdi47eC *c2_r;
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_e_y = NULL;
  const mxArray *c2_f_y = NULL;
  const mxArray *c2_g_y = NULL;
  const mxArray *c2_y;
  real_T c2_f_u[3];
  real_T c2_c_u;
  real_T c2_e_u;
  real_T c2_g_u;
  int32_T c2_iv[2];
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  char_T c2_d_u[5];
  char_T c2_b_u[2];
  (void)chartInstance;
  c2_y = NULL;
  c2_y = NULL;
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_iv[c2_i] = 1 + (c2_i << 2);
  }

  sf_mex_assign(&c2_y, sf_mex_createstructarray("structure", 2, c2_iv, 6,
    c2_b_sv), false);
  for (c2_i1 = 0; c2_i1 < 5; c2_i1++) {
    c2_r = &c2_u[c2_i1];
    for (c2_i2 = 0; c2_i2 < 2; c2_i2++) {
      c2_b_u[c2_i2] = c2_r->name[c2_i2];
    }

    c2_b_y = NULL;
    sf_mex_assign(&c2_b_y, sf_mex_create("y", c2_b_u, 10, 0U, 1U, 0U, 2, 1, 2),
                  false);
    sf_mex_setfieldbynum(c2_y, c2_i1, "name", c2_b_y, 0);
    c2_c_u = c2_r->origNameLength;
    c2_c_y = NULL;
    sf_mex_assign(&c2_c_y, sf_mex_create("y", &c2_c_u, 0, 0U, 0U, 0U, 0), false);
    sf_mex_setfieldbynum(c2_y, c2_i1, "origNameLength", c2_c_y, 1);
    for (c2_i3 = 0; c2_i3 < 5; c2_i3++) {
      c2_d_u[c2_i3] = c2_r->type[c2_i3];
    }

    c2_d_y = NULL;
    sf_mex_assign(&c2_d_y, sf_mex_create("y", c2_d_u, 10, 0U, 1U, 0U, 2, 1, 5),
                  false);
    sf_mex_setfieldbynum(c2_y, c2_i1, "type", c2_d_y, 2);
    c2_e_u = c2_r->origTypeLength;
    c2_e_y = NULL;
    sf_mex_assign(&c2_e_y, sf_mex_create("y", &c2_e_u, 0, 0U, 0U, 0U, 0), false);
    sf_mex_setfieldbynum(c2_y, c2_i1, "origTypeLength", c2_e_y, 3);
    for (c2_i4 = 0; c2_i4 < 3; c2_i4++) {
      c2_f_u[c2_i4] = c2_r->params[c2_i4];
    }

    c2_f_y = NULL;
    sf_mex_assign(&c2_f_y, sf_mex_create("y", c2_f_u, 0, 0U, 1U, 0U, 2, 1, 3),
                  false);
    sf_mex_setfieldbynum(c2_y, c2_i1, "params", c2_f_y, 4);
    c2_g_u = c2_r->origParamLength;
    c2_g_y = NULL;
    sf_mex_assign(&c2_g_y, sf_mex_create("y", &c2_g_u, 0, 0U, 0U, 0U, 0), false);
    sf_mex_setfieldbynum(c2_y, c2_i1, "origParamLength", c2_g_y, 5);
  }

  return c2_y;
}

static real_T c2_c_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_b_D_prev, const char_T *c2_identifier,
  boolean_T *c2_svPtr)
{
  emlrtMsgIdentifier c2_thisId;
  real_T c2_y;
  c2_thisId.fIdentifier = (const char_T *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_D_prev),
    &c2_thisId, c2_svPtr);
  sf_mex_destroy(&c2_b_D_prev);
  return c2_y;
}

static real_T c2_d_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  boolean_T *c2_svPtr)
{
  real_T c2_d;
  real_T c2_y;
  (void)chartInstance;
  if (mxIsEmpty(c2_u)) {
    *c2_svPtr = false;
  } else {
    *c2_svPtr = true;
    sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_d, 1, 0, 0U, 0, 0U, 0);
    c2_y = c2_d;
  }

  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_e_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_b_fis_obj, const char_T *c2_identifier,
  boolean_T *c2_svPtr, c2_s4qsEqaDHXG669afyZjSQlH *c2_y)
{
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = (const char_T *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_fis_obj), &c2_thisId,
                        c2_svPtr, c2_y);
  sf_mex_destroy(&c2_b_fis_obj);
}

static void c2_f_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  boolean_T *c2_svPtr, c2_s4qsEqaDHXG669afyZjSQlH *c2_y)
{
  static const char_T *c2_fieldNames[10] = { "name", "type", "andMethod",
    "orMethod", "defuzzMethod", "impMethod", "aggMethod", "input", "output",
    "rule" };

  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fParent = c2_parentId;
  c2_thisId.bParentIsCell = false;
  if (mxIsEmpty(c2_u)) {
    *c2_svPtr = false;
  } else {
    *c2_svPtr = true;
    sf_mex_check_struct(c2_parentId, c2_u, 10, c2_fieldNames, 0U, NULL);
    c2_thisId.fIdentifier = "name";
    c2_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u, "name",
      "name", 0)), &c2_thisId, c2_y->name);
    c2_thisId.fIdentifier = "type";
    c2_h_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u, "type",
      "type", 0)), &c2_thisId, c2_y->type);
    c2_thisId.fIdentifier = "andMethod";
    c2_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u,
      "andMethod", "andMethod", 0)), &c2_thisId, c2_y->andMethod);
    c2_thisId.fIdentifier = "orMethod";
    c2_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u,
      "orMethod", "orMethod", 0)), &c2_thisId, c2_y->orMethod);
    c2_thisId.fIdentifier = "defuzzMethod";
    c2_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u,
      "defuzzMethod", "defuzzMethod", 0)), &c2_thisId, c2_y->defuzzMethod);
    c2_thisId.fIdentifier = "impMethod";
    c2_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u,
      "impMethod", "impMethod", 0)), &c2_thisId, c2_y->impMethod);
    c2_thisId.fIdentifier = "aggMethod";
    c2_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u,
      "aggMethod", "aggMethod", 0)), &c2_thisId, c2_y->aggMethod);
    c2_thisId.fIdentifier = "input";
    c2_j_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u,
      "input", "input", 0)), &c2_thisId, c2_y->input);
    c2_thisId.fIdentifier = "output";
    c2_p_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u,
      "output", "output", 0)), &c2_thisId, &c2_y->output);
    c2_thisId.fIdentifier = "rule";
    c2_q_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u, "rule",
      "rule", 0)), &c2_thisId, c2_y->rule);
  }

  sf_mex_destroy(&c2_u);
}

static void c2_g_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  char_T c2_y[8])
{
  int32_T c2_i;
  char_T c2_b_cv[8];
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_b_cv, 1, 10, 0U, 1, 0U, 2, 1,
                8);
  for (c2_i = 0; c2_i < 8; c2_i++) {
    c2_y[c2_i] = c2_b_cv[c2_i];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_h_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  char_T c2_y[7])
{
  int32_T c2_i;
  char_T c2_b_cv[7];
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_b_cv, 1, 10, 0U, 1, 0U, 2, 1,
                7);
  for (c2_i = 0; c2_i < 7; c2_i++) {
    c2_y[c2_i] = c2_b_cv[c2_i];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_i_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  char_T c2_y[3])
{
  int32_T c2_i;
  char_T c2_b_cv[3];
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_b_cv, 1, 10, 0U, 1, 0U, 2, 1,
                3);
  for (c2_i = 0; c2_i < 3; c2_i++) {
    c2_y[c2_i] = c2_b_cv[c2_i];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_j_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  c2_s5XYxtK6icIzLqFV4FdSKVC c2_y[2])
{
  emlrtMsgIdentifier c2_thisId;
  int32_T c2_i;
  int32_T c2_i1;
  uint32_T c2_uv[2];
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_uv[c2_i] = 1U + (uint32_T)c2_i;
  }

  c2_thisId.fParent = c2_parentId;
  c2_thisId.bParentIsCell = false;
  sf_mex_check_struct(c2_parentId, c2_u, 5, c2_sv, 2U, c2_uv);
  for (c2_i1 = 0; c2_i1 < 2; c2_i1++) {
    c2_thisId.fIdentifier = "name";
    c2_k_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u, "name",
      "name", c2_i1)), &c2_thisId, c2_y[c2_i1].name);
    c2_thisId.fIdentifier = "origNameLength";
    c2_y[c2_i1].origNameLength = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c2_u, "origNameLength", "origNameLength", c2_i1)),
      &c2_thisId);
    c2_thisId.fIdentifier = "range";
    c2_l_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u,
      "range", "range", c2_i1)), &c2_thisId, c2_y[c2_i1].range);
    c2_thisId.fIdentifier = "mf";
    c2_m_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u, "mf",
      "mf", c2_i1)), &c2_thisId, c2_y[c2_i1].mf);
    c2_thisId.fIdentifier = "origNumMF";
    c2_y[c2_i1].origNumMF = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c2_u, "origNumMF", "origNumMF", c2_i1)), &c2_thisId);
  }

  sf_mex_destroy(&c2_u);
}

static void c2_k_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  char_T c2_y[2])
{
  int32_T c2_i;
  char_T c2_b_cv[2];
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_b_cv, 1, 10, 0U, 1, 0U, 2, 1,
                2);
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_y[c2_i] = c2_b_cv[c2_i];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_l_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  real_T c2_y[2])
{
  real_T c2_dv[2];
  int32_T c2_i;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_dv, 1, 0, 0U, 1, 0U, 2, 1, 2);
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_y[c2_i] = c2_dv[c2_i];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_m_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  c2_suvN3HkMprFcIaMRVdi47eC c2_y[5])
{
  static const char_T *c2_fieldNames[6] = { "name", "origNameLength", "type",
    "origTypeLength", "params", "origParamLength" };

  emlrtMsgIdentifier c2_thisId;
  int32_T c2_i;
  int32_T c2_i1;
  uint32_T c2_uv[2];
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_uv[c2_i] = 1U + ((uint32_T)c2_i << 2);
  }

  c2_thisId.fParent = c2_parentId;
  c2_thisId.bParentIsCell = false;
  sf_mex_check_struct(c2_parentId, c2_u, 6, c2_fieldNames, 2U, c2_uv);
  for (c2_i1 = 0; c2_i1 < 5; c2_i1++) {
    c2_thisId.fIdentifier = "name";
    c2_k_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u, "name",
      "name", c2_i1)), &c2_thisId, c2_y[c2_i1].name);
    c2_thisId.fIdentifier = "origNameLength";
    c2_y[c2_i1].origNameLength = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c2_u, "origNameLength", "origNameLength", c2_i1)),
      &c2_thisId);
    c2_thisId.fIdentifier = "type";
    c2_n_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u, "type",
      "type", c2_i1)), &c2_thisId, c2_y[c2_i1].type);
    c2_thisId.fIdentifier = "origTypeLength";
    c2_y[c2_i1].origTypeLength = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c2_u, "origTypeLength", "origTypeLength", c2_i1)),
      &c2_thisId);
    c2_thisId.fIdentifier = "params";
    c2_o_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u,
      "params", "params", c2_i1)), &c2_thisId, c2_y[c2_i1].params);
    c2_thisId.fIdentifier = "origParamLength";
    c2_y[c2_i1].origParamLength = c2_b_emlrt_marshallIn(chartInstance,
      sf_mex_dup(sf_mex_getfield(c2_u, "origParamLength", "origParamLength",
      c2_i1)), &c2_thisId);
  }

  sf_mex_destroy(&c2_u);
}

static void c2_n_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  char_T c2_y[5])
{
  int32_T c2_i;
  char_T c2_b_cv[5];
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_b_cv, 1, 10, 0U, 1, 0U, 2, 1,
                5);
  for (c2_i = 0; c2_i < 5; c2_i++) {
    c2_y[c2_i] = c2_b_cv[c2_i];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_o_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  real_T c2_y[3])
{
  real_T c2_dv[3];
  int32_T c2_i;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_dv, 1, 0, 0U, 1, 0U, 2, 1, 3);
  for (c2_i = 0; c2_i < 3; c2_i++) {
    c2_y[c2_i] = c2_dv[c2_i];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_p_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  c2_s5XYxtK6icIzLqFV4FdSKVC *c2_y)
{
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fParent = c2_parentId;
  c2_thisId.bParentIsCell = false;
  sf_mex_check_struct(c2_parentId, c2_u, 5, c2_sv, 0U, NULL);
  c2_thisId.fIdentifier = "name";
  c2_k_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u, "name",
    "name", 0)), &c2_thisId, c2_y->name);
  c2_thisId.fIdentifier = "origNameLength";
  c2_y->origNameLength = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c2_u, "origNameLength", "origNameLength", 0)), &c2_thisId);
  c2_thisId.fIdentifier = "range";
  c2_l_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u, "range",
    "range", 0)), &c2_thisId, c2_y->range);
  c2_thisId.fIdentifier = "mf";
  c2_m_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u, "mf",
    "mf", 0)), &c2_thisId, c2_y->mf);
  c2_thisId.fIdentifier = "origNumMF";
  c2_y->origNumMF = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c2_u, "origNumMF", "origNumMF", 0)), &c2_thisId);
  sf_mex_destroy(&c2_u);
}

static void c2_q_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId,
  c2_sEsqUUSxQBFGTGyl15EzrYH c2_y[24])
{
  static const char_T *c2_fieldNames[4] = { "antecedent", "consequent", "weight",
    "connection" };

  emlrtMsgIdentifier c2_thisId;
  int32_T c2_i;
  int32_T c2_i1;
  uint32_T c2_uv[2];
  for (c2_i = 0; c2_i < 2; c2_i++) {
    c2_uv[c2_i] = 1U + 23U * (uint32_T)c2_i;
  }

  c2_thisId.fParent = c2_parentId;
  c2_thisId.bParentIsCell = false;
  sf_mex_check_struct(c2_parentId, c2_u, 4, c2_fieldNames, 2U, c2_uv);
  for (c2_i1 = 0; c2_i1 < 24; c2_i1++) {
    c2_thisId.fIdentifier = "antecedent";
    c2_l_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getfield(c2_u,
      "antecedent", "antecedent", c2_i1)), &c2_thisId, c2_y[c2_i1].antecedent);
    c2_thisId.fIdentifier = "consequent";
    c2_y[c2_i1].consequent = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c2_u, "consequent", "consequent", c2_i1)), &c2_thisId);
    c2_thisId.fIdentifier = "weight";
    c2_y[c2_i1].weight = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c2_u, "weight", "weight", c2_i1)), &c2_thisId);
    c2_thisId.fIdentifier = "connection";
    c2_y[c2_i1].connection = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
      (sf_mex_getfield(c2_u, "connection", "connection", c2_i1)), &c2_thisId);
  }

  sf_mex_destroy(&c2_u);
}

static uint8_T c2_r_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *
  chartInstance, const mxArray *c2_b_is_active_c2_SimulinkSKRIPSIFIKS_FLC, const
  char_T *c2_identifier)
{
  emlrtMsgIdentifier c2_thisId;
  uint8_T c2_y;
  c2_thisId.fIdentifier = (const char_T *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_s_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_b_is_active_c2_SimulinkSKRIPSIFIKS_FLC), &c2_thisId);
  sf_mex_destroy(&c2_b_is_active_c2_SimulinkSKRIPSIFIKS_FLC);
  return c2_y;
}

static uint8_T c2_s_emlrt_marshallIn(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *
  chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  uint8_T c2_b_u;
  uint8_T c2_y;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_b_u, 1, 3, 0U, 0, 0U, 0);
  c2_y = c2_b_u;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_chart_data_browse_helper
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, int32_T
   c2_ssIdNumber, const mxArray **c2_mxData, uint8_T *c2_isValueTooBig)
{
  real_T c2_d;
  real_T c2_d1;
  real_T c2_d2;
  *c2_mxData = NULL;
  *c2_mxData = NULL;
  *c2_isValueTooBig = 0U;
  switch (c2_ssIdNumber) {
   case 4U:
    c2_d = *chartInstance->c2_dP;
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", &c2_d, 0, 0U, 0U, 0U, 0),
                  false);
    break;

   case 5U:
    c2_d1 = *chartInstance->c2_D;
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", &c2_d1, 0, 0U, 0U, 0U, 0),
                  false);
    break;

   case 6U:
    c2_d2 = *chartInstance->c2_dV;
    sf_mex_assign(c2_mxData, sf_mex_create("mxData", &c2_d2, 0, 0U, 0U, 0U, 0),
                  false);
    break;
  }
}

static const mxArray *c2_feval(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, const mxArray *c2_input0, const
  mxArray *c2_input1, const mxArray *c2_input2, const mxArray *c2_input3, const
  mxArray *c2_input4)
{
  const mxArray *c2_ = NULL;
  (void)chartInstance;
  c2_ = NULL;
  sf_mex_assign(&c2_, sf_mex_call(c2_sp, NULL, "feval", 1U, 5U, 14, sf_mex_dup
    (c2_input0), 14, sf_mex_dup(c2_input1), 14, sf_mex_dup(c2_input2), 14,
    sf_mex_dup(c2_input3), 14, sf_mex_dup(c2_input4)), false);
  sf_mex_destroy(&c2_input0);
  sf_mex_destroy(&c2_input1);
  sf_mex_destroy(&c2_input2);
  sf_mex_destroy(&c2_input3);
  sf_mex_destroy(&c2_input4);
  return c2_;
}

static const mxArray *c2_b_feval(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, const mxArray *c2_input0, const
  mxArray *c2_input1, const mxArray *c2_input2, const mxArray *c2_input3, const
  mxArray *c2_input4)
{
  const mxArray *c2_ = NULL;
  (void)chartInstance;
  c2_ = NULL;
  sf_mex_assign(&c2_, sf_mex_call(c2_sp, NULL, "feval", 1U, 5U, 14, sf_mex_dup
    (c2_input0), 14, sf_mex_dup(c2_input1), 14, sf_mex_dup(c2_input2), 14,
    sf_mex_dup(c2_input3), 14, sf_mex_dup(c2_input4)), false);
  sf_mex_destroy(&c2_input0);
  sf_mex_destroy(&c2_input1);
  sf_mex_destroy(&c2_input2);
  sf_mex_destroy(&c2_input3);
  sf_mex_destroy(&c2_input4);
  return c2_;
}

static const mxArray *c2_c_feval(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, const mxArray *c2_input0, const
  mxArray *c2_input1, const mxArray *c2_input2, const mxArray *c2_input3, const
  mxArray *c2_input4)
{
  const mxArray *c2_ = NULL;
  (void)chartInstance;
  c2_ = NULL;
  sf_mex_assign(&c2_, sf_mex_call(c2_sp, NULL, "feval", 1U, 5U, 14, sf_mex_dup
    (c2_input0), 14, sf_mex_dup(c2_input1), 14, sf_mex_dup(c2_input2), 14,
    sf_mex_dup(c2_input3), 14, sf_mex_dup(c2_input4)), false);
  sf_mex_destroy(&c2_input0);
  sf_mex_destroy(&c2_input1);
  sf_mex_destroy(&c2_input2);
  sf_mex_destroy(&c2_input3);
  sf_mex_destroy(&c2_input4);
  return c2_;
}

static const mxArray *c2_d_feval(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, const mxArray *c2_input0, const
  mxArray *c2_input1, const mxArray *c2_input2, const mxArray *c2_input3, const
  mxArray *c2_input4)
{
  const mxArray *c2_ = NULL;
  (void)chartInstance;
  c2_ = NULL;
  sf_mex_assign(&c2_, sf_mex_call(c2_sp, NULL, "feval", 1U, 5U, 14, sf_mex_dup
    (c2_input0), 14, sf_mex_dup(c2_input1), 14, sf_mex_dup(c2_input2), 14,
    sf_mex_dup(c2_input3), 14, sf_mex_dup(c2_input4)), false);
  sf_mex_destroy(&c2_input0);
  sf_mex_destroy(&c2_input1);
  sf_mex_destroy(&c2_input2);
  sf_mex_destroy(&c2_input3);
  sf_mex_destroy(&c2_input4);
  return c2_;
}

static const mxArray *c2_e_feval(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, const mxArray *c2_input0, const
  mxArray *c2_input1, const mxArray *c2_input2, const mxArray *c2_input3, const
  mxArray *c2_input4)
{
  const mxArray *c2_ = NULL;
  (void)chartInstance;
  c2_ = NULL;
  sf_mex_assign(&c2_, sf_mex_call(c2_sp, NULL, "feval", 1U, 5U, 14, sf_mex_dup
    (c2_input0), 14, sf_mex_dup(c2_input1), 14, sf_mex_dup(c2_input2), 14,
    sf_mex_dup(c2_input3), 14, sf_mex_dup(c2_input4)), false);
  sf_mex_destroy(&c2_input0);
  sf_mex_destroy(&c2_input1);
  sf_mex_destroy(&c2_input2);
  sf_mex_destroy(&c2_input3);
  sf_mex_destroy(&c2_input4);
  return c2_;
}

static real_T c2_b_applyOperators(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_fuzzifiedInputs_data[],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, real_T c2_varargin_1_data[], real_T
  c2_varargin_2_data[])
{
  static char_T c2_b_cv[7] = { 'f', 'p', 'r', 'i', 'n', 't', 'f' };

  static char_T c2_b_varargin_1[3] = { 'A', 'N', 'D' };

  static uint8_T c2_uv[3] = { 109U, 105U, 110U };

  emlrtStack c2_b_st;
  emlrtStack c2_c_st;
  emlrtStack c2_d_st;
  emlrtStack c2_st;
  const mxArray *c2_b_y = NULL;
  const mxArray *c2_c_y = NULL;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_e_y = NULL;
  const mxArray *c2_f_y = NULL;
  real_T c2_x_data[2];
  real_T c2_b_k;
  real_T c2_b_x;
  real_T c2_sumAntecedentOutputs;
  real_T c2_u;
  real_T c2_x;
  real_T c2_y;
  int32_T c2_b_inputID;
  int32_T c2_b_ruleID;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_inputID;
  int32_T c2_k;
  int32_T c2_ruleID;
  char_T c2_varargin_1[3];
  uint8_T c2_andMethod[3];
  uint8_T c2_x1;
  uint8_T c2_x2;
  boolean_T c2_b;
  boolean_T c2_b_b;
  boolean_T c2_b_p;
  boolean_T c2_c_p;
  boolean_T c2_exitg1;
  boolean_T c2_p;
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_c_st.prev = &c2_b_st;
  c2_c_st.tls = c2_b_st.tls;
  c2_d_st.prev = &c2_c_st;
  c2_d_st.tls = c2_c_st.tls;
  c2_sumAntecedentOutputs = 0.0;
  for (c2_ruleID = 0; c2_ruleID < 24; c2_ruleID++) {
    c2_b_ruleID = c2_ruleID;
    for (c2_inputID = 0; c2_inputID < 2; c2_inputID++) {
      c2_b_inputID = c2_inputID;
      c2_varargin_2_data[c2_b_inputID] = c2_fuzzifiedInputs_data[c2_b_ruleID +
        24 * c2_b_inputID];
    }

    c2_st.site = &c2_bd_emlrtRSI;
    for (c2_i = 0; c2_i < 3; c2_i++) {
      c2_andMethod[c2_i] = c2_fis->andMethod[c2_i];
    }

    for (c2_i1 = 0; c2_i1 < 2; c2_i1++) {
      c2_x_data[c2_i1] = c2_varargin_2_data[c2_i1];
    }

    c2_y = -1.0;
    c2_p = false;
    c2_b_p = true;
    c2_k = 0;
    c2_exitg1 = false;
    while ((!c2_exitg1) && (c2_k < 3)) {
      c2_b_k = (real_T)c2_k + 1.0;
      c2_x1 = c2_andMethod[(int32_T)c2_b_k - 1];
      c2_x2 = c2_uv[(int32_T)c2_b_k - 1];
      c2_c_p = (c2_x1 == c2_x2);
      if (!c2_c_p) {
        c2_b_p = false;
        c2_exitg1 = true;
      } else {
        c2_k++;
      }
    }

    if (c2_b_p) {
      c2_p = true;
    }

    if (c2_p) {
      c2_b_st.site = &c2_dd_emlrtRSI;
      c2_c_st.site = &c2_fd_emlrtRSI;
      c2_d_st.site = &c2_gd_emlrtRSI;
      if (c2_x_data[0] > c2_x_data[1]) {
        c2_y = c2_x_data[1];
      } else {
        c2_x = c2_x_data[0];
        c2_b = muDoubleScalarIsNaN(c2_x);
        if (c2_b) {
          c2_b_x = c2_x_data[1];
          c2_b_b = muDoubleScalarIsNaN(c2_b_x);
          if (!c2_b_b) {
            c2_y = c2_x_data[1];
          } else {
            c2_y = c2_x_data[0];
          }
        } else {
          c2_y = c2_x_data[0];
        }
      }
    } else {
      c2_b_st.site = &c2_ed_emlrtRSI;
      for (c2_i2 = 0; c2_i2 < 3; c2_i2++) {
        c2_varargin_1[c2_i2] = (char_T)(int8_T)c2_andMethod[c2_i2];
      }

      c2_c_st.site = &c2_xc_emlrtRSI;
      c2_b_y = NULL;
      sf_mex_assign(&c2_b_y, sf_mex_create("y", c2_b_cv, 10, 0U, 1U, 0U, 2, 1, 7),
                    false);
      c2_u = 1.0;
      c2_c_y = NULL;
      sf_mex_assign(&c2_c_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0), false);
      c2_d_y = NULL;
      sf_mex_assign(&c2_d_y, sf_mex_create("y", c2_cv2, 10, 0U, 1U, 0U, 2, 1, 91),
                    false);
      c2_e_y = NULL;
      sf_mex_assign(&c2_e_y, sf_mex_create("y", c2_b_varargin_1, 10, 0U, 1U, 0U,
        2, 1, 3), false);
      c2_f_y = NULL;
      sf_mex_assign(&c2_f_y, sf_mex_create("y", c2_varargin_1, 10, 0U, 1U, 0U, 2,
        1, 3), false);
      c2_d_st.site = &c2_yc_emlrtRSI;
      c2_emlrt_marshallIn(chartInstance, c2_b_feval(chartInstance, &c2_d_st,
        c2_b_y, c2_c_y, c2_d_y, c2_e_y, c2_f_y), "<output of feval>");
      c2_b_st.site = &c2_cd_emlrtRSI;
      exit(0);
    }

    c2_varargin_1_data[c2_b_ruleID] = c2_y;
    c2_sumAntecedentOutputs += c2_varargin_1_data[c2_b_ruleID];
  }

  return c2_sumAntecedentOutputs;
}

static void c2_b_fuzzifyInputs(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, real_T c2_inputs[2],
  c2_s_9DL33rUTgryGqqXf4f6A1E *c2_fis, c2_cell_wrap_0 c2_varargin_1[2],
  c2_emxArray_real_T *c2_varargin_2, real_T c2_varargin_3_data[],
  c2_emxArray_real_T *c2_inputMFCache)
{
  static char_T c2_b_cv[7] = { 'f', 'p', 'r', 'i', 'n', 't', 'f' };

  static uint8_T c2_uv1[5] = { 116U, 114U, 105U, 109U, 102U };

  static uint8_T c2_uv3[5] = { 115U, 105U, 103U, 109U, 102U };

  static uint8_T c2_uv9[4] = { 112U, 105U, 109U, 102U };

  static uint8_T c2_uv5[3] = { 115U, 109U, 102U };

  static uint8_T c2_uv7[3] = { 122U, 109U, 102U };

  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 c2_r;
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 c2_r1;
  emlrtStack c2_b_st;
  emlrtStack c2_c_st;
  emlrtStack c2_d_st;
  emlrtStack c2_e_st;
  emlrtStack c2_st;
  const mxArray *c2_d_y = NULL;
  const mxArray *c2_e_y = NULL;
  const mxArray *c2_f_y = NULL;
  const mxArray *c2_g_y = NULL;
  const mxArray *c2_h_y = NULL;
  const mxArray *c2_i_y = NULL;
  const mxArray *c2_j_y = NULL;
  const mxArray *c2_k_y = NULL;
  const mxArray *c2_l_y = NULL;
  const mxArray *c2_m_y = NULL;
  const mxArray *c2_n_y = NULL;
  const mxArray *c2_o_y = NULL;
  const mxArray *c2_p_y = NULL;
  real_T c2_b_params_data[3];
  real_T c2_params_data[3];
  real_T c2_b_params[2];
  real_T c2_a;
  real_T c2_b;
  real_T c2_b_a;
  real_T c2_b_c;
  real_T c2_b_value;
  real_T c2_b_x;
  real_T c2_b_x0;
  real_T c2_b_x1;
  real_T c2_c;
  real_T c2_c_value;
  real_T c2_c_x;
  real_T c2_c_x0;
  real_T c2_c_x1;
  real_T c2_c_y;
  real_T c2_d;
  real_T c2_d_value;
  real_T c2_d_x0;
  real_T c2_d_x1;
  real_T c2_g_x;
  real_T c2_h_x;
  real_T c2_i_x;
  real_T c2_j_x;
  real_T c2_k_x;
  real_T c2_l_x;
  real_T c2_m_x;
  real_T c2_n_x;
  real_T c2_o_x;
  real_T c2_p_x;
  real_T c2_q_x;
  real_T c2_q_y;
  real_T c2_r_x;
  real_T c2_r_y;
  real_T c2_s_x;
  real_T c2_t_x;
  real_T c2_u;
  real_T c2_u_x;
  real_T c2_value;
  real_T c2_x;
  real_T c2_x0;
  real_T c2_x1;
  real_T c2_y;
  int32_T c2_b_mfType_size[2];
  int32_T c2_b_params_size[2];
  int32_T c2_c_mfType_size[2];
  int32_T c2_c_params_size[2];
  int32_T c2_d_mfType_size[2];
  int32_T c2_e_mfType_size[2];
  int32_T c2_f_mfType_size[2];
  int32_T c2_g_mfType_size[2];
  int32_T c2_h_mfType_size[2];
  int32_T c2_i_mfType_size[2];
  int32_T c2_j_mfType_size[2];
  int32_T c2_k_mfType_size[2];
  int32_T c2_mfType_size[2];
  int32_T c2_params_size[2];
  int32_T c2_b_inputID;
  int32_T c2_b_loop_ub;
  int32_T c2_b_mfID;
  int32_T c2_b_q0;
  int32_T c2_b_q1;
  int32_T c2_b_qY;
  int32_T c2_b_ruleID;
  int32_T c2_b_y;
  int32_T c2_c_inputID;
  int32_T c2_c_loop_ub;
  int32_T c2_c_params;
  int32_T c2_d_inputID;
  int32_T c2_d_loop_ub;
  int32_T c2_d_x;
  int32_T c2_e_loop_ub;
  int32_T c2_e_x;
  int32_T c2_f_loop_ub;
  int32_T c2_f_x;
  int32_T c2_g_loop_ub;
  int32_T c2_h_loop_ub;
  int32_T c2_i;
  int32_T c2_i1;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i19;
  int32_T c2_i2;
  int32_T c2_i20;
  int32_T c2_i21;
  int32_T c2_i22;
  int32_T c2_i23;
  int32_T c2_i24;
  int32_T c2_i25;
  int32_T c2_i26;
  int32_T c2_i27;
  int32_T c2_i28;
  int32_T c2_i29;
  int32_T c2_i3;
  int32_T c2_i30;
  int32_T c2_i31;
  int32_T c2_i32;
  int32_T c2_i33;
  int32_T c2_i34;
  int32_T c2_i35;
  int32_T c2_i36;
  int32_T c2_i37;
  int32_T c2_i38;
  int32_T c2_i39;
  int32_T c2_i4;
  int32_T c2_i40;
  int32_T c2_i41;
  int32_T c2_i42;
  int32_T c2_i43;
  int32_T c2_i44;
  int32_T c2_i45;
  int32_T c2_i46;
  int32_T c2_i47;
  int32_T c2_i48;
  int32_T c2_i49;
  int32_T c2_i5;
  int32_T c2_i50;
  int32_T c2_i51;
  int32_T c2_i52;
  int32_T c2_i53;
  int32_T c2_i54;
  int32_T c2_i55;
  int32_T c2_i56;
  int32_T c2_i6;
  int32_T c2_i7;
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_i_loop_ub;
  int32_T c2_inputID;
  int32_T c2_j_loop_ub;
  int32_T c2_k_loop_ub;
  int32_T c2_loop_ub;
  int32_T c2_mfID;
  int32_T c2_mfIndex;
  int32_T c2_params;
  int32_T c2_q0;
  int32_T c2_q1;
  int32_T c2_qY;
  int32_T c2_ruleID;
  char_T c2_b_mfType_data[5];
  char_T c2_c_mfType_data[5];
  char_T c2_d_mfType_data[5];
  char_T c2_e_mfType_data[5];
  char_T c2_f_mfType_data[5];
  char_T c2_mfType_data[5];
  uint8_T c2_uv[5];
  uint8_T c2_uv2[5];
  uint8_T c2_uv8[4];
  uint8_T c2_uv4[3];
  uint8_T c2_uv6[3];
  c2_st.prev = c2_sp;
  c2_st.tls = c2_sp->tls;
  c2_b_st.prev = &c2_st;
  c2_b_st.tls = c2_st.tls;
  c2_c_st.prev = &c2_b_st;
  c2_c_st.tls = c2_b_st.tls;
  c2_d_st.prev = &c2_c_st;
  c2_d_st.tls = c2_c_st.tls;
  c2_e_st.prev = &c2_d_st;
  c2_e_st.tls = c2_d_st.tls;
  c2_st.site = &c2_ie_emlrtRSI;
  c2_i = c2_inputMFCache->size[0] * c2_inputMFCache->size[1];
  c2_inputMFCache->size[0] = 1;
  c2_inputMFCache->size[1] = c2_varargin_2->size[1];
  c2_emxEnsureCapacity_real_T(chartInstance, &c2_st, c2_inputMFCache, c2_i,
    &c2_of_emlrtRTEI);
  c2_loop_ub = c2_varargin_2->size[0] * c2_varargin_2->size[1] - 1;
  for (c2_i1 = 0; c2_i1 <= c2_loop_ub; c2_i1++) {
    c2_inputMFCache->data[c2_i1] = c2_varargin_2->data[c2_i1];
  }

  for (c2_inputID = 0; c2_inputID < 2; c2_inputID++) {
    c2_b_inputID = c2_inputID;
    for (c2_mfID = 0; c2_mfID < 5; c2_mfID++) {
      c2_b_mfID = c2_mfID;
      c2_r.size[1] = c2_varargin_1[c2_b_inputID].f1.size[1];
      c2_b_loop_ub = c2_varargin_1[c2_b_inputID].f1.size[0] *
        c2_varargin_1[c2_b_inputID].f1.size[1] - 1;
      for (c2_i4 = 0; c2_i4 <= c2_b_loop_ub; c2_i4++) {
        c2_r.data[c2_i4] = c2_varargin_1[c2_b_inputID].f1.data[c2_i4];
      }

      c2_r1.size[1] = c2_varargin_1[c2_b_inputID].f1.size[1];
      c2_c_loop_ub = c2_varargin_1[c2_b_inputID].f1.size[0] *
        c2_varargin_1[c2_b_inputID].f1.size[1] - 1;
      for (c2_i5 = 0; c2_i5 <= c2_c_loop_ub; c2_i5++) {
        c2_r1.data[c2_i5] = c2_varargin_1[c2_b_inputID].f1.data[c2_i5];
      }

      c2_b_st.site = &c2_je_emlrtRSI;
      c2_mfType_size[0] = 1;
      c2_i6 = c2_r.size[1] - 1;
      if ((c2_b_mfID < 0) || (c2_b_mfID > c2_i6)) {
        emlrtDynamicBoundsCheckR2012b(c2_b_mfID, 0, c2_i6, &c2_vd_emlrtBCI,
          &c2_b_st);
      }

      c2_i8 = c2_b_mfID;
      c2_mfType_size[1] = c2_r.data[c2_i8].type.size[1];
      c2_i9 = c2_r.size[1] - 1;
      if ((c2_b_mfID < 0) || (c2_b_mfID > c2_i9)) {
        emlrtDynamicBoundsCheckR2012b(c2_b_mfID, 0, c2_i9, &c2_vd_emlrtBCI,
          &c2_b_st);
      }

      c2_i10 = c2_b_mfID;
      c2_i11 = c2_r.size[1] - 1;
      if ((c2_b_mfID < 0) || (c2_b_mfID > c2_i11)) {
        emlrtDynamicBoundsCheckR2012b(c2_b_mfID, 0, c2_i11, &c2_vd_emlrtBCI,
          &c2_b_st);
      }

      c2_i13 = c2_b_mfID;
      c2_d_loop_ub = c2_r.data[c2_i10].type.size[0] * c2_r.data[c2_i13].
        type.size[1] - 1;
      for (c2_i14 = 0; c2_i14 <= c2_d_loop_ub; c2_i14++) {
        c2_i15 = c2_r.size[1] - 1;
        if ((c2_b_mfID < 0) || (c2_b_mfID > c2_i15)) {
          emlrtDynamicBoundsCheckR2012b(c2_b_mfID, 0, c2_i15, &c2_ae_emlrtBCI,
            &c2_b_st);
        }

        c2_mfType_data[c2_i14] = c2_r.data[c2_b_mfID].type.data[c2_i14];
      }

      c2_g_x = c2_inputs[c2_b_inputID];
      c2_params_size[0] = 1;
      c2_i17 = c2_r1.size[1] - 1;
      if ((c2_b_mfID < 0) || (c2_b_mfID > c2_i17)) {
        emlrtDynamicBoundsCheckR2012b(c2_b_mfID, 0, c2_i17, &c2_wd_emlrtBCI,
          &c2_b_st);
      }

      c2_i18 = c2_b_mfID;
      c2_params_size[1] = c2_r1.data[c2_i18].params.size[1];
      c2_i19 = c2_r1.size[1] - 1;
      if ((c2_b_mfID < 0) || (c2_b_mfID > c2_i19)) {
        emlrtDynamicBoundsCheckR2012b(c2_b_mfID, 0, c2_i19, &c2_wd_emlrtBCI,
          &c2_b_st);
      }

      c2_i20 = c2_b_mfID;
      c2_i21 = c2_r1.size[1] - 1;
      if ((c2_b_mfID < 0) || (c2_b_mfID > c2_i21)) {
        emlrtDynamicBoundsCheckR2012b(c2_b_mfID, 0, c2_i21, &c2_wd_emlrtBCI,
          &c2_b_st);
      }

      c2_i22 = c2_b_mfID;
      c2_e_loop_ub = c2_r1.data[c2_i20].params.size[0] * c2_r1.data[c2_i22].
        params.size[1] - 1;
      for (c2_i23 = 0; c2_i23 <= c2_e_loop_ub; c2_i23++) {
        c2_i24 = c2_r1.size[1] - 1;
        if ((c2_b_mfID < 0) || (c2_b_mfID > c2_i24)) {
          emlrtDynamicBoundsCheckR2012b(c2_b_mfID, 0, c2_i24, &c2_be_emlrtBCI,
            &c2_b_st);
        }

        c2_params_data[c2_i23] = c2_r1.data[c2_b_mfID].params.data[c2_i23];
      }

      c2_c_y = -1.0;
      c2_b_mfType_size[0] = 1;
      c2_b_mfType_size[1] = c2_mfType_size[1];
      c2_f_loop_ub = c2_mfType_size[0] * c2_mfType_size[1] - 1;
      for (c2_i25 = 0; c2_i25 <= c2_f_loop_ub; c2_i25++) {
        c2_b_mfType_data[c2_i25] = c2_mfType_data[c2_i25];
      }

      for (c2_i26 = 0; c2_i26 < 2; c2_i26++) {
        c2_c_mfType_size[c2_i26] = c2_b_mfType_size[c2_i26];
      }

      for (c2_i27 = 0; c2_i27 < 5; c2_i27++) {
        c2_uv[c2_i27] = c2_uv1[c2_i27];
      }

      if (c2_isequal(chartInstance, c2_b_mfType_data, c2_c_mfType_size, c2_uv))
      {
        c2_c_st.site = &c2_kb_emlrtRSI;
        c2_h_x = c2_g_x;
        c2_b_params_size[0] = 1;
        c2_b_params_size[1] = c2_params_size[1];
        c2_h_loop_ub = c2_params_size[0] * c2_params_size[1] - 1;
        for (c2_i30 = 0; c2_i30 <= c2_h_loop_ub; c2_i30++) {
          c2_b_params_data[c2_i30] = c2_params_data[c2_i30];
        }

        c2_d_st.site = &c2_mb_emlrtRSI;
        for (c2_i32 = 0; c2_i32 < 2; c2_i32++) {
          c2_c_params_size[c2_i32] = c2_b_params_size[c2_i32];
        }

        c2_validateTriMFParameterValues(chartInstance, &c2_d_st,
          c2_b_params_data, c2_c_params_size);
        c2_d_st.site = &c2_nb_emlrtRSI;
        c2_j_x = c2_h_x;
        c2_i34 = 1;
        if ((c2_i34 < 1) || (c2_i34 > c2_params_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i34, 1, c2_params_size[1],
            &c2_fb_emlrtBCI, &c2_d_st);
        }

        c2_a = c2_params_data[0];
        c2_i38 = 2;
        if ((c2_i38 < 1) || (c2_i38 > c2_params_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i38, 1, c2_params_size[1],
            &c2_gb_emlrtBCI, &c2_d_st);
        }

        c2_b = c2_params_data[1];
        c2_i40 = 3;
        if ((c2_i40 < 1) || (c2_i40 > c2_params_size[1])) {
          emlrtDynamicBoundsCheckR2012b(c2_i40, 1, c2_params_size[1],
            &c2_hb_emlrtBCI, &c2_d_st);
        }

        c2_b_c = c2_params_data[2];
        c2_c_y = 0.0;
        if ((c2_a != c2_b) && (c2_a < c2_j_x) && (c2_j_x < c2_b)) {
          c2_c_y = (c2_j_x - c2_a) * (1.0 / (c2_b - c2_a));
        }

        if ((c2_b != c2_b_c) && (c2_b < c2_j_x) && (c2_j_x < c2_b_c)) {
          c2_c_y = (c2_b_c - c2_j_x) * (1.0 / (c2_b_c - c2_b));
        }

        if (c2_j_x == c2_b) {
          c2_c_y = 1.0;
        }
      } else {
        c2_d_mfType_size[0] = 1;
        c2_d_mfType_size[1] = c2_mfType_size[1];
        c2_g_loop_ub = c2_mfType_size[0] * c2_mfType_size[1] - 1;
        for (c2_i28 = 0; c2_i28 <= c2_g_loop_ub; c2_i28++) {
          c2_c_mfType_data[c2_i28] = c2_mfType_data[c2_i28];
        }

        for (c2_i29 = 0; c2_i29 < 2; c2_i29++) {
          c2_e_mfType_size[c2_i29] = c2_d_mfType_size[c2_i29];
        }

        for (c2_i31 = 0; c2_i31 < 5; c2_i31++) {
          c2_uv2[c2_i31] = c2_uv3[c2_i31];
        }

        if (c2_isequal(chartInstance, c2_c_mfType_data, c2_e_mfType_size, c2_uv2))
        {
          c2_c_st.site = &c2_jb_emlrtRSI;
          c2_i_x = c2_g_x;
          c2_d_st.site = &c2_gc_emlrtRSI;
          if ((real_T)c2_params_size[1] < 2.0) {
            c2_d_y = NULL;
            sf_mex_assign(&c2_d_y, sf_mex_create("y", c2_cv1, 10, 0U, 1U, 0U, 2,
              1, 41), false);
            c2_e_y = NULL;
            sf_mex_assign(&c2_e_y, sf_mex_create("y", c2_cv1, 10, 0U, 1U, 0U, 2,
              1, 41), false);
            sf_mex_call(&c2_d_st, &c2_o_emlrtMCI, "error", 0U, 2U, 14, c2_d_y,
                        14, sf_mex_call(&c2_d_st, NULL, "getString", 1U, 1U, 14,
              sf_mex_call(&c2_d_st, NULL, "message", 1U, 1U, 14, c2_e_y)));
          }

          c2_i36 = 1;
          if ((c2_i36 < 1) || (c2_i36 > c2_params_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i36, 1, c2_params_size[1],
              &c2_db_emlrtBCI, &c2_c_st);
          }

          c2_b_a = c2_params_data[0];
          c2_i39 = 2;
          if ((c2_i39 < 1) || (c2_i39 > c2_params_size[1])) {
            emlrtDynamicBoundsCheckR2012b(c2_i39, 1, c2_params_size[1],
              &c2_eb_emlrtBCI, &c2_c_st);
          }

          c2_c = c2_params_data[1];
          c2_l_x = -c2_b_a * (c2_i_x - c2_c);
          c2_m_x = c2_l_x;
          c2_m_x = muDoubleScalarExp(c2_m_x);
          c2_c_y = 1.0 / (1.0 + c2_m_x);
        } else {
          c2_f_mfType_size[0] = 1;
          c2_f_mfType_size[1] = c2_mfType_size[1];
          c2_i_loop_ub = c2_mfType_size[0] * c2_mfType_size[1] - 1;
          for (c2_i33 = 0; c2_i33 <= c2_i_loop_ub; c2_i33++) {
            c2_d_mfType_data[c2_i33] = c2_mfType_data[c2_i33];
          }

          for (c2_i35 = 0; c2_i35 < 2; c2_i35++) {
            c2_g_mfType_size[c2_i35] = c2_f_mfType_size[c2_i35];
          }

          for (c2_i37 = 0; c2_i37 < 3; c2_i37++) {
            c2_uv4[c2_i37] = c2_uv5[c2_i37];
          }

          if (c2_b_isequal(chartInstance, c2_d_mfType_data, c2_g_mfType_size,
                           c2_uv4)) {
            c2_c_st.site = &c2_ib_emlrtRSI;
            c2_k_x = c2_g_x;
            c2_d_st.site = &c2_kc_emlrtRSI;
            if ((real_T)c2_params_size[1] < 2.0) {
              c2_f_y = NULL;
              sf_mex_assign(&c2_f_y, sf_mex_create("y", c2_cv4, 10, 0U, 1U, 0U,
                2, 1, 39), false);
              c2_g_y = NULL;
              sf_mex_assign(&c2_g_y, sf_mex_create("y", c2_cv4, 10, 0U, 1U, 0U,
                2, 1, 39), false);
              sf_mex_call(&c2_d_st, &c2_p_emlrtMCI, "error", 0U, 2U, 14, c2_f_y,
                          14, sf_mex_call(&c2_d_st, NULL, "getString", 1U, 1U,
                14, sf_mex_call(&c2_d_st, NULL, "message", 1U, 1U, 14, c2_g_y)));
            }

            c2_d_st.site = &c2_lc_emlrtRSI;
            c2_n_x = c2_k_x;
            c2_i44 = 1;
            if ((c2_i44 < 1) || (c2_i44 > c2_params_size[1])) {
              emlrtDynamicBoundsCheckR2012b(c2_i44, 1, c2_params_size[1],
                &c2_wb_emlrtBCI, &c2_d_st);
            }

            c2_x0 = c2_params_data[0];
            c2_i46 = 2;
            if ((c2_i46 < 1) || (c2_i46 > c2_params_size[1])) {
              emlrtDynamicBoundsCheckR2012b(c2_i46, 1, c2_params_size[1],
                &c2_xb_emlrtBCI, &c2_d_st);
            }

            c2_x1 = c2_params_data[1];
            if (c2_x0 >= c2_x1) {
              c2_c_y = (real_T)(c2_n_x >= (c2_x0 + c2_x1) / 2.0);
            } else {
              c2_c_y = 0.0;
              if ((c2_x0 < c2_n_x) && (c2_n_x <= (c2_x0 + c2_x1) / 2.0)) {
                c2_value = (c2_n_x - c2_x0) * (1.0 / (c2_x1 - c2_x0));
                c2_c_y = 2.0 * c2_value * c2_value;
              }

              if (((c2_x0 + c2_x1) / 2.0 < c2_n_x) && (c2_n_x <= c2_x1)) {
                c2_value = (c2_x1 - c2_n_x) * (1.0 / (c2_x1 - c2_x0));
                c2_c_y = 1.0 - 2.0 * c2_value * c2_value;
              }

              if (c2_x1 <= c2_n_x) {
                c2_c_y = 1.0;
              }
            }
          } else {
            c2_h_mfType_size[0] = 1;
            c2_h_mfType_size[1] = c2_mfType_size[1];
            c2_j_loop_ub = c2_mfType_size[0] * c2_mfType_size[1] - 1;
            for (c2_i41 = 0; c2_i41 <= c2_j_loop_ub; c2_i41++) {
              c2_e_mfType_data[c2_i41] = c2_mfType_data[c2_i41];
            }

            for (c2_i42 = 0; c2_i42 < 2; c2_i42++) {
              c2_i_mfType_size[c2_i42] = c2_h_mfType_size[c2_i42];
            }

            for (c2_i43 = 0; c2_i43 < 3; c2_i43++) {
              c2_uv6[c2_i43] = c2_uv7[c2_i43];
            }

            if (c2_b_isequal(chartInstance, c2_e_mfType_data, c2_i_mfType_size,
                             c2_uv6)) {
              c2_c_st.site = &c2_hb_emlrtRSI;
              c2_o_x = c2_g_x;
              c2_d_st.site = &c2_mc_emlrtRSI;
              if ((real_T)c2_params_size[1] < 2.0) {
                c2_h_y = NULL;
                sf_mex_assign(&c2_h_y, sf_mex_create("y", c2_cv5, 10, 0U, 1U, 0U,
                  2, 1, 39), false);
                c2_i_y = NULL;
                sf_mex_assign(&c2_i_y, sf_mex_create("y", c2_cv5, 10, 0U, 1U, 0U,
                  2, 1, 39), false);
                sf_mex_call(&c2_d_st, &c2_q_emlrtMCI, "error", 0U, 2U, 14,
                            c2_h_y, 14, sf_mex_call(&c2_d_st, NULL, "getString",
                  1U, 1U, 14, sf_mex_call(&c2_d_st, NULL, "message", 1U, 1U, 14,
                  c2_i_y)));
              }

              c2_d_st.site = &c2_nc_emlrtRSI;
              c2_p_x = c2_o_x;
              c2_i51 = 1;
              if ((c2_i51 < 1) || (c2_i51 > c2_params_size[1])) {
                emlrtDynamicBoundsCheckR2012b(c2_i51, 1, c2_params_size[1],
                  &c2_jc_emlrtBCI, &c2_d_st);
              }

              c2_b_x1 = c2_params_data[0];
              c2_i52 = 2;
              if ((c2_i52 < 1) || (c2_i52 > c2_params_size[1])) {
                emlrtDynamicBoundsCheckR2012b(c2_i52, 1, c2_params_size[1],
                  &c2_kc_emlrtBCI, &c2_d_st);
              }

              c2_b_x0 = c2_params_data[1];
              if (c2_b_x1 >= c2_b_x0) {
                c2_c_y = (real_T)(c2_p_x <= (c2_b_x0 + c2_b_x1) / 2.0);
              } else {
                c2_c_y = 0.0;
                if (c2_p_x <= c2_b_x1) {
                  c2_c_y = 1.0;
                }

                if ((c2_b_x1 < c2_p_x) && (c2_p_x <= (c2_b_x1 + c2_b_x0) / 2.0))
                {
                  c2_b_value = (c2_p_x - c2_b_x1) * (1.0 / (c2_b_x1 - c2_b_x0));
                  c2_c_y = 1.0 - 2.0 * c2_b_value * c2_b_value;
                }

                if (((c2_b_x1 + c2_b_x0) / 2.0 < c2_p_x) && (c2_p_x <= c2_b_x0))
                {
                  c2_b_value = (c2_b_x0 - c2_p_x) * (1.0 / (c2_b_x1 - c2_b_x0));
                  c2_c_y = 2.0 * c2_b_value * c2_b_value;
                }

                if (c2_b_x0 <= c2_p_x) {
                  c2_c_y = 0.0;
                }
              }
            } else {
              c2_j_mfType_size[0] = 1;
              c2_j_mfType_size[1] = c2_mfType_size[1];
              c2_k_loop_ub = c2_mfType_size[0] * c2_mfType_size[1] - 1;
              for (c2_i47 = 0; c2_i47 <= c2_k_loop_ub; c2_i47++) {
                c2_f_mfType_data[c2_i47] = c2_mfType_data[c2_i47];
              }

              for (c2_i48 = 0; c2_i48 < 2; c2_i48++) {
                c2_k_mfType_size[c2_i48] = c2_j_mfType_size[c2_i48];
              }

              for (c2_i50 = 0; c2_i50 < 4; c2_i50++) {
                c2_uv8[c2_i50] = c2_uv9[c2_i50];
              }

              if (c2_c_isequal(chartInstance, c2_f_mfType_data, c2_k_mfType_size,
                               c2_uv8)) {
                c2_c_st.site = &c2_gb_emlrtRSI;
                c2_q_x = c2_g_x;
                c2_d_st.site = &c2_vc_emlrtRSI;
                c2_k_y = NULL;
                sf_mex_assign(&c2_k_y, sf_mex_create("y", c2_cv6, 10, 0U, 1U, 0U,
                  2, 1, 40), false);
                c2_m_y = NULL;
                sf_mex_assign(&c2_m_y, sf_mex_create("y", c2_cv6, 10, 0U, 1U, 0U,
                  2, 1, 40), false);
                sf_mex_call(&c2_d_st, &c2_v_emlrtMCI, "error", 0U, 2U, 14,
                            c2_k_y, 14, sf_mex_call(&c2_d_st, NULL, "getString",
                  1U, 1U, 14, sf_mex_call(&c2_d_st, NULL, "message", 1U, 1U, 14,
                  c2_m_y)));
                c2_r_x = c2_q_x;
                c2_params = c2_params_size[1];
                for (c2_i53 = 0; c2_i53 < 2; c2_i53++) {
                  c2_i54 = c2_i53 + 1;
                  if ((c2_i54 < 1) || (c2_i54 > c2_params)) {
                    emlrtDynamicBoundsCheckR2012b(c2_i54, 1, c2_params,
                      &c2_xc_emlrtBCI, &c2_c_st);
                  }

                  c2_b_params[c2_i53] = c2_params_data[c2_i54 - 1];
                }

                c2_s_x = c2_r_x;
                c2_c_x0 = c2_b_params[0];
                c2_c_x1 = c2_b_params[1];
                if (c2_c_x0 >= c2_c_x1) {
                  c2_q_y = (real_T)(c2_s_x >= (c2_c_x0 + c2_c_x1) / 2.0);
                } else {
                  c2_q_y = 0.0;
                  if ((c2_c_x0 < c2_s_x) && (c2_s_x <= (c2_c_x0 + c2_c_x1) / 2.0))
                  {
                    c2_c_value = (c2_s_x - c2_c_x0) * (1.0 / (c2_c_x1 - c2_c_x0));
                    c2_q_y = 2.0 * c2_c_value * c2_c_value;
                  }

                  if (((c2_c_x0 + c2_c_x1) / 2.0 < c2_s_x) && (c2_s_x <= c2_c_x1))
                  {
                    c2_c_value = (c2_c_x1 - c2_s_x) * (1.0 / (c2_c_x1 - c2_c_x0));
                    c2_q_y = 1.0 - 2.0 * c2_c_value * c2_c_value;
                  }

                  if (c2_c_x1 <= c2_s_x) {
                    c2_q_y = 1.0;
                  }
                }

                c2_t_x = c2_q_x;
                c2_c_params = c2_params_size[1];
                for (c2_i55 = 0; c2_i55 < 2; c2_i55++) {
                  c2_i56 = (int32_T)(3.0 + (real_T)c2_i55);
                  if ((c2_i56 < 1) || (c2_i56 > c2_c_params)) {
                    emlrtDynamicBoundsCheckR2012b(c2_i56, 1, c2_c_params,
                      &c2_yc_emlrtBCI, &c2_c_st);
                  }

                  c2_b_params[c2_i55] = c2_params_data[c2_i56 - 1];
                }

                c2_u_x = c2_t_x;
                c2_d_x1 = c2_b_params[0];
                c2_d_x0 = c2_b_params[1];
                if (c2_d_x1 >= c2_d_x0) {
                  c2_r_y = (real_T)(c2_u_x <= (c2_d_x0 + c2_d_x1) / 2.0);
                } else {
                  c2_r_y = 0.0;
                  if (c2_u_x <= c2_d_x1) {
                    c2_r_y = 1.0;
                  }

                  if ((c2_d_x1 < c2_u_x) && (c2_u_x <= (c2_d_x1 + c2_d_x0) / 2.0))
                  {
                    c2_d_value = (c2_u_x - c2_d_x1) * (1.0 / (c2_d_x1 - c2_d_x0));
                    c2_r_y = 1.0 - 2.0 * c2_d_value * c2_d_value;
                  }

                  if (((c2_d_x1 + c2_d_x0) / 2.0 < c2_u_x) && (c2_u_x <= c2_d_x0))
                  {
                    c2_d_value = (c2_d_x0 - c2_u_x) * (1.0 / (c2_d_x1 - c2_d_x0));
                    c2_r_y = 2.0 * c2_d_value * c2_d_value;
                  }

                  if (c2_d_x0 <= c2_u_x) {
                    c2_r_y = 0.0;
                  }
                }

                c2_c_y = c2_q_y * c2_r_y;
              } else {
                c2_c_st.site = &c2_fb_emlrtRSI;
                c2_d_st.site = &c2_xc_emlrtRSI;
                c2_j_y = NULL;
                sf_mex_assign(&c2_j_y, sf_mex_create("y", c2_b_cv, 10, 0U, 1U,
                  0U, 2, 1, 7), false);
                c2_u = 1.0;
                c2_l_y = NULL;
                sf_mex_assign(&c2_l_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U,
                  0), false);
                c2_n_y = NULL;
                sf_mex_assign(&c2_n_y, sf_mex_create("y", c2_cv2, 10, 0U, 1U, 0U,
                  2, 1, 91), false);
                c2_o_y = NULL;
                sf_mex_assign(&c2_o_y, sf_mex_create("y", c2_cv3, 10, 0U, 1U, 0U,
                  2, 1, 10), false);
                c2_p_y = NULL;
                sf_mex_assign(&c2_p_y, sf_mex_create("y", &c2_mfType_data, 10,
                  0U, 1U, 0U, 2, c2_mfType_size[0], c2_mfType_size[1]), false);
                c2_e_st.site = &c2_yc_emlrtRSI;
                c2_emlrt_marshallIn(chartInstance, c2_feval(chartInstance,
                  &c2_e_st, c2_j_y, c2_l_y, c2_n_y, c2_o_y, c2_p_y),
                                    "<output of feval>");
                c2_c_st.site = &c2_lb_emlrtRSI;
                exit(0);
              }
            }
          }
        }
      }

      c2_i45 = c2_inputMFCache->size[1];
      c2_b_q0 = c2_fis->numCumInputMFs[c2_b_inputID];
      c2_b_q1 = c2_b_mfID + 1;
      if ((c2_b_q0 < 0) && (c2_b_q1 < MIN_int32_T - c2_b_q0)) {
        c2_b_qY = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      } else if ((c2_b_q0 > 0) && (c2_b_q1 > MAX_int32_T - c2_b_q0)) {
        c2_b_qY = MAX_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      } else {
        c2_b_qY = c2_b_q0 + c2_b_q1;
      }

      c2_i49 = c2_b_qY;
      if ((c2_i49 < 1) || (c2_i49 > c2_i45)) {
        emlrtDynamicBoundsCheckR2012b(c2_i49, 1, c2_i45, &c2_yd_emlrtBCI, &c2_st);
      }

      c2_inputMFCache->data[c2_i49 - 1] = c2_c_y;
    }
  }

  c2_i2 = c2_varargin_2->size[1];
  c2_i3 = c2_inputMFCache->size[1];
  if (c2_i2 != c2_i3) {
    emlrtSubAssignSizeCheck1dR2017a(c2_i2, c2_i3, &c2_v_emlrtECI, (void *)c2_sp);
  }

  for (c2_ruleID = 0; c2_ruleID < 24; c2_ruleID++) {
    c2_b_ruleID = c2_ruleID;
    for (c2_c_inputID = 0; c2_c_inputID < 2; c2_c_inputID++) {
      c2_d_inputID = c2_c_inputID;
      c2_x = c2_fis->antecedent[c2_b_ruleID + 24 * c2_d_inputID];
      c2_b_x = c2_x;
      c2_c_x = c2_b_x;
      c2_y = c2_c_x;
      c2_d = muDoubleScalarRound(c2_y);
      if (c2_d < 2.147483648E+9) {
        if (c2_d >= -2.147483648E+9) {
          c2_i7 = (int32_T)c2_d;
        } else {
          c2_i7 = MIN_int32_T;
          sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
        }
      } else if (c2_d >= 2.147483648E+9) {
        c2_i7 = MAX_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      } else {
        c2_i7 = 0;
      }

      c2_mfIndex = c2_i7;
      c2_d_x = c2_fis->numCumInputMFs[c2_d_inputID];
      c2_e_x = c2_d_x;
      c2_f_x = c2_e_x;
      c2_b_y = c2_f_x;
      c2_i12 = c2_inputMFCache->size[1];
      c2_q0 = c2_b_y;
      c2_q1 = c2_mfIndex;
      if ((c2_q0 < 0) && (c2_q1 < MIN_int32_T - c2_q0)) {
        c2_qY = MIN_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      } else if ((c2_q0 > 0) && (c2_q1 > MAX_int32_T - c2_q0)) {
        c2_qY = MAX_int32_T;
        sf_data_saturate_error(chartInstance->S, 1U, 0, 0);
      } else {
        c2_qY = c2_q0 + c2_q1;
      }

      c2_i16 = c2_qY;
      if ((c2_i16 < 1) || (c2_i16 > c2_i12)) {
        emlrtDynamicBoundsCheckR2012b(c2_i16, 1, c2_i12, &c2_xd_emlrtBCI, (void *)
          c2_sp);
      }

      c2_varargin_3_data[c2_b_ruleID + 24 * c2_d_inputID] =
        c2_inputMFCache->data[c2_i16 - 1];
    }
  }
}

static void c2_emxInitStruct_s_o4k2e0vdltB60Wn
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_o4k2e0vdltB60WnSYJQFVC *c2_pStruct)
{
  (void)chartInstance;
  c2_pStruct->type.size[0] = 0;
  c2_pStruct->type.size[1] = 0;
  c2_pStruct->params.size[0] = 0;
  c2_pStruct->params.size[1] = 0;
}

static void c2_emxExpand_s_o4k2e0vdltB60WnSYJQ
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_o4k2e0vdltB60WnSYJQFVC c2_data[5], int32_T c2_fromIndex, int32_T
   c2_toIndex)
{
  int32_T c2_i;
  for (c2_i = c2_fromIndex; c2_i < c2_toIndex; c2_i++) {
    c2_emxInitStruct_s_o4k2e0vdltB60Wn(chartInstance, &c2_data[c2_i]);
  }
}

static void c2_emxInitStruct_s_8hQCdWJdSJhbjCf
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_8hQCdWJdSJhbjCfdgdfm1F *c2_pStruct)
{
  (void)chartInstance;
  c2_pStruct->type.size[0] = 0;
  c2_pStruct->type.size[1] = 0;
  c2_pStruct->params.size[0] = 0;
  c2_pStruct->params.size[1] = 0;
}

static void c2_emxExpand_s_8hQCdWJdSJhbjCfdgdf
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_8hQCdWJdSJhbjCfdgdfm1F c2_data[5], int32_T c2_fromIndex, int32_T
   c2_toIndex)
{
  int32_T c2_i;
  for (c2_i = c2_fromIndex; c2_i < c2_toIndex; c2_i++) {
    c2_emxInitStruct_s_8hQCdWJdSJhbjCf(chartInstance, &c2_data[c2_i]);
  }
}

static void c2_emxEnsureCapacity_real_T
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, c2_emxArray_real_T *c2_emxArray, int32_T c2_oldNumel, const
   emlrtRTEInfo *c2_srcLocation)
{
  int32_T c2_i;
  int32_T c2_newCapacity;
  int32_T c2_newNumel;
  void *c2_newData;
  (void)chartInstance;
  if (c2_oldNumel < 0) {
    c2_oldNumel = 0;
  }

  c2_newNumel = 1;
  for (c2_i = 0; c2_i < c2_emxArray->numDimensions; c2_i++) {
    c2_newNumel = (int32_T)emlrtSizeMulR2012b((size_t)(uint32_T)c2_newNumel,
      (size_t)(uint32_T)c2_emxArray->size[c2_i], c2_srcLocation, (void *)c2_sp);
  }

  if (c2_newNumel > c2_emxArray->allocatedSize) {
    c2_newCapacity = c2_emxArray->allocatedSize;
    if (c2_newCapacity < 16) {
      c2_newCapacity = 16;
    }

    while (c2_newCapacity < c2_newNumel) {
      if (c2_newCapacity > 1073741823) {
        c2_newCapacity = MAX_int32_T;
      } else {
        c2_newCapacity <<= 1;
      }
    }

    c2_newData = emlrtCallocMex((uint32_T)c2_newCapacity, sizeof(real_T));
    if (c2_newData == NULL) {
      emlrtHeapAllocationErrorR2012b(c2_srcLocation, (void *)c2_sp);
    }

    if (c2_emxArray->data != NULL) {
      memcpy(c2_newData, c2_emxArray->data, sizeof(real_T) * (uint32_T)
             c2_oldNumel);
      if (c2_emxArray->canFreeData) {
        emlrtFreeMex(c2_emxArray->data);
      }
    }

    c2_emxArray->data = (real_T *)c2_newData;
    c2_emxArray->allocatedSize = c2_newCapacity;
    c2_emxArray->canFreeData = true;
  }
}

static void c2_emxInitStruct_s_JbR9CE1JwmiHOtK
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_JbR9CE1JwmiHOtKI7rv0ED *c2_pStruct)
{
  (void)chartInstance;
  c2_pStruct->type.size[0] = 0;
  c2_pStruct->type.size[1] = 0;
  c2_pStruct->params.size[0] = 0;
  c2_pStruct->params.size[1] = 0;
}

static void c2_emxExpand_s_JbR9CE1JwmiHOtKI7rv
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance,
   c2_s_JbR9CE1JwmiHOtKI7rv0ED c2_data[5], int32_T c2_fromIndex, int32_T
   c2_toIndex)
{
  int32_T c2_i;
  for (c2_i = c2_fromIndex; c2_i < c2_toIndex; c2_i++) {
    c2_emxInitStruct_s_JbR9CE1JwmiHOtK(chartInstance, &c2_data[c2_i]);
  }
}

static void c2_emxInit_real_T(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_emxArray_real_T **c2_pEmxArray,
  int32_T c2_numDimensions, const emlrtRTEInfo *c2_srcLocation)
{
  c2_emxArray_real_T *c2_emxArray;
  int32_T c2_i;
  (void)chartInstance;
  *c2_pEmxArray = (c2_emxArray_real_T *)emlrtMallocMex(sizeof(c2_emxArray_real_T));
  if ((void *)*c2_pEmxArray == NULL) {
    emlrtHeapAllocationErrorR2012b(c2_srcLocation, (void *)c2_sp);
  }

  c2_emxArray = *c2_pEmxArray;
  c2_emxArray->data = (real_T *)NULL;
  c2_emxArray->numDimensions = c2_numDimensions;
  c2_emxArray->size = (int32_T *)emlrtMallocMex(sizeof(int32_T) * (uint32_T)
    c2_numDimensions);
  if ((void *)c2_emxArray->size == NULL) {
    emlrtHeapAllocationErrorR2012b(c2_srcLocation, (void *)c2_sp);
  }

  c2_emxArray->allocatedSize = 0;
  c2_emxArray->canFreeData = true;
  for (c2_i = 0; c2_i < c2_numDimensions; c2_i++) {
    c2_emxArray->size[c2_i] = 0;
  }
}

static void c2_emxFree_real_T(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, c2_emxArray_real_T **c2_pEmxArray)
{
  (void)chartInstance;
  if (*c2_pEmxArray != (c2_emxArray_real_T *)NULL) {
    if (((*c2_pEmxArray)->data != (real_T *)NULL) && (*c2_pEmxArray)
        ->canFreeData) {
      emlrtFreeMex((*c2_pEmxArray)->data);
    }

    emlrtFreeMex((*c2_pEmxArray)->size);
    emlrtFreeMex(*c2_pEmxArray);
    *c2_pEmxArray = (c2_emxArray_real_T *)NULL;
  }
}

static void c2_emxEnsureCapacity_real_T1
  (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance, const emlrtStack
   *c2_sp, c2_emxArray_real_T *c2_emxArray, int32_T c2_oldNumel, const
   emlrtRTEInfo *c2_srcLocation)
{
  int32_T c2_i;
  int32_T c2_newCapacity;
  int32_T c2_newNumel;
  void *c2_newData;
  (void)chartInstance;
  if (c2_oldNumel < 0) {
    c2_oldNumel = 0;
  }

  c2_newNumel = 1;
  for (c2_i = 0; c2_i < c2_emxArray->numDimensions; c2_i++) {
    c2_newNumel = (int32_T)emlrtSizeMulR2012b((size_t)(uint32_T)c2_newNumel,
      (size_t)(uint32_T)c2_emxArray->size[c2_i], c2_srcLocation, (void *)c2_sp);
  }

  if (c2_newNumel > c2_emxArray->allocatedSize) {
    c2_newCapacity = c2_emxArray->allocatedSize;
    if (c2_newCapacity < 16) {
      c2_newCapacity = 16;
    }

    while (c2_newCapacity < c2_newNumel) {
      if (c2_newCapacity > 1073741823) {
        c2_newCapacity = MAX_int32_T;
      } else {
        c2_newCapacity <<= 1;
      }
    }

    c2_newData = emlrtCallocMex((uint32_T)c2_newCapacity, sizeof(real_T));
    if (c2_newData == NULL) {
      emlrtHeapAllocationErrorR2012b(c2_srcLocation, (void *)c2_sp);
    }

    if (c2_emxArray->data != NULL) {
      memcpy(c2_newData, c2_emxArray->data, sizeof(real_T) * (uint32_T)
             c2_oldNumel);
      if (c2_emxArray->canFreeData) {
        emlrtFreeMex(c2_emxArray->data);
      }
    }

    c2_emxArray->data = (real_T *)c2_newData;
    c2_emxArray->allocatedSize = c2_newCapacity;
    c2_emxArray->canFreeData = true;
  }
}

static void c2_emxInit_real_T1(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, const emlrtStack *c2_sp, c2_emxArray_real_T **c2_pEmxArray,
  int32_T c2_numDimensions, const emlrtRTEInfo *c2_srcLocation)
{
  c2_emxArray_real_T *c2_emxArray;
  int32_T c2_i;
  (void)chartInstance;
  *c2_pEmxArray = (c2_emxArray_real_T *)emlrtMallocMex(sizeof(c2_emxArray_real_T));
  if ((void *)*c2_pEmxArray == NULL) {
    emlrtHeapAllocationErrorR2012b(c2_srcLocation, (void *)c2_sp);
  }

  c2_emxArray = *c2_pEmxArray;
  c2_emxArray->data = (real_T *)NULL;
  c2_emxArray->numDimensions = c2_numDimensions;
  c2_emxArray->size = (int32_T *)emlrtMallocMex(sizeof(int32_T) * (uint32_T)
    c2_numDimensions);
  if ((void *)c2_emxArray->size == NULL) {
    emlrtHeapAllocationErrorR2012b(c2_srcLocation, (void *)c2_sp);
  }

  c2_emxArray->allocatedSize = 0;
  c2_emxArray->canFreeData = true;
  for (c2_i = 0; c2_i < c2_numDimensions; c2_i++) {
    c2_emxArray->size[c2_i] = 0;
  }
}

static int32_T c2__s32_s64_(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance, int64_T c2_b, int32_T c2_EMLOvCount_src_loc, uint32_T
  c2_ssid_src_loc, int32_T c2_offset_src_loc, int32_T c2_length_src_loc)
{
  int32_T c2_a;
  (void)c2_EMLOvCount_src_loc;
  c2_a = (int32_T)c2_b;
  if ((int64_T)c2_a != c2_b) {
    sf_data_overflow_error(chartInstance->S, c2_ssid_src_loc, c2_offset_src_loc,
      c2_length_src_loc);
  }

  return c2_a;
}

static void init_dsm_address_info(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *
  chartInstance)
{
  chartInstance->c2_covrtInstance = (CovrtStateflowInstance *)
    sfrtGetCovrtInstance(chartInstance->S);
  chartInstance->c2_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c2_dP = (real_T *)ssGetInputPortSignal_wrapper(chartInstance->S,
    0);
  chartInstance->c2_D = (real_T *)ssGetOutputPortSignal_wrapper(chartInstance->S,
    1);
  chartInstance->c2_dV = (real_T *)ssGetInputPortSignal_wrapper(chartInstance->S,
    1);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c2_SimulinkSKRIPSIFIKS_FLC_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1775454493U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2828091477U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2498038255U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(3535037516U);
}

mxArray *sf_c2_SimulinkSKRIPSIFIKS_FLC_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c2_SimulinkSKRIPSIFIKS_FLC_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("late");
  mxArray *fallbackReason = mxCreateString("ir_function_calls");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("exit");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c2_SimulinkSKRIPSIFIKS_FLC_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c2_SimulinkSKRIPSIFIKS_FLC(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNpjYPT0ZQACPiA+wcbAAEQMHEDMxAABrFA+I5TNCBdngYsrAHFJZUEqSLy4KNkzBUjnJeaC+Ym"
    "lFZ55aflg8y0YEOazYTGfEcl8Tqg4BHywp0y/iANIvwGSfhYC+gWALBdouMDCh3z7BRwo049pPz"
    "b3s6G4H8J3iS8oSi2D6L/AgD9+GdHilwnJ3ByGTIYCqDscCPiDCc0fAjBPNHg7QGg/qoTHUI4X1"
    "8EULwz+kHhhCBxR8cKOFi8gflpmcXx+UtYgyS/u0HjxHiTxokAVd0QQiBcVtHgB8YHRkphcklmW"
    "Gp9sFB+cmVuak5mXHewd5BkQ7Onm6R0c7+bjjOxPAAQHOFo="
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c2_SimulinkSKRIPSIFIKS_FLC_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "s2PuLYHApxzm8JwTXCzOj1B";
}

static void sf_opaque_initialize_c2_SimulinkSKRIPSIFIKS_FLC(void
  *chartInstanceVar)
{
  initialize_params_c2_SimulinkSKRIPSIFIKS_FLC
    ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*) chartInstanceVar);
  initialize_c2_SimulinkSKRIPSIFIKS_FLC
    ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c2_SimulinkSKRIPSIFIKS_FLC(void *chartInstanceVar)
{
  enable_c2_SimulinkSKRIPSIFIKS_FLC((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_disable_c2_SimulinkSKRIPSIFIKS_FLC(void *chartInstanceVar)
{
  disable_c2_SimulinkSKRIPSIFIKS_FLC((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*)
    chartInstanceVar);
}

static void sf_opaque_gateway_c2_SimulinkSKRIPSIFIKS_FLC(void *chartInstanceVar)
{
  sf_gateway_c2_SimulinkSKRIPSIFIKS_FLC
    ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*) chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c2_SimulinkSKRIPSIFIKS_FLC
  (SimStruct* S)
{
  return get_sim_state_c2_SimulinkSKRIPSIFIKS_FLC
    ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *)sf_get_chart_instance_ptr(S));/* raw sim ctx */
}

static void sf_opaque_set_sim_state_c2_SimulinkSKRIPSIFIKS_FLC(SimStruct* S,
  const mxArray *st)
{
  set_sim_state_c2_SimulinkSKRIPSIFIKS_FLC
    ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*)sf_get_chart_instance_ptr(S),
     st);
}

static void sf_opaque_cleanup_runtime_resources_c2_SimulinkSKRIPSIFIKS_FLC(void *
  chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*)
                    chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_SimulinkSKRIPSIFIKS_FLC_optimization_info();
    }

    mdl_cleanup_runtime_resources_c2_SimulinkSKRIPSIFIKS_FLC
      ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_mdl_start_c2_SimulinkSKRIPSIFIKS_FLC(void
  *chartInstanceVar)
{
  mdl_start_c2_SimulinkSKRIPSIFIKS_FLC
    ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_mdl_terminate_c2_SimulinkSKRIPSIFIKS_FLC(void
  *chartInstanceVar)
{
  mdl_terminate_c2_SimulinkSKRIPSIFIKS_FLC
    ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc2_SimulinkSKRIPSIFIKS_FLC
    ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c2_SimulinkSKRIPSIFIKS_FLC(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  sf_warn_if_symbolic_dimension_param_changed(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c2_SimulinkSKRIPSIFIKS_FLC
      ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*)sf_get_chart_instance_ptr(S));
    initSimStructsc2_SimulinkSKRIPSIFIKS_FLC
      ((SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct*)sf_get_chart_instance_ptr(S));
  }
}

const char* sf_c2_SimulinkSKRIPSIFIKS_FLC_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [20] = {
    "eNrtWE+P20QUd6LttpVKlQNSDyBRiUpwhF7oCXbjJNRstgl1dimnaNZ+iaexZ8z8SbJ74siFb8G",
    "HQBw4Io4ckRDfoR+BN7aTTR3baXYLChRHjjP277157/3eezOOVXOOLTzu4nnrnmXtmyuedSs9bm",
    "Tj2sqZ3t+zPsjG36MQ01GfCBJJq/JgJIKnIHmoFeXMYSNeCKNsBAKYh9iYC1WmTdJIh5RNOpp5R",
    "p/8KqBe4AZch34TZYnfY+E5aou16qOeFhXgqQ6ArwLB9TjohGS8tFiomR2AN5E6qnJBgnJ1bMyS",
    "xzpUNA6hPQfPYVIRtFhe2uYqosBW81I3jafSXQB5FIeUsEJvAyJdiDHACk5iH797WqFTeZgXEKG",
    "aEJApyC6dJDo5g7xOKvHBGWVEcUFJ2I5C2wiu29YP0Z5j7kNYERC0rSmATGJOmSrn3+2gp21Gzk",
    "JowZkel2tz4RttyD+lMANRGreRzacgyBh6rHTSJCDtecLWMkvWYYpGcErEoYf8SfBLsxczR7oEe",
    "YIBSpTBIHHSkQNBpxjeUm06ckxmbioZHaVky02wRFt7ClUsLLV1PGaTMJSlsAGPuzCFMNHaIopU",
    "w1KtxTgpqT/gGGCT3uXVoBlF4jOYzZlPC+ma5gBJ33mCjeVlpKel4pGNydvqdtcfr8McpkCMiAd",
    "FXUAQKgFjloS3XJtPpeEegWiVSswrAqcZsgllyZFmrRkXE4xJRRO5dMEwWgqM5Bi5xEo4kVg0VT",
    "DD5SacR7wAfNNgaAjHWDaILYiJNK3tEOtuStV5C6QnaFzAqsaqwzbUNgl1HsMJmzA+Yx3BIzfr8",
    "Wl4ATDbiGCUjZvYv8R5B2cvosKsZx9Zl+vZnVdYzxZy+euHK3pqBXqslWt+3tv1l/H13Lx1/NRq",
    "qdzBitxbuXn2cnIG18Dz5+/+fOfH2sUfn/zw4qf3T3+5tWn+2tr8teS3kZvf3G79v5uN31002mX",
    "hTNfy1WAfr9i1V6D/3or+RjaWD/u6+/Xjw3h+ET36YjZ4Zl/0nn/cTPT9ul9t742cvYv7903Hxy",
    "xL8lN4jp9tTMyY6HS5Nvofrdi7vyEet7P76fHis+vJv32Q53Fvg3wDf7VyeXv1+RsH15Nfn7/I/",
    "v0c32bcGsYCpqn8b9Z2+Vhf0Rta1Iqt9boq8qOe86OxcOLbo4P0+uS1xOPfzEt7l3ixeikv1pdv",
    "FC83c7yY8YjKIT97viP18nnGy9GO8HL/tdjxbAMvD3K8PEjeT4bE7Hpg6D0cLvYw7tFTp+86Hef",
    "IHXa6dt7Pq67b28pZ/8vthFztDfTvziv2pavIXXU+6x+Wu65/276P7Bq+al9r5fCNHfbjuu+Jfz",
    "f+9y33A+9l40+Xf9nYAQ39grf37DG+io+Knv4H8vQv2FXPGg==",
    ""
  };

  static char newstr [1401] = "";
  newstr[0] = '\0';
  for (i = 0; i < 20; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c2_SimulinkSKRIPSIFIKS_FLC(SimStruct *S)
{
  const char* newstr = sf_c2_SimulinkSKRIPSIFIKS_FLC_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(467503294U));
  ssSetChecksum1(S,(3682206136U));
  ssSetChecksum2(S,(3136332855U));
  ssSetChecksum3(S,(147215907U));
}

static void mdlRTW_c2_SimulinkSKRIPSIFIKS_FLC(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Embedded MATLAB");
  }
}

static void mdlSetupRuntimeResources_c2_SimulinkSKRIPSIFIKS_FLC(SimStruct *S)
{
  SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *chartInstance;
  chartInstance = (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct *)utMalloc(sizeof
    (SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  if (ssGetSampleTime(S, 0) == CONTINUOUS_SAMPLE_TIME && ssGetOffsetTime(S, 0) ==
      0 && ssGetNumContStates(ssGetRootSS(S)) > 0 &&
      !supportsLegacyBehaviorForPersistentVarInContinuousTime(S)) {
    sf_error_out_about_continuous_sample_time_with_persistent_vars(S);
  }

  chartInstance->chartInfo.isEMLChart = 1;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.mdlStart =
    sf_opaque_mdl_start_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.mdlTerminate =
    sf_opaque_mdl_terminate_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.mdlCleanupRuntimeResources =
    sf_opaque_cleanup_runtime_resources_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c2_SimulinkSKRIPSIFIKS_FLC;
  chartInstance->chartInfo.callGetHoverDataForMsg = NULL;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->chartInfo.chartStateSetterFcn = NULL;
  chartInstance->chartInfo.chartStateGetterFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0,
    chartInstance->c2_JITStateAnimation,
    chartInstance->c2_JITTransitionAnimation);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_setup_runtime_resources_c2_SimulinkSKRIPSIFIKS_FLC(chartInstance);
}

void c2_SimulinkSKRIPSIFIKS_FLC_method_dispatcher(SimStruct *S, int_T method,
  void *data)
{
  switch (method) {
   case SS_CALL_MDL_SETUP_RUNTIME_RESOURCES:
    mdlSetupRuntimeResources_c2_SimulinkSKRIPSIFIKS_FLC(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c2_SimulinkSKRIPSIFIKS_FLC(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c2_SimulinkSKRIPSIFIKS_FLC(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c2_SimulinkSKRIPSIFIKS_FLC_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
