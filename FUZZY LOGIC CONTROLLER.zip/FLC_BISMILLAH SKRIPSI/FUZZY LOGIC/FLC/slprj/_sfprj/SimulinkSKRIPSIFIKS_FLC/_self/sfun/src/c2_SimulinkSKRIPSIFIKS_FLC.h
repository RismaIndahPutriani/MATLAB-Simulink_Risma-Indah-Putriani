#ifndef __c2_SimulinkSKRIPSIFIKS_FLC_h__
#define __c2_SimulinkSKRIPSIFIKS_FLC_h__

/* Forward Declarations */
#ifndef typedef_c2_s15ssiVRIhrWT3e7dxoOupH
#define typedef_c2_s15ssiVRIhrWT3e7dxoOupH

typedef struct c2_tag_s15ssiVRIhrWT3e7dxoOupH c2_s15ssiVRIhrWT3e7dxoOupH;

#endif                                 /* typedef_c2_s15ssiVRIhrWT3e7dxoOupH */

#ifndef typedef_c2_swpvULEmUTKnryFWD4tJPAH
#define typedef_c2_swpvULEmUTKnryFWD4tJPAH

typedef struct c2_tag_swpvULEmUTKnryFWD4tJPAH c2_swpvULEmUTKnryFWD4tJPAH;

#endif                                 /* typedef_c2_swpvULEmUTKnryFWD4tJPAH */

#ifndef typedef_c2_sL6LJlPlxhdTxZzXh5NTaQC
#define typedef_c2_sL6LJlPlxhdTxZzXh5NTaQC

typedef struct c2_tag_sL6LJlPlxhdTxZzXh5NTaQC c2_sL6LJlPlxhdTxZzXh5NTaQC;

#endif                                 /* typedef_c2_sL6LJlPlxhdTxZzXh5NTaQC */

#ifndef typedef_c2_emxArray_char_T_1x5
#define typedef_c2_emxArray_char_T_1x5

typedef struct c2_emxArray_char_T_1x5 c2_emxArray_char_T_1x5;

#endif                                 /* typedef_c2_emxArray_char_T_1x5 */

#ifndef typedef_c2_emxArray_real_T_1x3
#define typedef_c2_emxArray_real_T_1x3

typedef struct c2_emxArray_real_T_1x3 c2_emxArray_real_T_1x3;

#endif                                 /* typedef_c2_emxArray_real_T_1x3 */

#ifndef typedef_c2_s_8hQCdWJdSJhbjCfdgdfm1F
#define typedef_c2_s_8hQCdWJdSJhbjCfdgdfm1F

typedef struct c2_tag_8hQCdWJdSJhbjCfdgdfm1F c2_s_8hQCdWJdSJhbjCfdgdfm1F;

#endif                                 /* typedef_c2_s_8hQCdWJdSJhbjCfdgdfm1F */

#ifndef typedef_c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm
#define typedef_c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm

typedef struct c2_emxArray_tag_8hQCdWJdSJhbjCfdgd
  c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm;

#endif                                 /* typedef_c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm */

#ifndef typedef_c2_emxArray_real_T_1x101
#define typedef_c2_emxArray_real_T_1x101

typedef struct c2_emxArray_real_T_1x101 c2_emxArray_real_T_1x101;

#endif                                 /* typedef_c2_emxArray_real_T_1x101 */

#ifndef typedef_c2_s_64TxJFgCtXBlX73DcwNLAB
#define typedef_c2_s_64TxJFgCtXBlX73DcwNLAB

typedef struct c2_tag_64TxJFgCtXBlX73DcwNLAB c2_s_64TxJFgCtXBlX73DcwNLAB;

#endif                                 /* typedef_c2_s_64TxJFgCtXBlX73DcwNLAB */

#ifndef typedef_c2_s_o4k2e0vdltB60WnSYJQFVC
#define typedef_c2_s_o4k2e0vdltB60WnSYJQFVC

typedef struct c2_tag_o4k2e0vdltB60WnSYJQFVC c2_s_o4k2e0vdltB60WnSYJQFVC;

#endif                                 /* typedef_c2_s_o4k2e0vdltB60WnSYJQFVC */

#ifndef typedef_c2_emxArray_s_o4k2e0vdltB60WnSYJQF
#define typedef_c2_emxArray_s_o4k2e0vdltB60WnSYJQF

typedef struct c2_emxArray_tag_o4k2e0vdltB60WnSYJ
  c2_emxArray_s_o4k2e0vdltB60WnSYJQF;

#endif                                 /* typedef_c2_emxArray_s_o4k2e0vdltB60WnSYJQF */

#ifndef typedef_c2_s_R1EPQmVtPqaprBGbq4jxhD
#define typedef_c2_s_R1EPQmVtPqaprBGbq4jxhD

typedef struct c2_tag_R1EPQmVtPqaprBGbq4jxhD c2_s_R1EPQmVtPqaprBGbq4jxhD;

#endif                                 /* typedef_c2_s_R1EPQmVtPqaprBGbq4jxhD */

#ifndef typedef_c2_s_JPdCXkmamKQZ91xcMYnAOD
#define typedef_c2_s_JPdCXkmamKQZ91xcMYnAOD

typedef struct c2_tag_JPdCXkmamKQZ91xcMYnAOD c2_s_JPdCXkmamKQZ91xcMYnAOD;

#endif                                 /* typedef_c2_s_JPdCXkmamKQZ91xcMYnAOD */

#ifndef typedef_c2_emxArray_real_T
#define typedef_c2_emxArray_real_T

typedef struct c2_emxArray_real_T c2_emxArray_real_T;

#endif                                 /* typedef_c2_emxArray_real_T */

#ifndef typedef_c2_s_JbR9CE1JwmiHOtKI7rv0ED
#define typedef_c2_s_JbR9CE1JwmiHOtKI7rv0ED

typedef struct c2_tag_JbR9CE1JwmiHOtKI7rv0ED c2_s_JbR9CE1JwmiHOtKI7rv0ED;

#endif                                 /* typedef_c2_s_JbR9CE1JwmiHOtKI7rv0ED */

#ifndef typedef_c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0
#define typedef_c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0

typedef struct c2_emxArray_tag_JbR9CE1JwmiHOtKI7r
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0;

#endif                                 /* typedef_c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 */

#ifndef typedef_c2_cell_wrap_0
#define typedef_c2_cell_wrap_0

typedef struct c2_tag_wVfZz4uBdVNo0SYd98f1KC c2_cell_wrap_0;

#endif                                 /* typedef_c2_cell_wrap_0 */

#ifndef typedef_c2_suvN3HkMprFcIaMRVdi47eC
#define typedef_c2_suvN3HkMprFcIaMRVdi47eC

typedef struct c2_tag_suvN3HkMprFcIaMRVdi47eC c2_suvN3HkMprFcIaMRVdi47eC;

#endif                                 /* typedef_c2_suvN3HkMprFcIaMRVdi47eC */

#ifndef typedef_c2_s5XYxtK6icIzLqFV4FdSKVC
#define typedef_c2_s5XYxtK6icIzLqFV4FdSKVC

typedef struct c2_tag_s5XYxtK6icIzLqFV4FdSKVC c2_s5XYxtK6icIzLqFV4FdSKVC;

#endif                                 /* typedef_c2_s5XYxtK6icIzLqFV4FdSKVC */

#ifndef typedef_c2_sEsqUUSxQBFGTGyl15EzrYH
#define typedef_c2_sEsqUUSxQBFGTGyl15EzrYH

typedef struct c2_tag_sEsqUUSxQBFGTGyl15EzrYH c2_sEsqUUSxQBFGTGyl15EzrYH;

#endif                                 /* typedef_c2_sEsqUUSxQBFGTGyl15EzrYH */

#ifndef typedef_c2_s4qsEqaDHXG669afyZjSQlH
#define typedef_c2_s4qsEqaDHXG669afyZjSQlH

typedef struct c2_tag_s4qsEqaDHXG669afyZjSQlH c2_s4qsEqaDHXG669afyZjSQlH;

#endif                                 /* typedef_c2_s4qsEqaDHXG669afyZjSQlH */

#ifndef typedef_c2_s_9DL33rUTgryGqqXf4f6A1E
#define typedef_c2_s_9DL33rUTgryGqqXf4f6A1E

typedef struct c2_tag_9DL33rUTgryGqqXf4f6A1E c2_s_9DL33rUTgryGqqXf4f6A1E;

#endif                                 /* typedef_c2_s_9DL33rUTgryGqqXf4f6A1E */

#ifndef typedef_c2_s_xulRujJto1gQ58WtQ8ChxF
#define typedef_c2_s_xulRujJto1gQ58WtQ8ChxF

typedef struct c2_tag_xulRujJto1gQ58WtQ8ChxF c2_s_xulRujJto1gQ58WtQ8ChxF;

#endif                                 /* typedef_c2_s_xulRujJto1gQ58WtQ8ChxF */

#ifndef typedef_c2_s_5ZDOC4lYZZXBhAEUbXMjWD
#define typedef_c2_s_5ZDOC4lYZZXBhAEUbXMjWD

typedef struct c2_tag_5ZDOC4lYZZXBhAEUbXMjWD c2_s_5ZDOC4lYZZXBhAEUbXMjWD;

#endif                                 /* typedef_c2_s_5ZDOC4lYZZXBhAEUbXMjWD */

#ifndef typedef_c2_s_bCBh7Pi2jvxDsMOAcKyLAE
#define typedef_c2_s_bCBh7Pi2jvxDsMOAcKyLAE

typedef struct c2_tag_bCBh7Pi2jvxDsMOAcKyLAE c2_s_bCBh7Pi2jvxDsMOAcKyLAE;

#endif                                 /* typedef_c2_s_bCBh7Pi2jvxDsMOAcKyLAE */

#ifndef typedef_c2_s_4Fr72VDSS1p2DUVUaSM65
#define typedef_c2_s_4Fr72VDSS1p2DUVUaSM65

typedef struct c2_tag_4Fr72VDSS1p2DUVUaSM65 c2_s_4Fr72VDSS1p2DUVUaSM65;

#endif                                 /* typedef_c2_s_4Fr72VDSS1p2DUVUaSM65 */

#ifndef typedef_c2_s_fxrtQpZcildDTGvn3QeHJH
#define typedef_c2_s_fxrtQpZcildDTGvn3QeHJH

typedef struct c2_tag_fxrtQpZcildDTGvn3QeHJH c2_s_fxrtQpZcildDTGvn3QeHJH;

#endif                                 /* typedef_c2_s_fxrtQpZcildDTGvn3QeHJH */

#ifndef typedef_c2_s_p6wwlW12g522yaIsbS39rE
#define typedef_c2_s_p6wwlW12g522yaIsbS39rE

typedef struct c2_tag_p6wwlW12g522yaIsbS39rE c2_s_p6wwlW12g522yaIsbS39rE;

#endif                                 /* typedef_c2_s_p6wwlW12g522yaIsbS39rE */

#ifndef typedef_c2_s_zBnbkWIDoQYOmfRYQQTZCF
#define typedef_c2_s_zBnbkWIDoQYOmfRYQQTZCF

typedef struct c2_tag_zBnbkWIDoQYOmfRYQQTZCF c2_s_zBnbkWIDoQYOmfRYQQTZCF;

#endif                                 /* typedef_c2_s_zBnbkWIDoQYOmfRYQQTZCF */

#ifndef typedef_c2_s_GBys1jprGfE2uYETSBX2vH
#define typedef_c2_s_GBys1jprGfE2uYETSBX2vH

typedef struct c2_tag_GBys1jprGfE2uYETSBX2vH c2_s_GBys1jprGfE2uYETSBX2vH;

#endif                                 /* typedef_c2_s_GBys1jprGfE2uYETSBX2vH */

/* Type Definitions */
#ifndef struct_c2_tag_s15ssiVRIhrWT3e7dxoOupH
#define struct_c2_tag_s15ssiVRIhrWT3e7dxoOupH

struct c2_tag_s15ssiVRIhrWT3e7dxoOupH
{
  uint8_T SimulinkDiagnostic;
  uint8_T Model;
  uint8_T Block;
  uint8_T OutOfRangeInputValue;
  uint8_T NoRuleFired;
  uint8_T EmptyOutputFuzzySet;
};

#endif                                 /* struct_c2_tag_s15ssiVRIhrWT3e7dxoOupH */

#ifndef typedef_c2_s15ssiVRIhrWT3e7dxoOupH
#define typedef_c2_s15ssiVRIhrWT3e7dxoOupH

typedef struct c2_tag_s15ssiVRIhrWT3e7dxoOupH c2_s15ssiVRIhrWT3e7dxoOupH;

#endif                                 /* typedef_c2_s15ssiVRIhrWT3e7dxoOupH */

#ifndef struct_c2_tag_swpvULEmUTKnryFWD4tJPAH
#define struct_c2_tag_swpvULEmUTKnryFWD4tJPAH

struct c2_tag_swpvULEmUTKnryFWD4tJPAH
{
  char_T type;
  real_T origTypeLength;
  real_T params;
  real_T origParamLength;
};

#endif                                 /* struct_c2_tag_swpvULEmUTKnryFWD4tJPAH */

#ifndef typedef_c2_swpvULEmUTKnryFWD4tJPAH
#define typedef_c2_swpvULEmUTKnryFWD4tJPAH

typedef struct c2_tag_swpvULEmUTKnryFWD4tJPAH c2_swpvULEmUTKnryFWD4tJPAH;

#endif                                 /* typedef_c2_swpvULEmUTKnryFWD4tJPAH */

#ifndef struct_c2_tag_sL6LJlPlxhdTxZzXh5NTaQC
#define struct_c2_tag_sL6LJlPlxhdTxZzXh5NTaQC

struct c2_tag_sL6LJlPlxhdTxZzXh5NTaQC
{
  int32_T intNumBits;
};

#endif                                 /* struct_c2_tag_sL6LJlPlxhdTxZzXh5NTaQC */

#ifndef typedef_c2_sL6LJlPlxhdTxZzXh5NTaQC
#define typedef_c2_sL6LJlPlxhdTxZzXh5NTaQC

typedef struct c2_tag_sL6LJlPlxhdTxZzXh5NTaQC c2_sL6LJlPlxhdTxZzXh5NTaQC;

#endif                                 /* typedef_c2_sL6LJlPlxhdTxZzXh5NTaQC */

#ifndef struct_c2_emxArray_char_T_1x5
#define struct_c2_emxArray_char_T_1x5

struct c2_emxArray_char_T_1x5
{
  char_T data[5];
  int32_T size[2];
};

#endif                                 /* struct_c2_emxArray_char_T_1x5 */

#ifndef typedef_c2_emxArray_char_T_1x5
#define typedef_c2_emxArray_char_T_1x5

typedef struct c2_emxArray_char_T_1x5 c2_emxArray_char_T_1x5;

#endif                                 /* typedef_c2_emxArray_char_T_1x5 */

#ifndef struct_c2_emxArray_real_T_1x3
#define struct_c2_emxArray_real_T_1x3

struct c2_emxArray_real_T_1x3
{
  real_T data[3];
  int32_T size[2];
};

#endif                                 /* struct_c2_emxArray_real_T_1x3 */

#ifndef typedef_c2_emxArray_real_T_1x3
#define typedef_c2_emxArray_real_T_1x3

typedef struct c2_emxArray_real_T_1x3 c2_emxArray_real_T_1x3;

#endif                                 /* typedef_c2_emxArray_real_T_1x3 */

#ifndef struct_c2_tag_8hQCdWJdSJhbjCfdgdfm1F
#define struct_c2_tag_8hQCdWJdSJhbjCfdgdfm1F

struct c2_tag_8hQCdWJdSJhbjCfdgdfm1F
{
  c2_emxArray_char_T_1x5 type;
  int32_T origTypeLength;
  c2_emxArray_real_T_1x3 params;
  int32_T origParamLength;
};

#endif                                 /* struct_c2_tag_8hQCdWJdSJhbjCfdgdfm1F */

#ifndef typedef_c2_s_8hQCdWJdSJhbjCfdgdfm1F
#define typedef_c2_s_8hQCdWJdSJhbjCfdgdfm1F

typedef struct c2_tag_8hQCdWJdSJhbjCfdgdfm1F c2_s_8hQCdWJdSJhbjCfdgdfm1F;

#endif                                 /* typedef_c2_s_8hQCdWJdSJhbjCfdgdfm1F */

#ifndef struct_c2_emxArray_tag_8hQCdWJdSJhbjCfdgd
#define struct_c2_emxArray_tag_8hQCdWJdSJhbjCfdgd

struct c2_emxArray_tag_8hQCdWJdSJhbjCfdgd
{
  c2_s_8hQCdWJdSJhbjCfdgdfm1F data[5];
  int32_T size[2];
};

#endif                                 /* struct_c2_emxArray_tag_8hQCdWJdSJhbjCfdgd */

#ifndef typedef_c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm
#define typedef_c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm

typedef struct c2_emxArray_tag_8hQCdWJdSJhbjCfdgd
  c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm;

#endif                                 /* typedef_c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm */

#ifndef struct_c2_emxArray_real_T_1x101
#define struct_c2_emxArray_real_T_1x101

struct c2_emxArray_real_T_1x101
{
  real_T data[101];
  int32_T size[2];
};

#endif                                 /* struct_c2_emxArray_real_T_1x101 */

#ifndef typedef_c2_emxArray_real_T_1x101
#define typedef_c2_emxArray_real_T_1x101

typedef struct c2_emxArray_real_T_1x101 c2_emxArray_real_T_1x101;

#endif                                 /* typedef_c2_emxArray_real_T_1x101 */

#ifndef struct_c2_tag_64TxJFgCtXBlX73DcwNLAB
#define struct_c2_tag_64TxJFgCtXBlX73DcwNLAB

struct c2_tag_64TxJFgCtXBlX73DcwNLAB
{
  c2_emxArray_s_8hQCdWJdSJhbjCfdgdfm mf;
  int32_T origNumMF;
};

#endif                                 /* struct_c2_tag_64TxJFgCtXBlX73DcwNLAB */

#ifndef typedef_c2_s_64TxJFgCtXBlX73DcwNLAB
#define typedef_c2_s_64TxJFgCtXBlX73DcwNLAB

typedef struct c2_tag_64TxJFgCtXBlX73DcwNLAB c2_s_64TxJFgCtXBlX73DcwNLAB;

#endif                                 /* typedef_c2_s_64TxJFgCtXBlX73DcwNLAB */

#ifndef struct_c2_tag_o4k2e0vdltB60WnSYJQFVC
#define struct_c2_tag_o4k2e0vdltB60WnSYJQFVC

struct c2_tag_o4k2e0vdltB60WnSYJQFVC
{
  c2_emxArray_char_T_1x5 type;
  real_T origTypeLength;
  c2_emxArray_real_T_1x3 params;
  real_T origParamLength;
};

#endif                                 /* struct_c2_tag_o4k2e0vdltB60WnSYJQFVC */

#ifndef typedef_c2_s_o4k2e0vdltB60WnSYJQFVC
#define typedef_c2_s_o4k2e0vdltB60WnSYJQFVC

typedef struct c2_tag_o4k2e0vdltB60WnSYJQFVC c2_s_o4k2e0vdltB60WnSYJQFVC;

#endif                                 /* typedef_c2_s_o4k2e0vdltB60WnSYJQFVC */

#ifndef struct_c2_emxArray_tag_o4k2e0vdltB60WnSYJ
#define struct_c2_emxArray_tag_o4k2e0vdltB60WnSYJ

struct c2_emxArray_tag_o4k2e0vdltB60WnSYJ
{
  c2_s_o4k2e0vdltB60WnSYJQFVC data[5];
  int32_T size[2];
};

#endif                                 /* struct_c2_emxArray_tag_o4k2e0vdltB60WnSYJ */

#ifndef typedef_c2_emxArray_s_o4k2e0vdltB60WnSYJQF
#define typedef_c2_emxArray_s_o4k2e0vdltB60WnSYJQF

typedef struct c2_emxArray_tag_o4k2e0vdltB60WnSYJ
  c2_emxArray_s_o4k2e0vdltB60WnSYJQF;

#endif                                 /* typedef_c2_emxArray_s_o4k2e0vdltB60WnSYJQF */

#ifndef struct_c2_tag_R1EPQmVtPqaprBGbq4jxhD
#define struct_c2_tag_R1EPQmVtPqaprBGbq4jxhD

struct c2_tag_R1EPQmVtPqaprBGbq4jxhD
{
  c2_emxArray_s_o4k2e0vdltB60WnSYJQF mf;
  real_T origNumMF;
};

#endif                                 /* struct_c2_tag_R1EPQmVtPqaprBGbq4jxhD */

#ifndef typedef_c2_s_R1EPQmVtPqaprBGbq4jxhD
#define typedef_c2_s_R1EPQmVtPqaprBGbq4jxhD

typedef struct c2_tag_R1EPQmVtPqaprBGbq4jxhD c2_s_R1EPQmVtPqaprBGbq4jxhD;

#endif                                 /* typedef_c2_s_R1EPQmVtPqaprBGbq4jxhD */

#ifndef struct_c2_tag_JPdCXkmamKQZ91xcMYnAOD
#define struct_c2_tag_JPdCXkmamKQZ91xcMYnAOD

struct c2_tag_JPdCXkmamKQZ91xcMYnAOD
{
  c2_s_o4k2e0vdltB60WnSYJQFVC mf;
  real_T origNumMF;
};

#endif                                 /* struct_c2_tag_JPdCXkmamKQZ91xcMYnAOD */

#ifndef typedef_c2_s_JPdCXkmamKQZ91xcMYnAOD
#define typedef_c2_s_JPdCXkmamKQZ91xcMYnAOD

typedef struct c2_tag_JPdCXkmamKQZ91xcMYnAOD c2_s_JPdCXkmamKQZ91xcMYnAOD;

#endif                                 /* typedef_c2_s_JPdCXkmamKQZ91xcMYnAOD */

#ifndef struct_c2_emxArray_real_T
#define struct_c2_emxArray_real_T

struct c2_emxArray_real_T
{
  real_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                 /* struct_c2_emxArray_real_T */

#ifndef typedef_c2_emxArray_real_T
#define typedef_c2_emxArray_real_T

typedef struct c2_emxArray_real_T c2_emxArray_real_T;

#endif                                 /* typedef_c2_emxArray_real_T */

#ifndef struct_c2_tag_JbR9CE1JwmiHOtKI7rv0ED
#define struct_c2_tag_JbR9CE1JwmiHOtKI7rv0ED

struct c2_tag_JbR9CE1JwmiHOtKI7rv0ED
{
  c2_emxArray_char_T_1x5 type;
  c2_emxArray_real_T_1x3 params;
};

#endif                                 /* struct_c2_tag_JbR9CE1JwmiHOtKI7rv0ED */

#ifndef typedef_c2_s_JbR9CE1JwmiHOtKI7rv0ED
#define typedef_c2_s_JbR9CE1JwmiHOtKI7rv0ED

typedef struct c2_tag_JbR9CE1JwmiHOtKI7rv0ED c2_s_JbR9CE1JwmiHOtKI7rv0ED;

#endif                                 /* typedef_c2_s_JbR9CE1JwmiHOtKI7rv0ED */

#ifndef struct_c2_emxArray_tag_JbR9CE1JwmiHOtKI7r
#define struct_c2_emxArray_tag_JbR9CE1JwmiHOtKI7r

struct c2_emxArray_tag_JbR9CE1JwmiHOtKI7r
{
  c2_s_JbR9CE1JwmiHOtKI7rv0ED data[5];
  int32_T size[2];
};

#endif                                 /* struct_c2_emxArray_tag_JbR9CE1JwmiHOtKI7r */

#ifndef typedef_c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0
#define typedef_c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0

typedef struct c2_emxArray_tag_JbR9CE1JwmiHOtKI7r
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0;

#endif                                 /* typedef_c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 */

#ifndef struct_c2_tag_wVfZz4uBdVNo0SYd98f1KC
#define struct_c2_tag_wVfZz4uBdVNo0SYd98f1KC

struct c2_tag_wVfZz4uBdVNo0SYd98f1KC
{
  c2_emxArray_s_JbR9CE1JwmiHOtKI7rv0 f1;
};

#endif                                 /* struct_c2_tag_wVfZz4uBdVNo0SYd98f1KC */

#ifndef typedef_c2_cell_wrap_0
#define typedef_c2_cell_wrap_0

typedef struct c2_tag_wVfZz4uBdVNo0SYd98f1KC c2_cell_wrap_0;

#endif                                 /* typedef_c2_cell_wrap_0 */

#ifndef struct_c2_tag_suvN3HkMprFcIaMRVdi47eC
#define struct_c2_tag_suvN3HkMprFcIaMRVdi47eC

struct c2_tag_suvN3HkMprFcIaMRVdi47eC
{
  char_T name[2];
  real_T origNameLength;
  char_T type[5];
  real_T origTypeLength;
  real_T params[3];
  real_T origParamLength;
};

#endif                                 /* struct_c2_tag_suvN3HkMprFcIaMRVdi47eC */

#ifndef typedef_c2_suvN3HkMprFcIaMRVdi47eC
#define typedef_c2_suvN3HkMprFcIaMRVdi47eC

typedef struct c2_tag_suvN3HkMprFcIaMRVdi47eC c2_suvN3HkMprFcIaMRVdi47eC;

#endif                                 /* typedef_c2_suvN3HkMprFcIaMRVdi47eC */

#ifndef struct_c2_tag_s5XYxtK6icIzLqFV4FdSKVC
#define struct_c2_tag_s5XYxtK6icIzLqFV4FdSKVC

struct c2_tag_s5XYxtK6icIzLqFV4FdSKVC
{
  char_T name[2];
  real_T origNameLength;
  real_T range[2];
  c2_suvN3HkMprFcIaMRVdi47eC mf[5];
  real_T origNumMF;
};

#endif                                 /* struct_c2_tag_s5XYxtK6icIzLqFV4FdSKVC */

#ifndef typedef_c2_s5XYxtK6icIzLqFV4FdSKVC
#define typedef_c2_s5XYxtK6icIzLqFV4FdSKVC

typedef struct c2_tag_s5XYxtK6icIzLqFV4FdSKVC c2_s5XYxtK6icIzLqFV4FdSKVC;

#endif                                 /* typedef_c2_s5XYxtK6icIzLqFV4FdSKVC */

#ifndef struct_c2_tag_sEsqUUSxQBFGTGyl15EzrYH
#define struct_c2_tag_sEsqUUSxQBFGTGyl15EzrYH

struct c2_tag_sEsqUUSxQBFGTGyl15EzrYH
{
  real_T antecedent[2];
  real_T consequent;
  real_T weight;
  real_T connection;
};

#endif                                 /* struct_c2_tag_sEsqUUSxQBFGTGyl15EzrYH */

#ifndef typedef_c2_sEsqUUSxQBFGTGyl15EzrYH
#define typedef_c2_sEsqUUSxQBFGTGyl15EzrYH

typedef struct c2_tag_sEsqUUSxQBFGTGyl15EzrYH c2_sEsqUUSxQBFGTGyl15EzrYH;

#endif                                 /* typedef_c2_sEsqUUSxQBFGTGyl15EzrYH */

#ifndef struct_c2_tag_s4qsEqaDHXG669afyZjSQlH
#define struct_c2_tag_s4qsEqaDHXG669afyZjSQlH

struct c2_tag_s4qsEqaDHXG669afyZjSQlH
{
  char_T name[8];
  char_T type[7];
  char_T andMethod[3];
  char_T orMethod[3];
  char_T defuzzMethod[8];
  char_T impMethod[3];
  char_T aggMethod[3];
  c2_s5XYxtK6icIzLqFV4FdSKVC input[2];
  c2_s5XYxtK6icIzLqFV4FdSKVC output;
  c2_sEsqUUSxQBFGTGyl15EzrYH rule[24];
};

#endif                                 /* struct_c2_tag_s4qsEqaDHXG669afyZjSQlH */

#ifndef typedef_c2_s4qsEqaDHXG669afyZjSQlH
#define typedef_c2_s4qsEqaDHXG669afyZjSQlH

typedef struct c2_tag_s4qsEqaDHXG669afyZjSQlH c2_s4qsEqaDHXG669afyZjSQlH;

#endif                                 /* typedef_c2_s4qsEqaDHXG669afyZjSQlH */

#ifndef struct_c2_tag_9DL33rUTgryGqqXf4f6A1E
#define struct_c2_tag_9DL33rUTgryGqqXf4f6A1E

struct c2_tag_9DL33rUTgryGqqXf4f6A1E
{
  uint8_T type[7];
  uint8_T andMethod[3];
  uint8_T orMethod[3];
  uint8_T defuzzMethod[8];
  uint8_T impMethod[3];
  uint8_T aggMethod[3];
  real_T inputRange[4];
  real_T outputRange[2];
  c2_s_64TxJFgCtXBlX73DcwNLAB inputMF[2];
  c2_s_64TxJFgCtXBlX73DcwNLAB outputMF;
  real_T antecedent[48];
  real_T consequent[24];
  real_T connection[24];
  real_T weight[24];
  int32_T numSamples;
  int32_T numInputs;
  int32_T numOutputs;
  int32_T numRules;
  int32_T numInputMFs[2];
  int32_T numCumInputMFs[2];
  int32_T numOutputMFs;
  int32_T numCumOutputMFs;
  c2_emxArray_real_T_1x101 outputSamplePoints;
  int32_T orrSize[2];
  int32_T aggSize[2];
  int32_T irrSize[2];
  int32_T rfsSize[2];
  int32_T sumSize[2];
  int32_T inputFuzzySetType;
};

#endif                                 /* struct_c2_tag_9DL33rUTgryGqqXf4f6A1E */

#ifndef typedef_c2_s_9DL33rUTgryGqqXf4f6A1E
#define typedef_c2_s_9DL33rUTgryGqqXf4f6A1E

typedef struct c2_tag_9DL33rUTgryGqqXf4f6A1E c2_s_9DL33rUTgryGqqXf4f6A1E;

#endif                                 /* typedef_c2_s_9DL33rUTgryGqqXf4f6A1E */

#ifndef struct_c2_tag_xulRujJto1gQ58WtQ8ChxF
#define struct_c2_tag_xulRujJto1gQ58WtQ8ChxF

struct c2_tag_xulRujJto1gQ58WtQ8ChxF
{
  real_T NumSamplePoints;
  char_T OutOfRangeInputValueMessage[7];
  char_T NoRuleFiredMessage[7];
  char_T EmptyOutputFuzzySetMessage[7];
};

#endif                                 /* struct_c2_tag_xulRujJto1gQ58WtQ8ChxF */

#ifndef typedef_c2_s_xulRujJto1gQ58WtQ8ChxF
#define typedef_c2_s_xulRujJto1gQ58WtQ8ChxF

typedef struct c2_tag_xulRujJto1gQ58WtQ8ChxF c2_s_xulRujJto1gQ58WtQ8ChxF;

#endif                                 /* typedef_c2_s_xulRujJto1gQ58WtQ8ChxF */

#ifndef struct_c2_tag_5ZDOC4lYZZXBhAEUbXMjWD
#define struct_c2_tag_5ZDOC4lYZZXBhAEUbXMjWD

struct c2_tag_5ZDOC4lYZZXBhAEUbXMjWD
{
  real_T NumSamplePoints;
  char_T OutOfRangeInputValueMessage[7];
  char_T NoRuleFiredMessage[7];
  char_T EmptyOutputFuzzySetMessage[7];
};

#endif                                 /* struct_c2_tag_5ZDOC4lYZZXBhAEUbXMjWD */

#ifndef typedef_c2_s_5ZDOC4lYZZXBhAEUbXMjWD
#define typedef_c2_s_5ZDOC4lYZZXBhAEUbXMjWD

typedef struct c2_tag_5ZDOC4lYZZXBhAEUbXMjWD c2_s_5ZDOC4lYZZXBhAEUbXMjWD;

#endif                                 /* typedef_c2_s_5ZDOC4lYZZXBhAEUbXMjWD */

#ifndef struct_c2_tag_bCBh7Pi2jvxDsMOAcKyLAE
#define struct_c2_tag_bCBh7Pi2jvxDsMOAcKyLAE

struct c2_tag_bCBh7Pi2jvxDsMOAcKyLAE
{
  char_T Value[20];
};

#endif                                 /* struct_c2_tag_bCBh7Pi2jvxDsMOAcKyLAE */

#ifndef typedef_c2_s_bCBh7Pi2jvxDsMOAcKyLAE
#define typedef_c2_s_bCBh7Pi2jvxDsMOAcKyLAE

typedef struct c2_tag_bCBh7Pi2jvxDsMOAcKyLAE c2_s_bCBh7Pi2jvxDsMOAcKyLAE;

#endif                                 /* typedef_c2_s_bCBh7Pi2jvxDsMOAcKyLAE */

#ifndef struct_c2_tag_4Fr72VDSS1p2DUVUaSM65
#define struct_c2_tag_4Fr72VDSS1p2DUVUaSM65

struct c2_tag_4Fr72VDSS1p2DUVUaSM65
{
  char_T Value[4];
};

#endif                                 /* struct_c2_tag_4Fr72VDSS1p2DUVUaSM65 */

#ifndef typedef_c2_s_4Fr72VDSS1p2DUVUaSM65
#define typedef_c2_s_4Fr72VDSS1p2DUVUaSM65

typedef struct c2_tag_4Fr72VDSS1p2DUVUaSM65 c2_s_4Fr72VDSS1p2DUVUaSM65;

#endif                                 /* typedef_c2_s_4Fr72VDSS1p2DUVUaSM65 */

#ifndef struct_c2_tag_fxrtQpZcildDTGvn3QeHJH
#define struct_c2_tag_fxrtQpZcildDTGvn3QeHJH

struct c2_tag_fxrtQpZcildDTGvn3QeHJH
{
  char_T Value[7];
};

#endif                                 /* struct_c2_tag_fxrtQpZcildDTGvn3QeHJH */

#ifndef typedef_c2_s_fxrtQpZcildDTGvn3QeHJH
#define typedef_c2_s_fxrtQpZcildDTGvn3QeHJH

typedef struct c2_tag_fxrtQpZcildDTGvn3QeHJH c2_s_fxrtQpZcildDTGvn3QeHJH;

#endif                                 /* typedef_c2_s_fxrtQpZcildDTGvn3QeHJH */

#ifndef struct_c2_tag_p6wwlW12g522yaIsbS39rE
#define struct_c2_tag_p6wwlW12g522yaIsbS39rE

struct c2_tag_p6wwlW12g522yaIsbS39rE
{
  char_T Value[11];
};

#endif                                 /* struct_c2_tag_p6wwlW12g522yaIsbS39rE */

#ifndef typedef_c2_s_p6wwlW12g522yaIsbS39rE
#define typedef_c2_s_p6wwlW12g522yaIsbS39rE

typedef struct c2_tag_p6wwlW12g522yaIsbS39rE c2_s_p6wwlW12g522yaIsbS39rE;

#endif                                 /* typedef_c2_s_p6wwlW12g522yaIsbS39rE */

#ifndef struct_c2_tag_zBnbkWIDoQYOmfRYQQTZCF
#define struct_c2_tag_zBnbkWIDoQYOmfRYQQTZCF

struct c2_tag_zBnbkWIDoQYOmfRYQQTZCF
{
  char_T Value[19];
};

#endif                                 /* struct_c2_tag_zBnbkWIDoQYOmfRYQQTZCF */

#ifndef typedef_c2_s_zBnbkWIDoQYOmfRYQQTZCF
#define typedef_c2_s_zBnbkWIDoQYOmfRYQQTZCF

typedef struct c2_tag_zBnbkWIDoQYOmfRYQQTZCF c2_s_zBnbkWIDoQYOmfRYQQTZCF;

#endif                                 /* typedef_c2_s_zBnbkWIDoQYOmfRYQQTZCF */

#ifndef struct_c2_tag_GBys1jprGfE2uYETSBX2vH
#define struct_c2_tag_GBys1jprGfE2uYETSBX2vH

struct c2_tag_GBys1jprGfE2uYETSBX2vH
{
  char_T type[7];
  char_T andMethod[3];
  char_T orMethod[3];
  char_T defuzzMethod[8];
  char_T impMethod[3];
  char_T aggMethod[3];
  c2_s_R1EPQmVtPqaprBGbq4jxhD inputMF[2];
  c2_s_R1EPQmVtPqaprBGbq4jxhD outputMF;
  real_T inputRange[4];
  real_T outputRange[2];
  real_T antecedent[48];
  real_T consequent[24];
  real_T connection[24];
  real_T weight[24];
  real_T numSamples;
  real_T numInputs;
  real_T numOutputs;
  real_T numRules;
  real_T numInputMFs[2];
  real_T numCumInputMFs[2];
  real_T numOutputMFs;
  real_T numCumOutputMFs;
  c2_emxArray_real_T_1x101 outputSamplePoints;
  real_T orrSize[2];
  real_T aggSize[2];
  real_T irrSize[2];
  real_T rfsSize[2];
  real_T sumSize[2];
  real_T inputFuzzySetType;
};

#endif                                 /* struct_c2_tag_GBys1jprGfE2uYETSBX2vH */

#ifndef typedef_c2_s_GBys1jprGfE2uYETSBX2vH
#define typedef_c2_s_GBys1jprGfE2uYETSBX2vH

typedef struct c2_tag_GBys1jprGfE2uYETSBX2vH c2_s_GBys1jprGfE2uYETSBX2vH;

#endif                                 /* typedef_c2_s_GBys1jprGfE2uYETSBX2vH */

#ifndef typedef_SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct
#define typedef_SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  int32_T c2_sfEvent;
  boolean_T c2_doneDoubleBufferReInit;
  uint8_T c2_is_active_c2_SimulinkSKRIPSIFIKS_FLC;
  uint8_T c2_JITStateAnimation[1];
  uint8_T c2_JITTransitionAnimation[1];
  int32_T c2_IsDebuggerActive;
  int32_T c2_IsSequenceViewerPresent;
  int32_T c2_SequenceViewerOptimization;
  int32_T c2_IsHeatMapPresent;
  void *c2_RuntimeVar;
  c2_s4qsEqaDHXG669afyZjSQlH c2_fis_obj;
  boolean_T c2_fis_obj_not_empty;
  real_T c2_D_prev;
  boolean_T c2_D_prev_not_empty;
  real_T c2_E_prev;
  boolean_T c2_E_prev_not_empty;
  uint32_T c2_mlFcnLineNumber;
  void *c2_fcnDataPtrs[8];
  char_T *c2_dataNames[8];
  uint32_T c2_numFcnVars;
  uint32_T c2_ssIds[8];
  uint32_T c2_statuses[8];
  void *c2_outMexFcns[8];
  void *c2_inMexFcns[8];
  CovrtStateflowInstance *c2_covrtInstance;
  void *c2_fEmlrtCtx;
  real_T *c2_dP;
  real_T *c2_D;
  real_T *c2_dV;
} SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct;

#endif                                 /* typedef_SFc2_SimulinkSKRIPSIFIKS_FLCInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray
  *sf_c2_SimulinkSKRIPSIFIKS_FLC_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c2_SimulinkSKRIPSIFIKS_FLC_get_check_sum(mxArray *plhs[]);
extern void c2_SimulinkSKRIPSIFIKS_FLC_method_dispatcher(SimStruct *S, int_T
  method, void *data);

#endif
