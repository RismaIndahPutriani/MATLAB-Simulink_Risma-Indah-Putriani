"C:\MATLAB ANYA\sys\lcc64\lcc64\bin\lccmake.exe" -f SimulinkSKRIPSIFIKS_FLC_sfun.lmk
