clearvars; clc;

%Parameter Input
G=1000;%Iradiasi
T=25+273.15;%Suhu dalam satuan Celcius ditambah kelvin

%Spesifikasi panel surya (datasheet)
Wp=350;
Vmp=36.9;
Imp=9.5;
Voc=43.8;
Isc=10.1;
Kos=-0.29;
Ksc=0.05;
Ns=66;%Nomor PV cells seri
Np=2;%Nomor PV cells paralel
Rs=0.2%Series resistor in Ohm
Rsh=200 %Shunt resistor in Ohm

%Konstanta
k=1.381e-23;%Konstanta Boltzman
q=1.602e-19;%Muatan elektron
n=1.2%Ideal factor tipe cell monocrystalline (Si-mono)
Iph_ref=Isc;
Gn=1000;%Iradiasi ketika STC
Tn=25+273.15;%Suhu ketika STC dalam satuan kelvin
Eg=1.12;%band gap energy dari semikonduktor jenis silikon

%Perhitungan
VT=k*(T/q)
a_hitung=(Ns*n*k*T)/q
a=Ns*n*VT
Voc_T1=Voc/Ns
Vtn=Ns*(k*Tn/q)

%Menentukan nilai Iph (Photocurrent
Iph=G/Gn*(Isc+(Ksc*(T-Tn)))

%Menentukan module reverse saturation current (Irs)
Irs=Isc/(exp((q*Voc)/(Ns*k*n*T))-1)

%Menentukan nilai Io
Io=(Irs*(T/Tn)^3)*exp((q*Eg)/(n*k)*((1/Tn)-(1/T))) %rumus detailed modeling pv

%Penentuan I dan V
I=Isc
V=0

%Menentukan Ish
Ish=(V+(I*Rs))/Rsh
%Rsh=Rshunt=Rp

%Menentukan nilai I Pv
I=Iph-Io*(exp(((V+(I*Rs))*q)/(Ns*n*k*T))-1)-Ish%rumus detailed modelling pv
I=Iph-Io*(exp((V+(I*Rs))/a)-1)-Ish

%Menentukan efisiensi
FF=(Vmp*Imp)/(Voc*Isc)
A=1.852*0.996%panjang x lebar

Efisiensi=((Voc*Isc*FF)/(G*A))*100
%label{p_programpv}

