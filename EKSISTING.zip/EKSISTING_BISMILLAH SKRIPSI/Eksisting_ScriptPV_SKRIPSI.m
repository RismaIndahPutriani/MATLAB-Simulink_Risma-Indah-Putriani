clearvars; clc;
%  MODEL PV — Risen RSM132-6-350M (STC)
% Parameter STC dari datasheet
G   = 1000;         % Iradiasi (W/m^2)
T   = 25+273.15;    % Suhu (Kelvin)
Wp  = 350;          % Daya maksimum (Wp)
Vmp = 36.9;         % Tegangan MPP (V)
Imp = 9.5;          % Arus MPP (A)
Voc = 43.8;         % Tegangan open circuit (V)
Isc = 10.1;         % Arus short circuit (A)
Ns  = 66;           % Jumlah sel seri (6x11 + 6x11 = 132)
Np  = 2;            % Jumlah modul paralel

% Koefisien suhu (datasheet: %/°C → dikonversi ke nilai absolut
% Koc = -0.29%/°C terhadap Voc
% Ksc = +0.05%/°C terhadap Isc
Koc = (-0.29/100) * Voc;   % V/°C  = -0.12702 V/°C
Ksc = ( 0.05/100) * Isc;   % A/°C  = +0.005095 A/°C

% Resistansi internal (estimasi)
Rs  =0.2;          % Resistansi seri (Ohm)
Rsh =200;           % Resistansi shunt (Ohm)

% Konstanta fisika
k = 1.381e-23;       % Konstanta Boltzmann (J/K)
q = 1.602e-19;       % Muatan elektron (C)
n = 1.2;             % Faktor idealitas (monocrystalline 9BB)
Gn = 1000;           % Iradiasi STC
Tn = 25 + 273.15;    % Suhu STC (K)
Eg = 1.12;           % Band gap silikon (eV)

% Perhitungan parameter model
VT=k*(T/q);       % Thermal voltage per sel (≈0.02585 V @ 25°C)
a=Ns*n*VT         % Faktor dioda total (V)

%Menentukan nilai arus photocurrent (Iph)
Iph=G/Gn*(Isc+(Ksc*(T-Tn)))

%Menentukan nilai arus saturasi balik (Irs)
Irs=Isc/(exp((q*Voc)/(Ns*k*n*T))-1)

%Menentukan nilai arus dioda (Io)
Io=(Irs*(T/Tn)^3)*exp((q*Eg)/(n*k)*((1*Tn)-(1/T)))

%Menentukan arus (I) dan tegangan (V)
I=Isc
V=0

%Menentukan nilai arus resistansi shunt (Ish)
Ish= (V+(I*Rs))/Rsh
%Rsh=Rshunt=Rp

%Menentukan nilai arus PV(Ipv)
I=Iph-Io*(exp(((V+(I*Rs))*q)/(Ns*n*k*T))-1)-Ish
I=Iph-Io*(exp((V+(I*Rs))/a)-1)-Ish

%Menentukan efisiensi PV
FF=(Vmp*Imp)/(Voc*Isc)
A=1.852*0.996 %panjang x lebar

Efisiensi=((Voc*Isc*FF)/(G*A))*100
%label(p_programpv