clearvars; clc;

%% ============================================================
%  MODEL PV — Risen RSM132-6-350M (STC)
%  Detailed Two-Diode / Single-Diode dengan Newton-Raphson
% ============================================================

%% --- Parameter STC dari datasheet ---
G   = 1000;          % Iradiasi (W/m^2)
T_C = 25;            % Suhu (Celsius)
T   = T_C + 273.15;  % Suhu (Kelvin)

Wp  = 350;           % Daya maksimum (Wp)
Vmp = 36.90;         % Tegangan MPP (V)
Imp = 9.50;          % Arus MPP (A)
Voc = 43.80;         % Tegangan open circuit (V)
Isc = 10.10;         % Arus short circuit (A)
Ns  = 132;           % Jumlah sel seri (6x11 + 6x11 = 132)
Np  = 1;             % Jumlah modul paralel

%% --- Koefisien suhu (datasheet: %/°C → dikonversi ke nilai absolut) ---
% Koc = -0.29%/°C terhadap Voc
% Ksc = +0.05%/°C terhadap Isc
Koc = (-0.29/100) * Voc;   % V/°C  = -0.12702 V/°C
Ksc = ( 0.05/100) * Isc;   % A/°C  = +0.005095 A/°C

%% --- Resistansi internal (estimasi) ---
Rs  = 0.20;          % Resistansi seri (Ohm)
Rsh = 200;           % Resistansi shunt (Ohm)

%% --- Konstanta fisika ---
k = 1.381e-23;       % Konstanta Boltzmann (J/K)
q = 1.602e-19;       % Muatan elektron (C)
n = 1.2;             % Faktor idealitas (monocrystalline 9BB)
Gn = 1000;           % Iradiasi STC
Tn = 25 + 273.15;    % Suhu STC (K)
Eg = 1.12;           % Band gap silikon (eV)

%% --- Perhitungan parameter model ---
VT  = k * T / q;             % Thermal voltage per sel (≈0.02585 V @ 25°C)
a   = Ns * n * VT;            % Faktor dioda total (V)

% Photocurrent (bergantung G dan T)
Iph = Np * (G/Gn) * (Isc + Ksc*(T - Tn));

% Reverse saturation current dari kondisi Voc
Irs = (Np*Isc) / (exp((q*Voc)/(Ns*n*k*T)) - 1);

% Arus saturasi pada suhu T
Io  = Irs * (T/Tn)^3 * exp((q*Eg)/(n*k) * (1/Tn - 1/T));

fprintf('=== Parameter Model ===\n');
fprintf('VT   = %.5f V\n', VT);
fprintf('a    = %.4f V\n', a);
fprintf('Iph  = %.4f A\n', Iph);
fprintf('Irs  = %.3e A\n', Irs);
fprintf('Io   = %.3e A\n', Io);

%% --- Kurva I-V: iterasi Newton-Raphson ---
N_pts = 1000;
V_vec = linspace(0, Voc, N_pts);
I_vec = zeros(1, N_pts);

for idx = 1:N_pts
    Vi  = V_vec(idx);
    Ii  = Iph;               % tebakan awal
    for iter = 1:100
        Ish   = (Vi + Ii*Rs) / Rsh;
        exp_v = exp((Vi + Ii*Rs) / a);
        f     =  Ii - Iph + Io*(exp_v - 1) + Ish;
        df    =  1 + (Io*Rs/a)*exp_v + Rs/Rsh;
        delta =  f / df;
        Ii    =  Ii - delta;
        if abs(delta) < 1e-10, break; end
    end
    I_vec(idx) = max(Ii, 0);
end

P_vec = V_vec .* I_vec;

%% --- Titik MPP ---
[Pmax_sim, idx_mpp] = max(P_vec);
Vmpp_sim = V_vec(idx_mpp);
Impp_sim = I_vec(idx_mpp);
FF       = (Vmp * Imp) / (Voc * Isc);
A_panel  = 1.852 * 0.996;   % m^2 (dari datasheet dimensi modul)
Eff      = (Pmax_sim / (G * A_panel)) * 100;

fprintf('\n=== Hasil Simulasi ===\n');
fprintf('Vmpp = %.3f V   (datasheet: %.2f V)\n', Vmpp_sim, Vmp);
fprintf('Impp = %.3f A   (datasheet: %.2f A)\n', Impp_sim, Imp);
fprintf('Pmax = %.2f W   (datasheet: %.0f W)\n',  Pmax_sim, Wp);
fprintf('FF   = %.4f\n', FF);
fprintf('Efisiensi = %.2f %%  (datasheet: 19.0 %%)\n', Eff);

%% --- Plot ---
figure('Name','Risen RSM132-6-350M — Kurva I-V & P-V','NumberTitle','off');

subplot(2,1,1);
plot(V_vec, I_vec, 'b-', 'LineWidth', 2); hold on;
plot(Vmpp_sim, Impp_sim, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
xlabel('Tegangan (V)'); ylabel('Arus (A)');
title('Kurva I-V — RSM132-6-350M (STC)');
legend('I-V', sprintf('MPP (%.2fV, %.2fA)', Vmpp_sim, Impp_sim));
grid on;

subplot(2,1,2);
plot(V_vec, P_vec, 'r-', 'LineWidth', 2); hold on;
plot(Vmpp_sim, Pmax_sim, 'bs', 'MarkerSize', 8, 'MarkerFaceColor', 'b');
xlabel('Tegangan (V)'); ylabel('Daya (W)');
title('Kurva P-V — RSM132-6-350M (STC)');
legend('P-V', sprintf('Pmax = %.1f W @ %.2f V', Pmax_sim, Vmpp_sim));
grid on;