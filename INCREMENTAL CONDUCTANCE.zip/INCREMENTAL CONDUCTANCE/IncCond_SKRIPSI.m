function D = IncCond(V, I)
    persistent Vold Iold Dold;
    step = 0.008; % Kecepatan perubahan Duty Cycle
    Dinit = 0.7;  % Duty cycle awal (50%)

    % Inisialisasi saat simulasi pertama kali jalan
    if isempty(Vold)
        Vold = V;
        Iold = I;
        Dold = Dinit;
    end

    % Perhitungan selisih tegangan dan arus
    dV = V - Vold;
    dI = I - Iold;

    % LOGIKA INCREMENTAL CONDUCTANCE
    if abs(dV) < 1e-4
        if dI ~= 0
            if dI > 0
                Dold = Dold + step; % DIBALIK: Naikkan D untuk menurunkan V_PV
            else
                Dold = Dold - step; % DIBALIK: Turunkan D untuk menaikkan V_PV
            end
        end
    else
        if V == 0; V = 1e-4; end 
        kondisi = (dI * V) + (I * dV);
        
        if abs(kondisi) < 0.01
            % Sudah berada di area puncak MPPT (Dold dipertahankan)
        elseif kondisi > 0
            Dold = Dold + step; % DIBALIK: Kiri dari puncak, naikkan D agar V_PV turun ke Vmpp
        else
            Dold = Dold - step; % DIBALIK: Kanan dari puncak, turunkan D agar V_PV naik ke Vmpp
        end
    end

    % Batasan Duty Cycle agar tidak 0 atau 1 (supaya aman untuk MOSFET)
    if Dold > 0.9; Dold = 0.9; end
    if Dold < 0.1; Dold = 0.1; end

    % Output ke PWM
    D = Dold;

    % Penyimpanan nilai sekarang untuk dipakai di langkah berikutnya
    Vold = V;
    Iold = I;
end