clearvars; clc;

%% ============================================================
%  DESAIN BUCK CONVERTER
%  Input : Vmpp = 36.90 V  (Risen RSM132-6-350M)
%  Output: Vout = 24 V
% ============================================================

%% --- Spesifikasi PV (RSM132-6-350M STC) ---
Vmp  = 36.90;
Imp  = 9.50;
Wp   = 350;
Voc  = 43.80;
Isc  = 10.10;

%% --- Parameter konverter ---
Vin     = Vmp;       % Tegangan input = Vmpp
Vout    = 24;        % Tegangan output target (V)
ripple_I = 0.20;     % Ripple arus induktor 20%
ripple_V = 0.05;     % Ripple tegangan kapasitor 5%
Fsw     = 20000;     % Frekuensi switching (20 kHz)

%% --- Duty Cycle ---
D     = Vout / Vin;
fprintf('=== Duty Cycle ===\n');
fprintf('D = Vout/Vin = %.4f / %.2f = %.6f  (%.4f %%)\n', Vout, Vin, D, D*100);

%% --- Arus keluaran (daya output / Vout, asumsi efisiensi ideal) ---
Iout = Wp / Vout;
fprintf('\n=== Arus ===\n');
fprintf('Iout = Wp/Vout = %.0f/%.0f = %.4f A\n', Wp, Vout, Iout);

Iin_teoritis = D * Iout;
fprintf('Iin  (teoritis) = D × Iout = %.4f A\n', Iin_teoritis);
fprintf('Imp  (datasheet)          = %.2f A\n', Imp);
% Catatan: Iin_teoritis ≈ Imp → konversi energi konsisten

%% --- Ripple ---
deltaIL = ripple_I * Iout;      % A
deltaVC = ripple_V * Vout;      % V
fprintf('\n=== Ripple ===\n');
fprintf('ΔIL = %.4f A\n', deltaIL);
fprintf('ΔVC = %.4f V\n', deltaVC);

%% --- Nilai komponen ---
L = (Vout * (1 - D)) / (Fsw * deltaIL);
C = (1 - D) / (8 * L * deltaVC * Fsw^2);
R = Vout / Iout;

fprintf('\n=== Komponen ===\n');
fprintf('L = %.6f H  =  %.3f µH\n', L, L*1e6);
fprintf('C = %.8f F  =  %.3f µF\n', C, C*1e6);
fprintf('R = %.4f Ω\n', R);

%% --- Arus induktor maks & min ---
Imax = Vout*(1/R + (1-D)/(2*L*Fsw));
Imin = Vout*(1/R - (1-D)/(2*L*Fsw));
fprintf('\n=== Arus Induktor ===\n');
fprintf('Imax = %.4f A\n', Imax);
fprintf('Imin = %.4f A\n', Imin);
if Imin < 0
    warning('Imin < 0 → konverter beroperasi di mode DCM. Pertimbangkan menaikkan L.');
end

%% --- Verifikasi ripple ---
Vripple_check = (1 - D) / (8 * L * C * Fsw^2);
Iripple_check = (Vout * (1 - D)) / (L * Fsw);   % kurung ekstra dihapus

fprintf('\n=== Verifikasi ===\n');
fprintf('Ripple tegangan : %.6f  (target %.4f)\n', Vripple_check, ripple_V);
fprintf('Ripple arus     : %.4f A\n', Iripple_check);

fprintf('\n=== Ringkasan untuk Simulink ===\n');
fprintf('L  = %.4e H\n', L);
fprintf('C  = %.4e F\n', C);
fprintf('R  = %.4f Ω\n', R);
fprintf('D  = %.4f  (nilai Dinit untuk IC)\n', D);
fprintf('Fsw = %d Hz\n', Fsw);